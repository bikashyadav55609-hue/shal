import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DECORATIVE_HEART_SPECS,
  DECORATIVE_ORB_SPECS,
  DECORATIVE_SPARKLE_SPECS,
  getChapterDecorativeVars,
} from './decorativeLayers';

test('decorative layer specs define valid CSS-variable durations and non-empty layers', () => {
  assert.ok(DECORATIVE_ORB_SPECS.length >= 3);
  assert.ok(DECORATIVE_HEART_SPECS.length >= 4);
  assert.ok(DECORATIVE_SPARKLE_SPECS.length >= 6);

  for (const orb of DECORATIVE_ORB_SPECS) {
    assert.match(orb.duration, /^\d+(\.\d+)?s$/);
    assert.ok(orb.colorVar.startsWith('var(--theme-'));
  }

  for (const heart of DECORATIVE_HEART_SPECS) {
    assert.match(heart.duration, /^\d+(\.\d+)?s$/);
    assert.ok(heart.opacity > 0 && heart.opacity <= 0.5);
  }
});

test('getChapterDecorativeVars returns valid normalized CSS custom properties for chapters 1..4', () => {
  for (const chapter of [1, 2, 3, 4] as const) {
    const vars = getChapterDecorativeVars(chapter);
    const orbOpacity = Number(vars['--decor-orb-opacity']);
    const heartOpacity = Number(vars['--decor-heart-opacity']);
    const sparkleOpacity = Number(vars['--decor-sparkle-opacity']);

    assert.ok(orbOpacity >= 0.5 && orbOpacity <= 1);
    assert.ok(heartOpacity >= 0.5 && heartOpacity <= 1);
    assert.ok(sparkleOpacity >= 0.5 && sparkleOpacity <= 1);
  }

  assert.equal(getChapterDecorativeVars(4)['--decor-sparkle-opacity'], '1');
});
