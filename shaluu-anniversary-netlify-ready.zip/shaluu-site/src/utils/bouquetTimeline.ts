export const BOUQUET_ASSETS = {
  pinkRoseFront: '/src/assets/images/flower_pink_rose_front.png',
  pinkRoseAngled: '/src/assets/images/flower_pink_rose_angled.png',
  whiteRoseFront: '/src/assets/images/flower_white_rose_front.png',
  whiteRoseAngled: '/src/assets/images/flower_white_rose_angled.png',
  pinkTulipFront: '/src/assets/images/flower_pink_tulip_front.png',
  pinkTulipAngled: '/src/assets/images/flower_pink_tulip_angled.png',
  babysBreath: '/src/assets/images/flower_babys_breath.png',
  whiteFiller: '/src/assets/images/flower_white_filler.png',
  eucalyptus: '/src/assets/images/foliage_eucalyptus.png',
  roseLeaf: '/src/assets/images/foliage_rose_leaf.png',
  foliageSprig: '/src/assets/images/foliage_sprig.png',
} as const;

export const BOUQUET_FINAL_STEP = 13;

export interface BouquetTimelineStep {
  step: number;
  delayMs: number;
  caption: string;
}

/**
 * 13-stage flower-by-flower assembly schedule spanning ~13.0 seconds (within 10-14s).
 * Step 0 starts empty; Step 13 reveals the completed bouquet and celebration message.
 */
export const BOUQUET_TIMELINE: readonly BouquetTimelineStep[] = [
  { step: 1, delayMs: 350, caption: 'Preparing fresh green stems & leaves...' },
  { step: 2, delayMs: 1500, caption: 'Placing the first blush garden rose...' },
  { step: 3, delayMs: 2450, caption: 'Adding an ivory white garden rose...' },
  { step: 4, delayMs: 3400, caption: 'Tucking a pink rose to the right...' },
  { step: 5, delayMs: 4350, caption: 'Crowning with a higher white rose...' },
  { step: 6, delayMs: 5300, caption: 'Arranging a soft pink tulip on the left...' },
  { step: 7, delayMs: 6200, caption: 'Balancing with a pink tulip on the right...' },
  { step: 8, delayMs: 7100, caption: 'Building fullness with smaller roses...' },
  { step: 9, delayMs: 8900, caption: "Weaving airy baby's breath & white filler..." },
  { step: 10, delayMs: 10400, caption: 'Framing with silver eucalyptus & foliage...' },
  { step: 11, delayMs: 11650, caption: 'Folding soft blush wrapping paper...' },
  { step: 12, delayMs: 12350, caption: 'Tying the dusty-rose satin bow...' },
  { step: 13, delayMs: 13000, caption: 'A Bouquet for My Favorite Girl ♡' },
] as const;

export interface BouquetPieceSpec {
  id: string;
  minStep: number;
  subDelayMs?: number;
  src: string;
  alt: string;
  /** Percentage coordinates relative to the bouquet stage container */
  leftPct: number;
  topPct: number;
  widthPct: number;
  zIndex: number;
  rotateDeg: number;
  flipX?: boolean;
  /** Initial entrance vector before settling */
  fromY?: number;
  fromX?: number;
  fromScale?: number;
  fromRotateOffset?: number;
}

export const BOUQUET_FLORAL_PIECES: readonly BouquetPieceSpec[] = [
  // Step 1: Initial natural green rose leaves unfolding with the stems
  {
    id: 'leaf-base-left',
    minStep: 1,
    subDelayMs: 450,
    src: BOUQUET_ASSETS.roseLeaf,
    alt: 'Natural green rose leaves',
    leftPct: 33,
    topPct: 49,
    widthPct: 24,
    zIndex: 12,
    rotateDeg: -42,
    fromY: 16,
    fromScale: 0.45,
    fromRotateOffset: -14,
  },
  {
    id: 'leaf-base-right',
    minStep: 1,
    subDelayMs: 650,
    src: BOUQUET_ASSETS.roseLeaf,
    alt: 'Natural green rose leaves',
    leftPct: 68,
    topPct: 48,
    widthPct: 24,
    zIndex: 12,
    rotateDeg: 40,
    flipX: true,
    fromY: 16,
    fromScale: 0.45,
    fromRotateOffset: 14,
  },
  {
    id: 'leaf-base-top',
    minStep: 1,
    subDelayMs: 820,
    src: BOUQUET_ASSETS.roseLeaf,
    alt: 'Natural green foliage crown',
    leftPct: 51,
    topPct: 28,
    widthPct: 22,
    zIndex: 11,
    rotateDeg: 4,
    fromY: 18,
    fromScale: 0.5,
  },

  // Step 10: Outer eucalyptus & greenery branches (placed behind/around flowers in stage 10)
  {
    id: 'euc-upper-left',
    minStep: 10,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.eucalyptus,
    alt: 'Silver eucalyptus branch',
    leftPct: 30,
    topPct: 24,
    widthPct: 31,
    zIndex: 14,
    rotateDeg: -26,
    fromX: -14,
    fromY: 22,
    fromScale: 0.65,
    fromRotateOffset: -10,
  },
  {
    id: 'euc-upper-right',
    minStep: 10,
    subDelayMs: 220,
    src: BOUQUET_ASSETS.eucalyptus,
    alt: 'Silver eucalyptus branch',
    leftPct: 71,
    topPct: 23,
    widthPct: 31,
    zIndex: 14,
    rotateDeg: 26,
    flipX: true,
    fromX: 14,
    fromY: 22,
    fromScale: 0.65,
    fromRotateOffset: 10,
  },
  {
    id: 'sprig-outer-left',
    minStep: 10,
    subDelayMs: 440,
    src: BOUQUET_ASSETS.foliageSprig,
    alt: 'Green foliage branch',
    leftPct: 20,
    topPct: 42,
    widthPct: 27,
    zIndex: 16,
    rotateDeg: -42,
    fromX: -16,
    fromY: 14,
    fromScale: 0.65,
  },
  {
    id: 'sprig-outer-right',
    minStep: 10,
    subDelayMs: 650,
    src: BOUQUET_ASSETS.foliageSprig,
    alt: 'Green foliage branch',
    leftPct: 79,
    topPct: 44,
    widthPct: 27,
    zIndex: 16,
    rotateDeg: 40,
    flipX: true,
    fromX: 16,
    fromY: 14,
    fromScale: 0.65,
  },
  {
    id: 'leaf-collar-front',
    minStep: 10,
    subDelayMs: 840,
    src: BOUQUET_ASSETS.roseLeaf,
    alt: 'Fresh green rose leaf collar',
    leftPct: 50,
    topPct: 57,
    widthPct: 26,
    zIndex: 18,
    rotateDeg: 180,
    fromY: 12,
    fromScale: 0.6,
  },

  // Step 6 & Step 7: Soft pink tulips on left and right sides
  {
    id: 'tulip-left',
    minStep: 6,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.pinkTulipAngled,
    alt: 'Soft pink tulip on the left',
    leftPct: 25,
    topPct: 36,
    widthPct: 28,
    zIndex: 21,
    rotateDeg: -16,
    flipX: true,
    fromX: -16,
    fromY: 24,
    fromScale: 0.68,
    fromRotateOffset: -12,
  },
  {
    id: 'tulip-right',
    minStep: 7,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.pinkTulipFront,
    alt: 'Soft pink tulip on the right',
    leftPct: 71,
    topPct: 33,
    widthPct: 24,
    zIndex: 21,
    rotateDeg: 18,
    fromX: 16,
    fromY: 24,
    fromScale: 0.68,
    fromRotateOffset: 12,
  },

  // Step 9: Baby's breath & small white filler clusters staggered separately
  {
    id: 'babys-breath-upper-left',
    minStep: 9,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.babysBreath,
    alt: "Airy baby's breath cluster",
    leftPct: 33,
    topPct: 23,
    widthPct: 27,
    zIndex: 23,
    rotateDeg: -12,
    fromScale: 0.55,
    fromY: 10,
  },
  {
    id: 'babys-breath-upper-right',
    minStep: 9,
    subDelayMs: 320,
    src: BOUQUET_ASSETS.babysBreath,
    alt: "Airy baby's breath cluster",
    leftPct: 68,
    topPct: 25,
    widthPct: 25,
    zIndex: 23,
    rotateDeg: 28,
    fromScale: 0.55,
    fromX: 10,
  },
  {
    id: 'white-filler-right',
    minStep: 9,
    subDelayMs: 640,
    src: BOUQUET_ASSETS.whiteFiller,
    alt: 'Delicate white filler blossoms',
    leftPct: 78,
    topPct: 37,
    widthPct: 25,
    zIndex: 24,
    rotateDeg: 26,
    fromScale: 0.55,
    fromX: 10,
  },
  {
    id: 'white-filler-left',
    minStep: 9,
    subDelayMs: 960,
    src: BOUQUET_ASSETS.whiteFiller,
    alt: 'Delicate white filler blossoms',
    leftPct: 22,
    topPct: 48,
    widthPct: 24,
    zIndex: 24,
    rotateDeg: -34,
    flipX: true,
    fromScale: 0.55,
    fromX: -10,
  },

  // Step 5: Fourth flower (white rose higher crown)
  {
    id: 'rose-white-crown',
    minStep: 5,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.whiteRoseAngled,
    alt: 'Creamy white garden rose',
    leftPct: 48,
    topPct: 24,
    widthPct: 25,
    zIndex: 25,
    rotateDeg: -7,
    fromY: 22,
    fromScale: 0.58,
    fromRotateOffset: -10,
  },

  // Step 3: Second flower (white rose slightly left)
  {
    id: 'rose-white-left',
    minStep: 3,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.whiteRoseFront,
    alt: 'White garden rose',
    leftPct: 34,
    topPct: 38,
    widthPct: 26,
    zIndex: 28,
    rotateDeg: -8,
    fromX: -14,
    fromY: 18,
    fromScale: 0.55,
    fromRotateOffset: -12,
  },

  // Step 4: Third flower (pink rose on the right)
  {
    id: 'rose-pink-right',
    minStep: 4,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.pinkRoseAngled,
    alt: 'Blush-pink garden rose',
    leftPct: 67,
    topPct: 41,
    widthPct: 26,
    zIndex: 27,
    rotateDeg: 11,
    fromX: 14,
    fromY: 18,
    fromScale: 0.55,
    fromRotateOffset: 12,
  },

  // Step 2: First flower (large pink garden rose near center)
  {
    id: 'rose-pink-center',
    minStep: 2,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.pinkRoseFront,
    alt: 'Large pink garden rose',
    leftPct: 50,
    topPct: 40,
    widthPct: 29,
    zIndex: 31,
    rotateDeg: -3,
    fromY: 26,
    fromScale: 0.52,
    fromRotateOffset: -10,
  },

  // Step 8: Additional smaller roses tucked one by one for lush floral asymmetry
  {
    id: 'rose-extra-upper-right',
    minStep: 8,
    subDelayMs: 0,
    src: BOUQUET_ASSETS.pinkRoseFront,
    alt: 'Soft blush garden rose',
    leftPct: 60,
    topPct: 28,
    widthPct: 20,
    zIndex: 26,
    rotateDeg: 9,
    fromY: 18,
    fromScale: 0.54,
    fromRotateOffset: 10,
  },
  {
    id: 'rose-extra-lower-left',
    minStep: 8,
    subDelayMs: 420,
    src: BOUQUET_ASSETS.pinkRoseAngled,
    alt: 'Pink garden rose',
    leftPct: 33,
    topPct: 52,
    widthPct: 23,
    zIndex: 33,
    rotateDeg: -14,
    flipX: true,
    fromX: -12,
    fromY: 18,
    fromScale: 0.54,
  },
  {
    id: 'rose-extra-lower-right',
    minStep: 8,
    subDelayMs: 840,
    src: BOUQUET_ASSETS.whiteRoseFront,
    alt: 'Creamy ivory rose',
    leftPct: 64,
    topPct: 53,
    widthPct: 22,
    zIndex: 32,
    rotateDeg: 12,
    fromX: 12,
    fromY: 18,
    fromScale: 0.54,
  },
  {
    id: 'rose-extra-center-front',
    minStep: 8,
    subDelayMs: 1240,
    src: BOUQUET_ASSETS.pinkRoseFront,
    alt: 'Blush-pink garden rose',
    leftPct: 49,
    topPct: 55,
    widthPct: 24,
    zIndex: 34,
    rotateDeg: 4,
    fromY: 20,
    fromScale: 0.54,
  },
] as const;

export function getBouquetStageCaption(step: number): string {
  if (step <= 0) return 'Preparing your bouquet...';
  const match = BOUQUET_TIMELINE.find((item) => item.step === step);
  if (match) return match.caption;
  return 'A Bouquet for My Favorite Girl ♡';
}

export function getTotalBouquetDurationMs(): number {
  const last = BOUQUET_TIMELINE[BOUQUET_TIMELINE.length - 1];
  return last ? last.delayMs : 0;
}
