import {
  AnniversaryContent,
  AnniversaryProgress,
  ChapterId,
  FlowerId,
  GalleryPhoto,
  GallerySection,
} from '../types/anniversary';

export const TOTAL_FLOWERS = 5;

export function createDefaultContent(): AnniversaryContent {
  return {
    siteTitle: 'A Little World Made for Shaluu ♡',
    tagline: 'Three months of us, a thousand more to come.',
    theme: 'blush-sunrise',
    ownerPin: '',
    personal: {
      ownerName: 'Yours',
      herNickname: 'Shaluu',
      anniversaryDate: 'Three Months of Us',
      firstMeetingDate: '',
      ownerCityLabel: 'My City',
      herCityLabel: 'Your City',
    },
    chapter1: {
      anniversaryBadge: '03 MONTHS · ONE SPECIAL LOVE',
      heroHeading: 'Happy 3 Months, My Shaluu ♡',
      heroSubtitle:
        'A little world made for you, to celebrate three beautiful months of us.',
      anniversaryHighlightHeading: 'Happy 3-Month Anniversary, My Shaluu!',
      anniversarySupportingText:
        "Three months of smiles, little conversations, sweet moments, and a love that keeps growing.\n\nEven though different cities separate us, you have made these three months incredibly special.\n\nHere's a little world made just to celebrate YOU and US.",
      invitationText:
        'Hey, my Shaluu...\n\nI made a little world for you to wish you a happy three-month anniversary. Every flower, every word, and every little surprise inside is here to remind you how special you are to me.\n\nReady to open it, my Panda?',
      openButtonLabel: 'Open Your Little World ♡',
      welcomeMessage:
        "Happy three months, my love!\n\nI made this little world for you because you deserve more than an ordinary anniversary wish.\n\nThese three months have given me so many reasons to smile, and you have become such a beautiful part of my days.\n\nEven though we're in different cities, you've made the distance feel a little smaller and my world a lot sweeter.\n\nSo today, this little world is all yours.\n\nHappy three months, my Rasmalaiii. ♡",
      nextButtonLabel: "Let's Begin Our Little Story →",
    },
    chapter2: {
      heading: 'My Favorite Girl',
      subheading: 'The prettiest part of these three months.',
      handwrittenNote:
        'Every picture reminds me how lucky I am to adore you.',
      sections: [
        {
          id: 'section-smile',
          title: 'The Girl Who Makes Me Smile',
          subtitle: 'Featured photograph',
          layoutHint: 'featured',
          placeholderCaption:
            'Somehow, just seeing your smile makes my day better.',
          photos: [],
        },
        {
          id: 'section-pretty',
          title: 'My Pretty Shaluu',
          subtitle: 'Moments I cannot stop looking at',
          layoutHint: 'grid',
          placeholderCaption:
            'Every photo of you feels like a little piece of sunshine.',
          photos: [],
        },
        {
          id: 'section-little-things',
          title: 'Little Things I Adore',
          subtitle: 'Every expression, smile, and small detail',
          layoutHint: 'mini',
          placeholderCaption:
            'It is always the little expressions that make me fall for you a little more.',
          photos: [],
        },
        {
          id: 'section-forever-view',
          title: 'My Forever Favorite View',
          subtitle: 'Always my favorite',
          layoutHint: 'finale',
          placeholderCaption:
            'Out of all the beautiful things in this world, you will always be my favorite view.',
          photos: [],
        },
      ],
      closingLine:
        "That's my favorite girl. And somehow, I still find new reasons to adore you every day.",
      nextButtonLabel: "There's More, My Panda →",
    },
    chapter3: {
      heading: 'A Thousand Little Reasons',
      subheading:
        'Three months of finding more reasons every day to adore you—tap each bloom, open the letters tucked away, and do not forget your panda hug.',
      flowers: [
        {
          id: 'rose',
          name: 'Rose',
          message:
            'Every petal reminds me that loving you is one of my favorite things.',
        },
        {
          id: 'tulip',
          name: 'Tulip',
          message:
            'If I could send you one thing right now, it would be a bouquet big enough to carry all my love.',
        },
        {
          id: 'daisy',
          name: 'Daisy',
          message: 'You make even the simplest days feel special.',
        },
        {
          id: 'cherry_blossom',
          name: 'Cherry blossom',
          message:
            'Even from different cities, you make my world feel a little more beautiful.',
        },
        {
          id: 'sunflower',
          name: 'Sunflower',
          message:
            'Just like a sunflower follows the light, my thoughts always find their way to you.',
        },
      ],
      allCollectedMessage:
        'You collected every little flower! Just like you collect all the little pieces of my heart.',
      openWhenHeading: 'Open When... — Little Love Letters',
      openWhenSubheading:
        'Seven keepsake envelopes sealed with love for whatever kind of day you are having.',
      letters: [
        {
          id: 'open-miss-me',
          title: 'Open when you miss me.',
          body: "Hey my Shaluu,\n\nIf you opened this one, I hope you know I am probably missing you right back. Sometimes the space between our cities feels way too quiet, and all I want is to be right next to you without a phone screen in the way.\n\nTake a deep breath, look at our little sky, and remember you are never far from my thoughts. Text me, call me, or just hold onto this thought: I'm counting down to when missing you becomes seeing you.",
          signOff: 'Missing you too, always ♡',
        },
        {
          id: 'open-bad-day',
          title: 'Open when you are having a bad day.',
          body: "My sweet Rasmalaiii,\n\nI'm so sorry today has been heavy on you. Whatever wore you out or made you upset today, you do not have to carry it all by yourself.\n\nPut your shoulders down, drink some water, and let yourself rest. Tomorrow does not need you to be perfect—and neither do I. I am in your corner on the quiet days, the messy days, and every day in between.",
          signOff: 'Always cheering for you ♡',
        },
        {
          id: 'open-cant-sleep',
          title: 'Open when you cannot sleep.',
          body: "Hey sleepyhead Panda,\n\nIf your mind is still racing late at night, pretend I am on a soft call with you telling you that everything can wait until morning.\n\nClose your eyes, let your thoughts drift away one by one, and imagine a quiet starry sky keeping watch over both our cities tonight. Goodnight, my love. Sleep softly.",
          signOff: 'Sweetest dreams, Golumolu ♡',
        },
        {
          id: 'open-lonely',
          title: 'Open when you feel lonely.',
          body: "My Shaluu,\n\nLong distance can make even a crowded room feel quiet sometimes. If today feels a little lonely, I want you to remember that somewhere in another city, someone smiles just thinking about your name.\n\nYou have me—not just for the big anniversary days, but for the random Tuesday afternoons when you just want someone to listen. You are deeply, genuinely loved.",
          signOff: 'Right here with you ♡',
        },
        {
          id: 'open-need-hug',
          title: 'Open when you need a hug.',
          body: "My Golumolu,\n\nI know we haven't had our first real hug yet, and honestly, it is one of the things I look forward to the very most.\n\nUntil the day I finally get to stand in front of you and wrap my arms around you for real, close your eyes for a few seconds and take this little promise from me: our first hug is going to be worth every single mile and every single day we waited for it.",
          signOff: 'Saving the longest hug for you ♡',
        },
        {
          id: 'open-reminder',
          title: 'Open when you need a reminder of how much I love you.',
          body: "Hey, my favorite person,\n\nJust in case you ever forget for even half a second: I adore your voice, the way you brighten my ordinary days, and the warmth you bring into my life from miles away.\n\nChoosing you has been the easiest, sweetest thing. Three months feels like just the opening chapter, and I am so grateful it is you.",
          signOff: 'More than words can fit ♡',
        },
        {
          id: 'open-smile',
          title: 'Open when you need a reason to smile.',
          body: "Hello there, my cute Panda!\n\nReminder #1: You are officially someone's favorite person to think about.\nReminder #2: Somewhere out there, there is a bouquet with your name on it waiting for the day we meet.\nReminder #3: Even right now, just thinking of your smile makes me grin like an idiot.\n\nI hope that got at least one tiny smile out of you, Rasmalaiii.",
          signOff: 'Go smile in the mirror now ♡',
        },
      ],
      pandaHeading: 'A Little Panda Hug',
      pandaMessage:
        "Sending the biggest virtual hug to my Golumolu!\n\nI wish I could wrap my arms around you right now. Until the day I finally can, here's a little panda hug to remind you that you are loved.",
      pandaButtonLabel: 'Hug Me Again ♡',
      closingLine:
        'These were only a few of the thousand little reasons I adore you.',
      nextButtonLabel: 'One Last Surprise Awaits →',
    },
    chapter4: {
      heading: 'Until We Meet, My Panda',
      twoStarsTitle: 'Two different cities, one little universe of love.',
      bouquetTitle: 'A Bouquet for My Favorite Girl ♡',
      bouquetText:
        "If I could stand in front of you right now, I would bring you the prettiest bouquet I could find.\n\nI'd choose every flower carefully, just to see that beautiful smile of yours.\n\nUntil the day I can hand you real flowers, here's a little bouquet made with all my love.\n\nHappy three months, my Shaluu.",
      letterEnvelopeTitle: 'One Last Letter for My Shaluu ♡',
      finalLetterBody:
        "My dearest Shaluu,\n\nHappy three months, my Rasmalaiii.\n\nI wish I could be beside you today, holding a bouquet in one hand and your hand in the other. I wish I could see your smile in person, look into your eyes, and give you the longest hug.\n\nBut for now, we have our little messages, our calls, our smiles through screens, and all the beautiful moments we are still waiting to create.\n\nEven though we haven't met face to face yet, you have become someone incredibly special to me. The distance may keep us in different cities, but it doesn't stop you from being a part of my everyday thoughts.\n\nThank you for being my Shaluu, my Panda, my Golumolu, and my favorite person to adore.\n\nI don't know every detail of what the future holds, but I know there are so many beautiful things I want to experience with you.\n\nOne day, there will be no screen between us. No goodnight message followed by a distant goodbye. Just you and me, finally together, and that first real hug I've been looking forward to.\n\nUntil then, I hope this little world reminds you how much you mean to me.\n\nThree months down. So many beautiful chapters still waiting for us.\n\nI love you, my Panda.",
      finalLetterSignature: 'Always yours. ♡',
      closingAnniversaryHeading: 'Happy Three Months, My Shaluu ♡',
      closingTitle: 'To be continued...',
      closingSubtitle:
        'Three months down. A lifetime of beautiful chapters to look forward to.',
      replayButtonLabel: 'Replay Our Little World ♡',
    },
    music: {
      songTitle: 'Our Song',
      artistName: 'Playing for Shaluu',
      youtubeVideoId: 'n90OVV69e9A',
      startSeconds: 29,
    },
  };
}

export function createDefaultProgress(): AnniversaryProgress {
  return {
    chapter1Opened: false,
    highestUnlockedChapter: 1,
    collectedFlowers: [],
    openedLetters: [],
    pandaHugCount: 0,
    bouquetAssembled: false,
    finalLetterOpened: false,
  };
}

export function clampChapter(value: number): ChapterId {
  if (value <= 1) return 1;
  if (value === 2) return 2;
  if (value === 3) return 3;
  return 4;
}

export function collectFlower(
  progress: AnniversaryProgress,
  flowerId: FlowerId
): {
  progress: AnniversaryProgress;
  newlyCollected: boolean;
  allCollected: boolean;
} {
  const alreadyCollected = progress.collectedFlowers.includes(flowerId);
  const nextCollected = alreadyCollected
    ? progress.collectedFlowers
    : [...progress.collectedFlowers, flowerId];

  return {
    progress: {
      ...progress,
      collectedFlowers: nextCollected,
    },
    newlyCollected: !alreadyCollected,
    allCollected: nextCollected.length >= TOTAL_FLOWERS,
  };
}

export function markLetterOpened(
  progress: AnniversaryProgress,
  letterId: string
): AnniversaryProgress {
  if (progress.openedLetters.includes(letterId)) {
    return progress;
  }
  return {
    ...progress,
    openedLetters: [...progress.openedLetters, letterId],
  };
}

export function addPhotoToSection(
  sections: GallerySection[],
  sectionId: string,
  photo: GalleryPhoto
): GallerySection[] {
  return sections.map((section) => {
    if (section.id !== sectionId) return section;
    const nextPhotos = photo.isFeatured
      ? section.photos.map((p) => ({ ...p, isFeatured: false }))
      : section.photos;
    return {
      ...section,
      photos: [...nextPhotos, photo],
    };
  });
}

export function replacePhotoInSection(
  sections: GallerySection[],
  sectionId: string,
  photoId: string,
  newDataUrl: string,
  fileName: string
): GallerySection[] {
  return sections.map((section) => {
    if (section.id !== sectionId) return section;
    return {
      ...section,
      photos: section.photos.map((photo) =>
        photo.id === photoId
          ? {
              ...photo,
              dataUrl: newDataUrl,
              fileName,
              addedAt: new Date().toISOString(),
            }
          : photo
      ),
    };
  });
}

export function deletePhotoFromSection(
  sections: GallerySection[],
  sectionId: string,
  photoId: string
): GallerySection[] {
  return sections.map((section) => {
    if (section.id !== sectionId) return section;
    return {
      ...section,
      photos: section.photos.filter((photo) => photo.id !== photoId),
    };
  });
}

export function reorderPhotoInSection(
  sections: GallerySection[],
  sectionId: string,
  photoId: string,
  direction: 'up' | 'down'
): GallerySection[] {
  return sections.map((section) => {
    if (section.id !== sectionId) return section;
    const idx = section.photos.findIndex((p) => p.id === photoId);
    if (idx === -1) return section;
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= section.photos.length) return section;
    const copy = [...section.photos];
    const [item] = copy.splice(idx, 1);
    copy.splice(targetIdx, 0, item);
    return {
      ...section,
      photos: copy,
    };
  });
}

export function updatePhotoDetails(
  sections: GallerySection[],
  sectionId: string,
  photoId: string,
  patch: Partial<Pick<GalleryPhoto, 'caption' | 'alt' | 'isFeatured'>>
): GallerySection[] {
  return sections.map((section) => {
    if (section.id !== sectionId) return section;
    return {
      ...section,
      photos: section.photos.map((photo) => {
        if (photo.id === photoId) {
          return { ...photo, ...patch };
        }
        if (patch.isFeatured) {
          return { ...photo, isFeatured: false };
        }
        return photo;
      }),
    };
  });
}

export function addGallerySection(
  sections: GallerySection[],
  title: string,
  subtitle = 'More favorite moments'
): GallerySection[] {
  const cleanTitle = title.trim();
  if (!cleanTitle) return sections;
  const id = `section-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  return [
    ...sections,
    {
      id,
      title: cleanTitle,
      subtitle,
      layoutHint: 'grid',
      placeholderCaption: 'Add photographs to celebrate this moment together.',
      photos: [],
    },
  ];
}

export function removeGallerySection(
  sections: GallerySection[],
  sectionId: string
): GallerySection[] {
  if (sections.length <= 1) return sections;
  return sections.filter((section) => section.id !== sectionId);
}

export function updateGallerySection(
  sections: GallerySection[],
  sectionId: string,
  patch: Partial<Pick<GallerySection, 'title' | 'subtitle' | 'placeholderCaption'>>
): GallerySection[] {
  return sections.map((section) =>
    section.id === sectionId ? { ...section, ...patch } : section
  );
}

export function getAllGalleryPhotos(sections: GallerySection[]): Array<{
  photo: GalleryPhoto;
  sectionId: string;
  sectionTitle: string;
}> {
  const list: Array<{
    photo: GalleryPhoto;
    sectionId: string;
    sectionTitle: string;
  }> = [];
  for (const section of sections) {
    for (const photo of section.photos) {
      list.push({
        photo,
        sectionId: section.id,
        sectionTitle: section.title,
      });
    }
  }
  return list;
}

export function extractYouTubeVideoId(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return '';
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  try {
    const url = new URL(trimmed);
    if (url.hostname.includes('youtu.be')) {
      return url.pathname.replace('/', '').slice(0, 11);
    }
    const vParam = url.searchParams.get('v');
    if (vParam) return vParam.slice(0, 11);
  } catch {
    // fallback if partial text
  }
  return trimmed;
}

export function parseCustomizationImport(
  rawJson: string
): { ok: true; content: AnniversaryContent } | { ok: false; error: string } {
  try {
    const parsed = JSON.parse(rawJson) as Partial<AnniversaryContent>;
    if (!parsed || typeof parsed !== 'object') {
      return { ok: false, error: 'Invalid backup format.' };
    }
    const base = createDefaultContent();
    const merged: AnniversaryContent = {
      ...base,
      ...parsed,
      personal: { ...base.personal, ...(parsed.personal ?? {}) },
      chapter1: { ...base.chapter1, ...(parsed.chapter1 ?? {}) },
      chapter2: {
        ...base.chapter2,
        ...(parsed.chapter2 ?? {}),
        sections: Array.isArray(parsed.chapter2?.sections)
          ? parsed.chapter2.sections
          : base.chapter2.sections,
      },
      chapter3: {
        ...base.chapter3,
        ...(parsed.chapter3 ?? {}),
        flowers: Array.isArray(parsed.chapter3?.flowers)
          ? parsed.chapter3.flowers
          : base.chapter3.flowers,
        letters: Array.isArray(parsed.chapter3?.letters)
          ? parsed.chapter3.letters
          : base.chapter3.letters,
      },
      chapter4: { ...base.chapter4, ...(parsed.chapter4 ?? {}) },
      music: { ...base.music, ...(parsed.music ?? {}) },
    };
    return { ok: true, content: merged };
  } catch {
    return { ok: false, error: 'Could not read JSON backup file.' };
  }
}
