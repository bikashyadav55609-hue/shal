import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addGallerySection,
  addPhotoToSection,
  clampChapter,
  collectFlower,
  createDefaultContent,
  createDefaultProgress,
  deletePhotoFromSection,
  extractYouTubeVideoId,
  parseCustomizationImport,
  removeGallerySection,
  reorderPhotoInSection,
  replacePhotoInSection,
  updatePhotoDetails,
} from './anniversaryStore';
import { GalleryPhoto } from '../types/anniversary';

test('default content highlights Three-Month Anniversary and preserves relationship context', () => {
  const content = createDefaultContent();
  assert.equal(content.siteTitle, 'A Little World Made for Shaluu ♡');
  assert.equal(content.chapter1.heroHeading, 'Happy 3 Months, My Shaluu ♡');
  assert.equal(content.chapter1.anniversaryBadge, '03 MONTHS · ONE SPECIAL LOVE');
  assert.equal(content.chapter4.bouquetTitle, 'A Bouquet for My Favorite Girl ♡');
  assert.equal(content.chapter4.closingAnniversaryHeading, 'Happy Three Months, My Shaluu ♡');
  assert.equal(content.music.youtubeVideoId, 'n90OVV69e9A');
  assert.equal(content.music.startSeconds, 29);
  assert.equal(content.chapter2.sections.length, 4);
  assert.equal(content.chapter3.flowers.length, 5);
  assert.equal(content.chapter3.letters.length, 7);

  const fullText = JSON.stringify(content);
  for (const nickname of ['Shaluu', 'Rasmalaiii', 'Panda', 'Golumolu']) {
    assert.ok(fullText.includes(nickname), `Missing nickname: ${nickname}`);
  }
  for (const section of content.chapter2.sections) {
    assert.equal(section.photos.length, 0);
  }
});

test('collectFlower tracks progress cleanly without duplicates and detects completion', () => {
  let progress = createDefaultProgress();

  const first = collectFlower(progress, 'rose');
  assert.equal(first.newlyCollected, true);
  assert.equal(first.allCollected, false);
  assert.equal(first.progress.collectedFlowers.length, 1);

  const duplicate = collectFlower(first.progress, 'rose');
  assert.equal(duplicate.newlyCollected, false);
  assert.equal(duplicate.progress.collectedFlowers.length, 1);

  progress = duplicate.progress;
  progress = collectFlower(progress, 'tulip').progress;
  progress = collectFlower(progress, 'daisy').progress;
  progress = collectFlower(progress, 'cherry_blossom').progress;
  const fifth = collectFlower(progress, 'sunflower');

  assert.equal(fifth.newlyCollected, true);
  assert.equal(fifth.allCollected, true);
  assert.equal(fifth.progress.collectedFlowers.length, 5);
});

test('gallery photo CRUD, reorder, and featured toggle work deterministically', () => {
  const content = createDefaultContent();
  let sections = content.chapter2.sections;
  const sectionId = sections[1].id;

  const photoA: GalleryPhoto = {
    id: 'p1',
    dataUrl: 'data:image/png;base64,AAA',
    fileName: 'a.png',
    caption: 'First',
    alt: 'First',
    isFeatured: false,
    addedAt: '2026-11-16T00:00:00Z',
  };
  const photoB: GalleryPhoto = {
    id: 'p2',
    dataUrl: 'data:image/png;base64,BBB',
    fileName: 'b.png',
    caption: 'Second',
    alt: 'Second',
    isFeatured: true,
    addedAt: '2026-11-16T00:01:00Z',
  };

  sections = addPhotoToSection(sections, sectionId, photoA);
  sections = addPhotoToSection(sections, sectionId, photoB);
  assert.equal(sections[1].photos.length, 2);

  sections = reorderPhotoInSection(sections, sectionId, 'p2', 'up');
  assert.deepEqual(
    sections[1].photos.map((p) => p.id),
    ['p2', 'p1']
  );

  sections = updatePhotoDetails(sections, sectionId, 'p1', {
    isFeatured: true,
    caption: 'Updated',
  });
  assert.equal(sections[1].photos.find((p) => p.id === 'p1')?.isFeatured, true);
  assert.equal(sections[1].photos.find((p) => p.id === 'p1')?.caption, 'Updated');
  assert.equal(sections[1].photos.find((p) => p.id === 'p2')?.isFeatured, false);

  sections = replacePhotoInSection(
    sections,
    sectionId,
    'p2',
    'data:image/png;base64,CCC',
    'c.png'
  );
  assert.equal(sections[1].photos.find((p) => p.id === 'p2')?.fileName, 'c.png');

  sections = deletePhotoFromSection(sections, sectionId, 'p2');
  assert.equal(sections[1].photos.length, 1);

  sections = addGallerySection(sections, 'Extra Moments');
  assert.equal(sections.length, 5);
  const addedId = sections[4].id;
  sections = removeGallerySection(sections, addedId);
  assert.equal(sections.length, 4);
});

test('clampChapter, extractYouTubeVideoId, and parseCustomizationImport behave safely', () => {
  assert.equal(clampChapter(0), 1);
  assert.equal(clampChapter(2), 2);
  assert.equal(clampChapter(99), 4);

  assert.equal(
    extractYouTubeVideoId('https://youtu.be/n90OVV69e9A?t=29'),
    'n90OVV69e9A'
  );
  assert.equal(
    extractYouTubeVideoId('https://www.youtube.com/watch?v=n90OVV69e9A&t=29s'),
    'n90OVV69e9A'
  );
  assert.equal(extractYouTubeVideoId('n90OVV69e9A'), 'n90OVV69e9A');

  const badImport = parseCustomizationImport('{broken json');
  assert.equal(badImport.ok, false);

  const goodImport = parseCustomizationImport(
    JSON.stringify({ personal: { ownerName: 'Aarav', herNickname: 'Shaluu' } })
  );
  assert.equal(goodImport.ok, true);
  if (goodImport.ok) {
    assert.equal(goodImport.content.personal.ownerName, 'Aarav');
    assert.equal(goodImport.content.chapter3.flowers.length, 5);
  }
});
