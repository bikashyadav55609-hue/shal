import test from 'node:test';
import assert from 'node:assert/strict';
import {
  BOUQUET_ASSETS,
  BOUQUET_FINAL_STEP,
  BOUQUET_FLORAL_PIECES,
  BOUQUET_TIMELINE,
  getBouquetStageCaption,
  getTotalBouquetDurationMs,
} from './bouquetTimeline';

test('bouquet timeline spans 10-14 seconds with strictly increasing steps 1..13', () => {
  const duration = getTotalBouquetDurationMs();
  assert.ok(duration >= 10000 && duration <= 14000, `Expected 10-14s, got ${duration}`);
  assert.equal(BOUQUET_TIMELINE[0].step, 1);
  assert.equal(BOUQUET_TIMELINE[BOUQUET_TIMELINE.length - 1].step, BOUQUET_FINAL_STEP);

  for (let i = 1; i < BOUQUET_TIMELINE.length; i++) {
    assert.ok(
      BOUQUET_TIMELINE[i].delayMs > BOUQUET_TIMELINE[i - 1].delayMs,
      `Step ${BOUQUET_TIMELINE[i].step} must happen after step ${BOUQUET_TIMELINE[i - 1].step}`
    );
    assert.equal(BOUQUET_TIMELINE[i].step, BOUQUET_TIMELINE[i - 1].step + 1);
  }
});

test('all 11 required individual botanical PNG assets are referenced in bouquet pieces', () => {
  const usedSrcs = new Set(BOUQUET_FLORAL_PIECES.map((p) => p.src));
  for (const [key, src] of Object.entries(BOUQUET_ASSETS)) {
    assert.ok(src.endsWith('.png'), `${key} should be a transparent .png asset`);
    assert.ok(usedSrcs.has(src), `${key} (${src}) must be used in BOUQUET_FLORAL_PIECES`);
  }
});

test('step 0 returns empty-start caption and step 13 returns final reveal title', () => {
  assert.match(getBouquetStageCaption(0), /Preparing/i);
  assert.match(getBouquetStageCaption(13), /A Bouquet for My Favorite Girl/i);
});
