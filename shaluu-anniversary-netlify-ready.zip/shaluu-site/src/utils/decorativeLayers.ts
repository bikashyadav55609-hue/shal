import { ChapterId } from '../types/anniversary';

export interface OrbSpec {
  id: string;
  positionClass: string;
  sizeClass: string;
  colorVar: string;
  alpha: number;
  duration: string;
  delay: string;
  driftX: string;
  driftY: string;
  scale: string;
  mobileVisible: boolean;
}

export interface FloatingHeartSpec {
  id: string;
  left: string;
  size: number;
  duration: string;
  delay: string;
  swayA: string;
  swayB: string;
  opacity: number;
  colorVar: string;
  mobileVisible: boolean;
}

export interface SparkleSpec {
  id: string;
  left: string;
  top: string;
  duration: string;
  delay: string;
  colorVar: string;
  mobileVisible: boolean;
}

export interface ChapterDecorativeVars {
  '--decor-orb-opacity': string;
  '--decor-heart-opacity': string;
  '--decor-sparkle-opacity': string;
}

export const DECORATIVE_ORB_SPECS: OrbSpec[] = [
  {
    id: 'champagne-nw',
    positionClass: '-top-24 -left-20',
    sizeClass: 'h-72 w-72 sm:h-96 sm:w-96',
    colorVar: 'var(--theme-champagne)',
    alpha: 0.52,
    duration: '19s',
    delay: '0s',
    driftX: '28px',
    driftY: '-18px',
    scale: '1.08',
    mobileVisible: true,
  },
  {
    id: 'rose-east',
    positionClass: 'top-[28%] -right-24',
    sizeClass: 'h-80 w-80 sm:h-[26rem] sm:w-[26rem]',
    colorVar: 'var(--theme-rose)',
    alpha: 0.34,
    duration: '23s',
    delay: '-7s',
    driftX: '-24px',
    driftY: '20px',
    scale: '1.1',
    mobileVisible: true,
  },
  {
    id: 'peach-south',
    positionClass: '-bottom-24 left-[22%]',
    sizeClass: 'h-72 w-72 sm:h-96 sm:w-96',
    colorVar: 'var(--theme-peach)',
    alpha: 0.38,
    duration: '21s',
    delay: '-12s',
    driftX: '22px',
    driftY: '-24px',
    scale: '1.07',
    mobileVisible: true,
  },
  {
    id: 'gold-halo-center',
    positionClass: 'top-[12%] left-[42%]',
    sizeClass: 'h-64 w-64 sm:h-80 sm:w-80',
    colorVar: 'var(--theme-gold)',
    alpha: 0.18,
    duration: '26s',
    delay: '-4s',
    driftX: '-18px',
    driftY: '16px',
    scale: '1.06',
    mobileVisible: false,
  },
];

export const DECORATIVE_HEART_SPECS: FloatingHeartSpec[] = [
  {
    id: 'heart-1',
    left: '10%',
    size: 11,
    duration: '24s',
    delay: '-4s',
    swayA: '14px',
    swayB: '-10px',
    opacity: 0.36,
    colorVar: 'var(--theme-dusty-rose)',
    mobileVisible: true,
  },
  {
    id: 'heart-2',
    left: '26%',
    size: 9,
    duration: '28s',
    delay: '-13s',
    swayA: '-12px',
    swayB: '16px',
    opacity: 0.3,
    colorVar: 'var(--theme-rose)',
    mobileVisible: false,
  },
  {
    id: 'heart-3',
    left: '48%',
    size: 10,
    duration: '26s',
    delay: '-18s',
    swayA: '12px',
    swayB: '-14px',
    opacity: 0.32,
    colorVar: 'var(--theme-accent)',
    mobileVisible: false,
  },
  {
    id: 'heart-4',
    left: '67%',
    size: 12,
    duration: '23s',
    delay: '-9s',
    swayA: '-16px',
    swayB: '12px',
    opacity: 0.35,
    colorVar: 'var(--theme-dusty-rose)',
    mobileVisible: false,
  },
  {
    id: 'heart-5',
    left: '86%',
    size: 11,
    duration: '25s',
    delay: '-15s',
    swayA: '14px',
    swayB: '-12px',
    opacity: 0.34,
    colorVar: 'var(--theme-rose)',
    mobileVisible: true,
  },
];

export const DECORATIVE_SPARKLE_SPECS: SparkleSpec[] = [
  {
    id: 'sparkle-1',
    left: '8%',
    top: '16%',
    duration: '3.4s',
    delay: '0.2s',
    colorVar: 'var(--theme-gold)',
    mobileVisible: true,
  },
  {
    id: 'sparkle-2',
    left: '24%',
    top: '34%',
    duration: '4.1s',
    delay: '1.1s',
    colorVar: 'var(--theme-surface)',
    mobileVisible: false,
  },
  {
    id: 'sparkle-3',
    left: '42%',
    top: '12%',
    duration: '3.7s',
    delay: '0.8s',
    colorVar: 'var(--theme-gold)',
    mobileVisible: true,
  },
  {
    id: 'sparkle-4',
    left: '66%',
    top: '24%',
    duration: '3.9s',
    delay: '1.9s',
    colorVar: 'var(--theme-surface)',
    mobileVisible: false,
  },
  {
    id: 'sparkle-5',
    left: '84%',
    top: '18%',
    duration: '3.5s',
    delay: '0.5s',
    colorVar: 'var(--theme-gold)',
    mobileVisible: true,
  },
  {
    id: 'sparkle-6',
    left: '92%',
    top: '52%',
    duration: '4.2s',
    delay: '1.5s',
    colorVar: 'var(--theme-gold)',
    mobileVisible: false,
  },
  {
    id: 'sparkle-7',
    left: '14%',
    top: '68%',
    duration: '3.8s',
    delay: '2.1s',
    colorVar: 'var(--theme-surface)',
    mobileVisible: false,
  },
  {
    id: 'sparkle-8',
    left: '76%',
    top: '76%',
    duration: '3.6s',
    delay: '0.9s',
    colorVar: 'var(--theme-gold)',
    mobileVisible: true,
  },
];

export function getChapterDecorativeVars(
  chapter: ChapterId
): ChapterDecorativeVars {
  switch (chapter) {
    case 1:
      return {
        '--decor-orb-opacity': '0.92',
        '--decor-heart-opacity': '0.88',
        '--decor-sparkle-opacity': '0.82',
      };
    case 2:
      return {
        '--decor-orb-opacity': '0.84',
        '--decor-heart-opacity': '0.8',
        '--decor-sparkle-opacity': '0.75',
      };
    case 3:
      return {
        '--decor-orb-opacity': '0.9',
        '--decor-heart-opacity': '0.95',
        '--decor-sparkle-opacity': '0.88',
      };
    case 4:
      return {
        '--decor-orb-opacity': '1',
        '--decor-heart-opacity': '1',
        '--decor-sparkle-opacity': '1',
      };
  }
}
