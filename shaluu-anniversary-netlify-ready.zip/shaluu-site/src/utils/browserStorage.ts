import {
  AnniversaryContent,
  AnniversaryProgress,
  GallerySection,
} from '../types/anniversary';
import {
  createDefaultContent,
  createDefaultProgress,
} from './anniversaryStore';

const CONTENT_STORAGE_KEY = 'shaluu_anniversary_content_v2';
const PROGRESS_STORAGE_KEY = 'shaluu_anniversary_progress_v2';
const IDB_NAME = 'shaluu_anniversary_db';
const IDB_STORE = 'photos';
const IDB_PHOTOS_KEY = 'gallery_sections_photos_v1';

export interface StorageSaveResult {
  ok: boolean;
  warning?: string;
}

function openPhotoDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const request = indexedDB.open(IDB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('IndexedDB error'));
  });
}

async function savePhotosToIndexedDB(
  sections: GallerySection[]
): Promise<StorageSaveResult> {
  try {
    const db = await openPhotoDatabase();
    return await new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      const photoMap: Record<string, GallerySection['photos']> = {};
      for (const section of sections) {
        photoMap[section.id] = section.photos;
      }
      store.put(photoMap, IDB_PHOTOS_KEY);
      tx.oncomplete = () => {
        db.close();
        resolve({ ok: true });
      };
      tx.onerror = () => {
        db.close();
        resolve({
          ok: false,
          warning:
            'Browser photo storage is full or restricted. Try using slightly smaller images or exporting a backup.',
        });
      };
    });
  } catch {
    return {
      ok: false,
      warning:
        'IndexedDB is unavailable in this browser session. Photos may not persist after refresh.',
    };
  }
}

async function loadPhotosFromIndexedDB(): Promise<
  Record<string, GallerySection['photos']> | null
> {
  try {
    const db = await openPhotoDatabase();
    return await new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(IDB_PHOTOS_KEY);
      req.onsuccess = () => {
        db.close();
        resolve(
          (req.result as Record<string, GallerySection['photos']>) ?? null
        );
      };
      req.onerror = () => {
        db.close();
        resolve(null);
      };
    });
  } catch {
    return null;
  }
}

export async function loadPersistedContent(): Promise<AnniversaryContent> {
  const base = createDefaultContent();
  try {
    const raw = localStorage.getItem(CONTENT_STORAGE_KEY);
    let merged = base;
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<AnniversaryContent>;
      merged = {
        ...base,
        ...parsed,
        personal: { ...base.personal, ...(parsed.personal ?? {}) },
        chapter1: { ...base.chapter1, ...(parsed.chapter1 ?? {}) },
        chapter2: {
          ...base.chapter2,
          ...(parsed.chapter2 ?? {}),
          sections: Array.isArray(parsed.chapter2?.sections)
            ? parsed.chapter2.sections
            : base.chapter2.sections,
        },
        chapter3: {
          ...base.chapter3,
          ...(parsed.chapter3 ?? {}),
          flowers: Array.isArray(parsed.chapter3?.flowers)
            ? parsed.chapter3.flowers
            : base.chapter3.flowers,
          letters: Array.isArray(parsed.chapter3?.letters)
            ? parsed.chapter3.letters
            : base.chapter3.letters,
        },
        chapter4: { ...base.chapter4, ...(parsed.chapter4 ?? {}) },
        music: { ...base.music, ...(parsed.music ?? {}) },
      };
    }

    const photoMap = await loadPhotosFromIndexedDB();
    if (photoMap) {
      merged = {
        ...merged,
        chapter2: {
          ...merged.chapter2,
          sections: merged.chapter2.sections.map((section) => ({
            ...section,
            photos: Array.isArray(photoMap[section.id])
              ? photoMap[section.id]
              : section.photos,
          })),
        },
      };
    }

    return merged;
  } catch {
    return base;
  }
}

export async function savePersistedContent(
  content: AnniversaryContent
): Promise<StorageSaveResult> {
  const idbResult = await savePhotosToIndexedDB(content.chapter2.sections);

  const lightweightContent: AnniversaryContent = {
    ...content,
    chapter2: {
      ...content.chapter2,
      sections: content.chapter2.sections.map((section) => ({
        ...section,
        photos: idbResult.ok ? [] : section.photos,
      })),
    },
  };

  try {
    localStorage.setItem(
      CONTENT_STORAGE_KEY,
      JSON.stringify(lightweightContent)
    );
    return idbResult;
  } catch {
    return {
      ok: false,
      warning:
        'Browser storage quota exceeded. Please reduce photo file sizes or clear unused photos.',
    };
  }
}

export function loadPersistedProgress(): AnniversaryProgress {
  const base = createDefaultProgress();
  try {
    const raw = localStorage.getItem(PROGRESS_STORAGE_KEY);
    if (!raw) return base;
    const parsed = JSON.parse(raw) as Partial<AnniversaryProgress>;
    return {
      ...base,
      ...parsed,
      collectedFlowers: Array.isArray(parsed.collectedFlowers)
        ? parsed.collectedFlowers
        : base.collectedFlowers,
      openedLetters: Array.isArray(parsed.openedLetters)
        ? parsed.openedLetters
        : base.openedLetters,
    };
  } catch {
    return base;
  }
}

export function savePersistedProgress(progress: AnniversaryProgress): void {
  try {
    localStorage.setItem(PROGRESS_STORAGE_KEY, JSON.stringify(progress));
  } catch {
    // Ignore minor storage failures for progress
  }
}

export async function readImageFileAsDataUrl(file: File): Promise<string> {
  const allowedTypes = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
  ];
  if (file.type && !allowedTypes.includes(file.type.toLowerCase())) {
    throw new Error('Please upload JPG, JPEG, PNG, or WebP images only.');
  }

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Could not read selected image file.'));
      }
    };
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.readAsDataURL(file);
  });
}
