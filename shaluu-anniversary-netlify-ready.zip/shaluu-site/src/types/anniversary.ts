export type ThemeId = 'blush-sunrise' | 'lavender-meadow' | 'peach-blossom';

export type ChapterId = 1 | 2 | 3 | 4;

export type FlowerId =
  | 'rose'
  | 'tulip'
  | 'daisy'
  | 'cherry_blossom'
  | 'sunflower';

export interface GalleryPhoto {
  id: string;
  dataUrl: string;
  fileName: string;
  caption: string;
  alt: string;
  isFeatured: boolean;
  addedAt: string;
}

export interface GallerySection {
  id: string;
  title: string;
  subtitle: string;
  layoutHint: 'featured' | 'grid' | 'mini' | 'finale';
  placeholderCaption: string;
  photos: GalleryPhoto[];
}

export interface FlowerItem {
  id: FlowerId;
  name: string;
  message: string;
}

export interface OpenWhenLetter {
  id: string;
  title: string;
  body: string;
  signOff: string;
}

export interface MusicConfig {
  songTitle: string;
  artistName: string;
  youtubeVideoId: string;
  startSeconds: number;
}

export interface PersonalDetails {
  ownerName: string;
  herNickname: string;
  anniversaryDate: string;
  firstMeetingDate: string;
  ownerCityLabel: string;
  herCityLabel: string;
}

export interface AnniversaryContent {
  siteTitle: string;
  tagline: string;
  theme: ThemeId;
  ownerPin: string;
  personal: PersonalDetails;
  chapter1: {
    anniversaryBadge: string;
    heroHeading: string;
    heroSubtitle: string;
    anniversaryHighlightHeading: string;
    anniversarySupportingText: string;
    invitationText: string;
    openButtonLabel: string;
    welcomeMessage: string;
    nextButtonLabel: string;
  };
  chapter2: {
    heading: string;
    subheading: string;
    handwrittenNote: string;
    sections: GallerySection[];
    closingLine: string;
    nextButtonLabel: string;
  };
  chapter3: {
    heading: string;
    subheading: string;
    flowers: FlowerItem[];
    allCollectedMessage: string;
    openWhenHeading: string;
    openWhenSubheading: string;
    letters: OpenWhenLetter[];
    pandaHeading: string;
    pandaMessage: string;
    pandaButtonLabel: string;
    closingLine: string;
    nextButtonLabel: string;
  };
  chapter4: {
    heading: string;
    twoStarsTitle: string;
    bouquetTitle: string;
    bouquetText: string;
    letterEnvelopeTitle: string;
    finalLetterBody: string;
    finalLetterSignature: string;
    closingAnniversaryHeading: string;
    closingTitle: string;
    closingSubtitle: string;
    replayButtonLabel: string;
  };
  music: MusicConfig;
}

export interface AnniversaryProgress {
  chapter1Opened: boolean;
  highestUnlockedChapter: ChapterId;
  collectedFlowers: FlowerId[];
  openedLetters: string[];
  pandaHugCount: number;
  bouquetAssembled: boolean;
  finalLetterOpened: boolean;
}
