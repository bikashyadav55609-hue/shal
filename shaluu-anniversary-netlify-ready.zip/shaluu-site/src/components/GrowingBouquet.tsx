import React from 'react';
import { motion } from 'motion/react';
import { FlowerId } from '../types/anniversary';
import { TOTAL_FLOWERS } from '../utils/anniversaryStore';

interface GrowingBouquetProps {
  collectedFlowers: FlowerId[];
  allCollectedMessage: string;
}

export const GrowingBouquet: React.FC<GrowingBouquetProps> = ({
  collectedFlowers,
  allCollectedMessage,
}) => {
  const count = collectedFlowers.length;
  const hasRose = collectedFlowers.includes('rose');
  const hasTulip = collectedFlowers.includes('tulip');
  const hasDaisy = collectedFlowers.includes('daisy');
  const hasSakura = collectedFlowers.includes('cherry_blossom');
  const hasSunflower = collectedFlowers.includes('sunflower');
  const allCollected = count >= TOTAL_FLOWERS;

  return (
    <div
      className="stationery-panel paper-texture relative flex flex-col items-center overflow-hidden rounded-3xl p-6 text-center sm:p-8"
      data-testid="growing-bouquet"
      data-collected-count={count}
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D8B477]/30"
      />

      <p className="relative z-10 text-[11px] font-semibold tracking-[0.2em] text-[#A94F70] uppercase">
        Your Growing Bouquet
      </p>
      <h3 className="font-serif-display relative z-10 mt-1 text-2xl font-semibold text-[#50313F]">
        Collect Your Flowers ({count}/{TOTAL_FLOWERS})
      </h3>

      <div className="relative z-10 my-4 flex h-64 w-56 items-center justify-center">
        <svg
          viewBox="0 0 220 245"
          fill="none"
          className="h-full w-full drop-shadow-xs"
          aria-label={`Flower vase containing ${count} of ${TOTAL_FLOWERS} collected flowers`}
        >
          <defs>
            <linearGradient id="porcelainVase" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#F8DCE4" />
              <stop offset="45%" stopColor="#FFF7F2" />
              <stop offset="100%" stopColor="#F2CAD6" />
            </linearGradient>
          </defs>

          {allCollected && (
            <circle cx="110" cy="94" r="82" fill="#F4C6D0" opacity="0.45" />
          )}

          {/* Sage eucalyptus greenery in vase */}
          <path
            d="M110 154 C96 122, 82 98, 70 76"
            stroke="#87A384"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <path
            d="M110 154 C124 122, 138 98, 150 76"
            stroke="#87A384"
            strokeWidth="3"
            strokeLinecap="round"
          />
          <ellipse cx="64" cy="98" rx="11" ry="6" transform="rotate(-25 64 98)" fill="#A4B99A" />
          <ellipse cx="156" cy="98" rx="11" ry="6" transform="rotate(25 156 98)" fill="#94AC8B" />

          {/* 1. Cherry blossom */}
          {hasSakura && (
            <motion.g
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: '68px 66px' }}
            >
              <path
                d="M104 150 C88 122, 74 92, 68 66"
                stroke="#856965"
                strokeWidth="3"
                strokeLinecap="round"
              />
              {[0, 72, 144, 216, 288].map((a) => (
                <path
                  key={a}
                  d="M68 66 C61 55, 60 47, 66 46 L68 49 L70 46 C76 47, 75 55, 68 66 Z"
                  fill="#FAD6E0"
                  stroke="#E79FB2"
                  strokeWidth="0.8"
                  transform={`rotate(${a} 68 66)`}
                />
              ))}
              <circle cx="68" cy="66" r="4.5" fill="#C96480" />
            </motion.g>
          )}

          {/* 2. Sunflower */}
          {hasSunflower && (
            <motion.g
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: '150px 66px' }}
            >
              <path
                d="M116 150 C130 120, 142 94, 150 66"
                stroke="#6F8F6D"
                strokeWidth="3.2"
                strokeLinecap="round"
              />
              {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map(
                (a) => (
                  <ellipse
                    key={a}
                    cx="150"
                    cy="48"
                    rx="4"
                    ry="11"
                    fill={a % 60 === 0 ? '#EEB74A' : '#F6CE6E'}
                    transform={`rotate(${a} 150 66)`}
                  />
                )
              )}
              <circle cx="150" cy="66" r="10" fill="#654132" />
            </motion.g>
          )}

          {/* 3. Tulip */}
          {hasTulip && (
            <motion.g
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: '86px 96px' }}
            >
              <path
                d="M107 152 C98 130, 90 112, 86 96"
                stroke="#6F8F6D"
                strokeWidth="3"
                strokeLinecap="round"
              />
              <path
                d="M72 82 C70 98, 78 106, 86 106 C94 106, 102 98, 100 82 C95 86, 90 86, 86 76 C82 86, 77 86, 72 82 Z"
                fill="#EE9CB1"
              />
              <path
                d="M79 84 C80 96, 83 104, 86 104 C89 104, 92 96, 93 84 C90 86, 88 80, 86 76 C84 80, 82 86, 79 84 Z"
                fill="#C96D88"
              />
            </motion.g>
          )}

          {/* 4. Daisy */}
          {hasDaisy && (
            <motion.g
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: '134px 96px' }}
            >
              <path
                d="M113 152 C122 130, 128 112, 134 96"
                stroke="#6F8F6D"
                strokeWidth="3"
                strokeLinecap="round"
              />
              {[0, 36, 72, 108, 144, 180, 216, 252, 288, 324].map((a) => (
                <ellipse
                  key={a}
                  cx="134"
                  cy="83"
                  rx="4.2"
                  ry="10"
                  fill="#FFFDFB"
                  stroke="#EAD2DA"
                  strokeWidth="0.9"
                  transform={`rotate(${a} 134 96)`}
                />
              ))}
              <circle cx="134" cy="96" r="7" fill="#E8B968" />
            </motion.g>
          )}

          {/* 5. Center Rose */}
          {hasRose && (
            <motion.g
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              style={{ transformOrigin: '110px 56px' }}
            >
              <path
                d="M110 152 L110 66"
                stroke="#6F8F6D"
                strokeWidth="3.5"
                strokeLinecap="round"
              />
              <ellipse cx="110" cy="56" rx="20" ry="17" fill="#E695A8" />
              <ellipse cx="98" cy="53" rx="12" ry="13" fill="#D5738D" />
              <ellipse cx="122" cy="53" rx="12" ry="13" fill="#F3B5C4" />
              <ellipse cx="110" cy="51" rx="11" ry="10" fill="#B95472" />
              <path
                d="M103 51 C103 45, 117 45, 117 51 C117 56, 106 56, 106 51"
                stroke="#FCE5EB"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </motion.g>
          )}

          {/* Porcelain Blush Vase with Gold Trim */}
          <path
            d="M78 148 L142 148 L154 200 C155 210, 148 218, 138 218 L82 218 C72 218, 65 210, 66 200 Z"
            fill="url(#porcelainVase)"
            stroke="#D8B477"
            strokeWidth="1.6"
          />
          <ellipse
            cx="110"
            cy="148"
            rx="32"
            ry="6"
            fill="#F6DFE6"
            stroke="#D8B477"
            strokeWidth="1.4"
          />
          {/* Satin ribbon around vase */}
          <path
            d="M74 170 Q110 179 146 170"
            stroke="#C97891"
            strokeWidth="5.5"
            strokeLinecap="round"
          />
          <circle cx="110" cy="175" r="4.5" fill="#A94F70" stroke="#D8B477" strokeWidth="1" />
        </svg>
      </div>

      {allCollected ? (
        <motion.p
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="font-handwriting relative z-10 max-w-md text-2xl leading-snug text-[#A94F70]"
        >
          “{allCollectedMessage}”
        </motion.p>
      ) : (
        <p className="relative z-10 max-w-sm text-sm text-[#7E596A]">
          {count === 0
            ? 'Your blush porcelain vase is ready. Tap each bloom in the garden to add it.'
            : `${TOTAL_FLOWERS - count} more ${
                TOTAL_FLOWERS - count === 1 ? 'flower' : 'flowers'
              } waiting to bloom into your bouquet.`}
        </p>
      )}
    </div>
  );
};
