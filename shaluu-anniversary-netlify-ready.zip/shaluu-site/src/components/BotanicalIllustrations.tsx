import React from 'react';
import { FlowerId } from '../types/anniversary';

interface FlowerSvgProps {
  id: FlowerId;
  className?: string;
  collected?: boolean;
}

export const FlowerSvg: React.FC<FlowerSvgProps> = ({
  id,
  className = 'w-20 h-20',
  collected = false,
}) => {
  switch (id) {
    case 'rose':
      return (
        <svg
          viewBox="0 0 120 140"
          fill="none"
          className={className}
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="roseOuter" cx="50%" cy="40%" r="55%">
              <stop offset="0%" stopColor="#F9D2DC" />
              <stop offset="65%" stopColor="#E695A8" />
              <stop offset="100%" stopColor="#C3647E" />
            </radialGradient>
            <radialGradient id="roseCore" cx="50%" cy="45%" r="55%">
              <stop offset="0%" stopColor="#F4B2C2" />
              <stop offset="55%" stopColor="#C96582" />
              <stop offset="100%" stopColor="#9D4260" />
            </radialGradient>
          </defs>
          <path
            d="M60 66 C60 88, 58 112, 60 134"
            stroke="#6F8F6D"
            strokeWidth="3.8"
            strokeLinecap="round"
          />
          <path
            d="M60 100 C43 90, 32 95, 30 106 C42 110, 52 108, 60 100 Z"
            fill="#95AE8D"
          />
          <path
            d="M60 89 C77 79, 88 83, 90 94 C78 99, 68 96, 60 89 Z"
            fill="#839E7B"
          />
          {/* Layered garden rose petals */}
          <ellipse cx="60" cy="48" rx="31" ry="26" fill="url(#roseOuter)" />
          <ellipse cx="40" cy="44" rx="18" ry="21" fill="#E38DA2" />
          <ellipse cx="80" cy="44" rx="18" ry="21" fill="#F3B5C4" />
          <ellipse cx="60" cy="36" rx="22" ry="18" fill="#EE9FB2" />
          <ellipse cx="60" cy="43" rx="17" ry="15" fill="url(#roseCore)" />
          <path
            d="M49 42 C49 33, 71 33, 71 42 C71 49, 53 50, 53 42 C53 37, 65 37, 65 42"
            stroke="#FCE5EB"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          {collected && (
            <circle cx="94" cy="22" r="5" fill="#D8B477" opacity="0.95" />
          )}
        </svg>
      );

    case 'tulip':
      return (
        <svg
          viewBox="0 0 120 140"
          fill="none"
          className={className}
          aria-hidden="true"
        >
          <defs>
            <linearGradient id="tulipOuter" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FBE1E8" />
              <stop offset="55%" stopColor="#EE9CB1" />
              <stop offset="100%" stopColor="#C96D88" />
            </linearGradient>
            <linearGradient id="tulipInner" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#F5B8C8" />
              <stop offset="100%" stopColor="#A94F70" />
            </linearGradient>
          </defs>
          <path
            d="M60 68 L60 134"
            stroke="#6F8F6D"
            strokeWidth="3.8"
            strokeLinecap="round"
          />
          <path
            d="M60 124 C40 107, 34 84, 43 72 C50 92, 54 106, 60 124 Z"
            fill="#93AC8B"
          />
          <path
            d="M60 124 C80 107, 86 84, 77 72 C70 92, 66 106, 60 124 Z"
            fill="#809B78"
          />
          <path
            d="M35 39 C33 63, 46 73, 60 73 C74 73, 87 63, 85 39 C78 46, 70 46, 60 28 C50 46, 42 46, 35 39 Z"
            fill="url(#tulipOuter)"
          />
          <path
            d="M46 42 C46 61, 52 71, 60 71 C68 71, 74 61, 74 42 C68 48, 64 37, 60 27 C56 37, 52 48, 46 42 Z"
            fill="url(#tulipInner)"
          />
          <path
            d="M52 44 C54 61, 56 69, 60 69 C64 69, 66 61, 68 44 C64 46, 62 38, 60 31 C58 38, 56 46, 52 44 Z"
            fill="#F9CAD6"
          />
        </svg>
      );

    case 'daisy':
      return (
        <svg
          viewBox="0 0 120 140"
          fill="none"
          className={className}
          aria-hidden="true"
        >
          <path
            d="M60 62 C59 86, 61 112, 60 134"
            stroke="#6F8F6D"
            strokeWidth="3.8"
            strokeLinecap="round"
          />
          <path
            d="M60 102 C45 94, 37 98, 35 108 C45 111, 53 108, 60 102 Z"
            fill="#95AE8D"
          />
          {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map(
            (angle) => (
              <ellipse
                key={angle}
                cx="60"
                cy="24"
                rx="6.8"
                ry="17"
                fill="#FFFDFB"
                stroke="#EED8DF"
                strokeWidth="0.9"
                transform={`rotate(${angle} 60 46)`}
              />
            )
          )}
          <circle cx="60" cy="46" r="13" fill="#E8B968" />
          <circle cx="60" cy="46" r="9.5" fill="#D8A048" />
          <circle cx="56" cy="43" r="1.5" fill="#FFF3D6" />
          <circle cx="63" cy="44" r="1.5" fill="#FFF3D6" />
          <circle cx="60" cy="49" r="1.5" fill="#FFF3D6" />
        </svg>
      );

    case 'cherry_blossom':
      return (
        <svg
          viewBox="0 0 120 140"
          fill="none"
          className={className}
          aria-hidden="true"
        >
          <defs>
            <radialGradient id="sakuraPetal" cx="50%" cy="75%" r="70%">
              <stop offset="0%" stopColor="#E688A1" />
              <stop offset="55%" stopColor="#FAD6E0" />
              <stop offset="100%" stopColor="#FFF7F9" />
            </radialGradient>
          </defs>
          <path
            d="M28 118 C44 96, 56 80, 62 56"
            stroke="#8B6E68"
            strokeWidth="4.2"
            strokeLinecap="round"
          />
          <path
            d="M48 92 C66 88, 82 94, 92 104"
            stroke="#8B6E68"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
          <path
            d="M72 86 C78 78, 86 78, 90 84 C84 88, 78 88, 72 86 Z"
            fill="#95AE8D"
          />
          {[0, 72, 144, 216, 288].map((angle) => (
            <path
              key={angle}
              d="M60 44 C49 27, 47 15, 57 13 L60 19 L63 13 C73 15, 71 27, 60 44 Z"
              fill="url(#sakuraPetal)"
              stroke="#E9A2B5"
              strokeWidth="0.9"
              transform={`rotate(${angle} 60 44)`}
            />
          ))}
          <circle cx="60" cy="44" r="6" fill="#C96480" />
          {[0, 60, 120, 180, 240, 300].map((angle) => (
            <line
              key={angle}
              x1="60"
              y1="44"
              x2="60"
              y2="33"
              stroke="#FFF3D8"
              strokeWidth="1.4"
              strokeLinecap="round"
              transform={`rotate(${angle} 60 44)`}
            />
          ))}
        </svg>
      );

    case 'sunflower':
      return (
        <svg
          viewBox="0 0 120 140"
          fill="none"
          className={className}
          aria-hidden="true"
        >
          <path
            d="M60 66 L60 134"
            stroke="#6F8F6D"
            strokeWidth="4"
            strokeLinecap="round"
          />
          <path
            d="M60 98 C44 90, 34 94, 32 105 C44 108, 52 106, 60 98 Z"
            fill="#88A482"
          />
          <path
            d="M60 108 C76 100, 86 104, 88 114 C76 118, 68 116, 60 108 Z"
            fill="#95AE8D"
          />
          {[0, 22.5, 45, 67.5, 90, 112.5, 135, 157.5, 180, 202.5, 225, 247.5, 270, 292.5, 315, 337.5].map(
            (angle) => (
              <ellipse
                key={angle}
                cx="60"
                cy="21"
                rx="5.4"
                ry="16"
                fill={angle % 45 === 0 ? '#EEB74A' : '#F6CE6E'}
                transform={`rotate(${angle} 60 46)`}
              />
            )
          )}
          <circle cx="60" cy="46" r="15" fill="#654132" />
          <circle cx="60" cy="46" r="11" fill="#7D5240" />
          <circle cx="56" cy="43" r="1.5" fill="#D8B477" />
          <circle cx="64" cy="44" r="1.5" fill="#D8B477" />
          <circle cx="60" cy="50" r="1.5" fill="#D8B477" />
        </svg>
      );
  }
};

export const WaxSealSvg: React.FC<{ className?: string }> = ({
  className = 'w-14 h-14',
}) => (
  <svg viewBox="0 0 80 80" fill="none" className={className} aria-hidden="true">
    <defs>
      <radialGradient id="waxGrad" cx="35%" cy="30%" r="70%">
        <stop offset="0%" stopColor="#D67C96" />
        <stop offset="60%" stopColor="#A94F70" />
        <stop offset="100%" stopColor="#843552" />
      </radialGradient>
    </defs>
    <path
      d="M40 6 C48 6, 54 9, 60 12 C67 15, 72 23, 73 31 C75 39, 73 48, 69 55 C65 63, 57 70, 48 72 C40 74, 31 73, 24 68 C16 63, 10 55, 8 46 C6 37, 9 27, 15 19 C21 12, 30 6, 40 6 Z"
      fill="#9E4262"
    />
    <circle
      cx="40"
      cy="40"
      r="24"
      fill="url(#waxGrad)"
      stroke="#D8B477"
      strokeWidth="1.5"
    />
    <path
      d="M40 50 C40 50, 29 43, 29 35.5 C29 31.8, 32 29, 35.4 29 C37.6 29, 39.2 30.2, 40 31.8 C40.8 30.2, 42.4 29, 44.6 29 C48 29, 51 31.8, 51 35.5 C51 43, 40 50, 40 50 Z"
      fill="#FFF7F2"
    />
  </svg>
);

export const CornerBlossomSvg: React.FC<{ className?: string }> = ({
  className = 'w-24 h-24',
}) => (
  <svg viewBox="0 0 120 120" fill="none" className={className} aria-hidden="true">
    <path
      d="M14 98 C34 78, 58 62, 92 48"
      stroke="#A4B99A"
      strokeWidth="2.5"
      strokeLinecap="round"
    />
    <path
      d="M36 78 C24 64, 24 52, 34 48 C42 58, 42 68, 36 78 Z"
      fill="#A4B99A"
      opacity="0.9"
    />
    <path
      d="M66 60 C72 46, 86 44, 92 52 C84 62, 74 64, 66 60 Z"
      fill="#8EA684"
      opacity="0.9"
    />
    <g transform="translate(52 46)">
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse
          key={a}
          cx="0"
          cy="-12"
          rx="6"
          ry="10"
          fill="#F4C6D0"
          transform={`rotate(${a})`}
        />
      ))}
      <circle cx="0" cy="0" r="4.5" fill="#D8B477" />
    </g>
    <g transform="translate(86 30)">
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse
          key={a}
          cx="0"
          cy="-9"
          rx="4.5"
          ry="7.5"
          fill="#FFF7F2"
          stroke="#EBA8B8"
          strokeWidth="0.8"
          transform={`rotate(${a})`}
        />
      ))}
      <circle cx="0" cy="0" r="3.5" fill="#D8B477" />
    </g>
  </svg>
);
