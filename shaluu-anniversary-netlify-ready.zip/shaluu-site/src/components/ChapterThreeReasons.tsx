import React, { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, ArrowRight, Check, X } from 'lucide-react';
import {
  AnniversaryContent,
  AnniversaryProgress,
  FlowerId,
  OpenWhenLetter,
} from '../types/anniversary';
import { TOTAL_FLOWERS } from '../utils/anniversaryStore';
import { FlowerSvg, WaxSealSvg } from './BotanicalIllustrations';
import { GrowingBouquet } from './GrowingBouquet';
import { PandaHug } from './PandaHug';
import {
  ButterflyAccent,
  FloralCornerOrnament,
  GoldFloralDivider,
  SwayingFloralSprig,
} from './RomanticOrnaments';

interface ChapterThreeReasonsProps {
  content: AnniversaryContent;
  progress: AnniversaryProgress;
  onCollectFlower: (flowerId: FlowerId) => void;
  onOpenLetter: (letterId: string) => void;
  onPandaHug: () => void;
  onPrevChapter: () => void;
  onNextChapter: () => void;
}

export const ChapterThreeReasons: React.FC<ChapterThreeReasonsProps> = ({
  content,
  progress,
  onCollectFlower,
  onOpenLetter,
  onPandaHug,
  onPrevChapter,
  onNextChapter,
}) => {
  const { chapter3 } = content;
  const [selectedFlowerId, setSelectedFlowerId] = useState<FlowerId | null>(
    progress.collectedFlowers[progress.collectedFlowers.length - 1] ?? null
  );
  const [activeLetter, setActiveLetter] = useState<OpenWhenLetter | null>(null);
  const letterCloseBtnRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (!activeLetter) return;
    letterCloseBtnRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setActiveLetter(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [activeLetter]);

  const activeFlower = chapter3.flowers.find((f) => f.id === selectedFlowerId);

  const handleFlowerClick = (flowerId: FlowerId) => {
    setSelectedFlowerId(flowerId);
    onCollectFlower(flowerId);
  };

  const handleLetterClick = (letter: OpenWhenLetter) => {
    setActiveLetter(letter);
    onOpenLetter(letter.id);
  };

  return (
    <section
      aria-label="Chapter 3: A Thousand Little Reasons"
      className="paper-texture relative overflow-hidden py-10 sm:py-16"
      style={{
        background:
          'linear-gradient(180deg, #FFF6F0 0%, #FBE2EA 48%, #F6D0DA 100%)',
      }}
    >
      {/* Living garden radial glow behind flower bed */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 35% 24%, rgba(255, 246, 240, 0.85) 0%, transparent 52%), radial-gradient(circle at 75% 60%, rgba(249, 214, 203, 0.34) 0%, transparent 54%)',
        }}
      />

      {/* Corner Floral Garlands */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 opacity-80"
      >
        <FloralCornerOrnament
          position="top-left"
          className="h-28 w-36 sm:h-40 sm:w-52"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 right-0 hidden opacity-75 sm:block"
      >
        <FloralCornerOrnament
          position="top-right"
          className="h-36 w-48"
        />
      </div>

      <div className="relative z-20 mx-auto max-w-5xl space-y-16 px-4 sm:px-6">
        {/* Chapter Header */}
        <div className="text-center">
          <p className="text-[11px] font-semibold tracking-[0.24em] text-[#7F5A6B] uppercase">
            CHAPTER III &nbsp;·&nbsp; THREE MONTHS, A THOUSAND REASONS
          </p>
          <div className="mt-2 flex items-center justify-center gap-3">
            <SwayingFloralSprig className="hidden h-14 w-11 opacity-85 sm:block" />
            <h1 className="font-serif-display text-balance text-4xl font-semibold tracking-tight text-[#563443] sm:text-5xl md:text-6xl">
              {chapter3.heading}
            </h1>
            <SwayingFloralSprig
              flip
              className="hidden h-14 w-11 opacity-85 sm:block"
            />
          </div>
          <p className="mx-auto mt-3 max-w-2xl text-base text-[#7F5A6B]">
            {chapter3.subheading}
          </p>
          <GoldFloralDivider className="mt-5" />
        </div>

        {/* A & D. Interactive Flower Garden + Growing Bouquet */}
        <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-12">
          <div className="stationery-panel relative overflow-hidden rounded-3xl p-6 sm:p-8 lg:col-span-7">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D8B477]/30"
            />
            <div className="relative z-10">
              <div className="mb-6 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-[11px] font-semibold tracking-[0.18em] text-[#A94F70] uppercase">
                    Interactive Flower Garden
                  </p>
                  <h2 className="font-serif-display text-2xl font-semibold text-[#50313F] sm:text-3xl">
                    Pick a Flower to Read Its Note
                  </h2>
                </div>
                <span
                  className="text-sm font-semibold text-[#A94F70] tabular-nums"
                  data-testid="flower-counter"
                >
                  Flowers collected: {progress.collectedFlowers.length}/
                  {TOTAL_FLOWERS}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                {chapter3.flowers.map((flower, idx) => {
                  const collected = progress.collectedFlowers.includes(
                    flower.id
                  );
                  const selected = selectedFlowerId === flower.id;

                  return (
                    <motion.button
                      key={flower.id}
                      type="button"
                      onClick={() => handleFlowerClick(flower.id)}
                      whileHover={{ y: -4 }}
                      whileTap={{ scale: 0.96 }}
                      animate={
                        selected ? { scale: [1, 1.05, 1.02] } : { scale: 1 }
                      }
                      transition={{ duration: 0.35 }}
                      aria-pressed={selected}
                      aria-label={`${flower.name}${
                        collected ? ' (collected)' : ''
                      }`}
                      className={`relative flex min-h-[150px] flex-col items-center justify-center rounded-2xl border p-4 transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70] ${
                        selected
                          ? 'border-[#D8B477] bg-[#FFFDFB] shadow-[0_12px_30px_-10px_rgba(216,180,119,0.55)] ring-1 ring-[#D8B477]/45'
                          : collected
                          ? 'border-[#A4B99A] bg-[#FFFDFB]/95'
                          : 'border-[#C97891]/28 bg-[#FFFDFB]/90 hover:border-[#C97891]/60 hover:bg-[#FFFDFB]'
                      }`}
                    >
                      {collected && (
                        <span
                          className="absolute top-2.5 right-2.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-[#8CA582] text-white"
                          aria-hidden="true"
                        >
                          <Check className="h-3 w-3" />
                        </span>
                      )}

                      <div
                        className={idx % 2 === 0 ? 'animate-sway' : ''}
                        style={{ animationDelay: `${idx * 0.4}s` }}
                      >
                        <FlowerSvg
                          id={flower.id}
                          collected={collected}
                          className="h-22 w-22"
                        />
                      </div>
                      <span className="mt-2 text-sm font-medium text-[#50313F]">
                        {flower.name}
                      </span>
                    </motion.button>
                  );
                })}
              </div>

              {/* Revealed Flower Message inside Decorative Paper Panel */}
              <AnimatePresence mode="wait">
                {activeFlower ? (
                  <motion.div
                    key={activeFlower.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -6 }}
                    transition={{ duration: 0.25 }}
                    className="paper-texture relative mt-6 rounded-2xl border border-[#D8B477]/55 bg-[#FFFDF9] p-5 shadow-xs"
                  >
                    <div className="flex items-center justify-between">
                      <p className="font-script text-2xl text-[#A94F70]">
                        {activeFlower.name}
                      </p>
                      <ButterflyAccent className="h-6 w-6 opacity-75" />
                    </div>
                    <p className="font-serif-display mt-1 text-xl italic leading-relaxed text-[#50313F] sm:text-2xl">
                      “{activeFlower.message}”
                    </p>
                  </motion.div>
                ) : (
                  <div className="mt-6 rounded-2xl border border-dashed border-[#C97891]/35 bg-[#FFFDF9]/75 p-5 text-center text-sm text-[#7E596A]">
                    Tap any bloom above to reveal a hidden note and add it to
                    your bouquet.
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* D. Persistent Growing Bouquet */}
          <div className="lg:col-span-5">
            <GrowingBouquet
              collectedFlowers={progress.collectedFlowers}
              allCollectedMessage={chapter3.allCollectedMessage}
            />
          </div>
        </div>

        {/* B. Open When... — Real Stationery Blush Envelopes */}
        <div className="border-t border-[#D8B477]/40 pt-12">
          <div className="mb-8 text-center">
            <p className="text-[11px] font-semibold tracking-[0.2em] text-[#A94F70] uppercase">
              Keepsake Stationery
            </p>
            <h2 className="font-serif-display mt-1 text-3xl font-semibold text-[#50313F] sm:text-4xl">
              {chapter3.openWhenHeading}
            </h2>
            <p className="mx-auto mt-2 max-w-xl text-sm text-[#7E596A] sm:text-base">
              {chapter3.openWhenSubheading}
            </p>
          </div>

          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {chapter3.letters.map((letter) => {
              const openedBefore = progress.openedLetters.includes(letter.id);
              return (
                <motion.button
                  key={letter.id}
                  type="button"
                  onClick={() => handleLetterClick(letter)}
                  whileHover={{ y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  className="group relative flex min-h-[164px] flex-col justify-between overflow-hidden rounded-2xl border border-[#D8B477]/55 bg-gradient-to-b from-[#FFF8F6] via-[#FCE7EE] to-[#F6D3DF] p-5 text-left shadow-[0_14px_32px_-16px_rgba(169,79,112,0.28)] transition-shadow hover:shadow-[0_20px_38px_-14px_rgba(169,79,112,0.38)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
                >
                  {/* Envelope top diagonal flap */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-0 h-14 border-b border-[#C97891]/25 bg-gradient-to-b from-[#FDF1F5] to-transparent"
                    style={{ clipPath: 'polygon(0 0, 100% 0, 50% 100%)' }}
                  />
                  {/* Gold ribbon band */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-10 h-1.5 border-y border-[#D8B477]/35 bg-[#EBA8B8]/35"
                  />

                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <WaxSealSvg className="h-9 w-9 shrink-0 drop-shadow-xs transition-transform duration-300 group-hover:scale-105" />
                    <span className="text-[11px] font-medium tracking-wider text-[#7E596A] uppercase">
                      {openedBefore ? 'Opened · Read again' : 'Sealed ♡'}
                    </span>
                  </div>

                  <p className="font-handwriting relative z-10 mt-5 text-2xl font-semibold leading-snug text-[#50313F] group-hover:text-[#A94F70]">
                    {letter.title}
                  </p>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* C. A Little Panda Hug */}
        <div className="border-t border-[#D8B477]/40 pt-12">
          <PandaHug
            heading={chapter3.pandaHeading}
            message={chapter3.pandaMessage}
            buttonLabel={chapter3.pandaButtonLabel}
            hugCount={progress.pandaHugCount}
            onHug={onPandaHug}
          />
        </div>

        {/* Chapter 3 Closing & Navigation */}
        <div className="stationery-panel paper-texture relative overflow-hidden rounded-3xl p-7 text-center sm:p-10">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D8B477]/35"
          />
          <div className="relative z-10">
            <GoldFloralDivider className="mb-4" />
            <p className="font-serif-display mx-auto max-w-xl text-2xl italic text-[#50313F] sm:text-3xl">
              “{chapter3.closingLine}”
            </p>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onPrevChapter}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-full border border-[#C97891]/35 bg-[#FFF7F2] px-6 py-3 text-sm font-medium text-[#50313F] transition-colors hover:bg-[#F9E3E9] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Chapter 2</span>
              </button>
              <button
                type="button"
                onClick={onNextChapter}
                className="inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-gradient-to-r from-[#B96281] to-[#A94F70] px-7 py-3 text-sm font-medium text-[#FFF7F2] shadow-md shadow-[#A94F70]/25 transition-all hover:from-[#A94F70] hover:to-[#8F3D5B] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
              >
                <span>{chapter3.nextButtonLabel}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Open When Letter Stationery Modal */}
      <AnimatePresence>
        {activeLetter && (
          <div
            role="dialog"
            aria-modal="true"
            aria-label={activeLetter.title}
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#50313F]/55 p-4 backdrop-blur-sm"
            onClick={() => setActiveLetter(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.92, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 8 }}
              transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="stationery-panel paper-texture relative max-h-[86vh] w-full max-w-lg overflow-y-auto rounded-3xl p-6 sm:p-9"
            >
              <div
                aria-hidden="true"
                className="pointer-events-none absolute top-0 left-0 opacity-65"
              >
                <FloralCornerOrnament
                  position="top-left"
                  className="h-24 w-32"
                />
              </div>

              <div className="relative z-10">
                <div className="mb-4 flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <WaxSealSvg className="h-10 w-10 shrink-0" />
                    <h3 className="font-serif-display text-2xl font-semibold text-[#50313F]">
                      {activeLetter.title}
                    </h3>
                  </div>
                  <button
                    ref={letterCloseBtnRef}
                    type="button"
                    onClick={() => setActiveLetter(null)}
                    aria-label="Close letter"
                    className="inline-flex min-h-[40px] min-w-[40px] shrink-0 items-center justify-center rounded-full border border-[#C97891]/35 bg-[#FFF7F2] text-[#7E596A] transition-colors hover:bg-[#F9E3E9] focus-visible:outline-2 focus-visible:outline-[#A94F70]"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <div className="space-y-4 border-t border-[#D8B477]/40 pt-5 text-base leading-relaxed whitespace-pre-line text-[#50313F]">
                  {activeLetter.body}
                </div>

                <p className="font-handwriting mt-6 text-right text-2xl text-[#A94F70]">
                  {activeLetter.signOff}
                </p>

                <div className="mt-6 flex justify-center">
                  <button
                    type="button"
                    onClick={() => setActiveLetter(null)}
                    className="inline-flex min-h-[44px] items-center rounded-full bg-[#F4C6D0]/55 px-6 py-2 text-sm font-medium text-[#50313F] transition-colors hover:bg-[#F4C6D0] focus-visible:outline-2 focus-visible:outline-[#A94F70]"
                  >
                    Keep This Letter Safe
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
