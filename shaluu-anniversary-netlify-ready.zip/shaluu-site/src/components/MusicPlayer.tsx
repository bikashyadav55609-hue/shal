import React, {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import { Music2, Pause, Play, Volume2 } from 'lucide-react';
import { MusicConfig } from '../types/anniversary';

export type PlaybackStatus =
  | 'idle'
  | 'loading'
  | 'playing'
  | 'paused'
  | 'blocked'
  | 'error';

export interface MusicControllerHandle {
  startFromUserGesture: () => void;
  togglePlayback: () => void;
  getStatus: () => PlaybackStatus;
}

interface YTPlayerInstance {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  loadVideoById: (options: { videoId: string; startSeconds?: number }) => void;
  destroy: () => void;
  getPlayerState: () => number;
}

interface YTNamespace {
  Player: new (
    element: HTMLElement | string,
    options: {
      height?: string | number;
      width?: string | number;
      videoId: string;
      playerVars?: Record<string, number | string>;
      events?: {
        onReady?: (event: { target: YTPlayerInstance }) => void;
        onStateChange?: (event: { data: number }) => void;
        onError?: () => void;
      };
    }
  ) => YTPlayerInstance;
  PlayerState: {
    UNSTARTED: number;
    ENDED: number;
    PLAYING: number;
    PAUSED: number;
    BUFFERING: number;
    CUED: number;
  };
}

declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

interface MusicPlayerProps {
  config: MusicConfig;
  nightMode?: boolean;
  onStatusChange?: (status: PlaybackStatus) => void;
}

export const MusicPlayer = forwardRef<MusicControllerHandle, MusicPlayerProps>(
  ({ config, nightMode = false, onStatusChange }, ref) => {
    const hostRef = useRef<HTMLDivElement | null>(null);
    const playerRef = useRef<YTPlayerInstance | null>(null);
    const readyRef = useRef(false);
    const pendingStartRef = useRef(false);
    const blockedCheckTimerRef = useRef<number | null>(null);
    const currentVideoRef = useRef<string>(config.youtubeVideoId);

    const [status, setStatus] = useState<PlaybackStatus>('idle');

    const updateStatus = useCallback(
      (next: PlaybackStatus) => {
        setStatus(next);
        onStatusChange?.(next);
      },
      [onStatusChange]
    );

    const clearBlockedTimer = () => {
      if (blockedCheckTimerRef.current !== null) {
        window.clearTimeout(blockedCheckTimerRef.current);
        blockedCheckTimerRef.current = null;
      }
    };

    const scheduleBlockedVerification = useCallback(() => {
      clearBlockedTimer();
      blockedCheckTimerRef.current = window.setTimeout(() => {
        const player = playerRef.current;
        const yt = window.YT;
        if (!player || !yt) {
          updateStatus('blocked');
          return;
        }
        try {
          const state = player.getPlayerState();
          if (
            state !== yt.PlayerState.PLAYING &&
            state !== yt.PlayerState.BUFFERING
          ) {
            updateStatus('blocked');
          }
        } catch {
          updateStatus('blocked');
        }
      }, 1500);
    }, [updateStatus]);

    const startFromUserGesture = useCallback(() => {
      pendingStartRef.current = true;
      if (!readyRef.current || !playerRef.current) {
        updateStatus('loading');
        scheduleBlockedVerification();
        return;
      }
      try {
        updateStatus('loading');
        playerRef.current.seekTo(config.startSeconds, true);
        playerRef.current.playVideo();
        scheduleBlockedVerification();
      } catch {
        updateStatus('blocked');
      }
    }, [config.startSeconds, scheduleBlockedVerification, updateStatus]);

    const togglePlayback = useCallback(() => {
      const player = playerRef.current;
      if (!readyRef.current || !player) {
        startFromUserGesture();
        return;
      }

      try {
        if (status === 'playing') {
          clearBlockedTimer();
          player.pauseVideo();
          updateStatus('paused');
        } else {
          if (status === 'idle' || status === 'blocked') {
            player.seekTo(config.startSeconds, true);
          }
          updateStatus('loading');
          player.playVideo();
          scheduleBlockedVerification();
        }
      } catch {
        updateStatus('blocked');
      }
    }, [
      config.startSeconds,
      scheduleBlockedVerification,
      startFromUserGesture,
      status,
      updateStatus,
    ]);

    useImperativeHandle(
      ref,
      () => ({
        startFromUserGesture,
        togglePlayback,
        getStatus: () => status,
      }),
      [startFromUserGesture, status, togglePlayback]
    );

    // Mount persistent YouTube player once
    useEffect(() => {
      let disposed = false;

      const initPlayer = () => {
        if (disposed || !hostRef.current || !window.YT?.Player) return;
        if (playerRef.current) return;

        try {
          playerRef.current = new window.YT.Player(hostRef.current, {
            height: '200',
            width: '200',
            videoId: config.youtubeVideoId,
            playerVars: {
              autoplay: 0,
              controls: 0,
              disablekb: 1,
              fs: 0,
              modestbranding: 1,
              rel: 0,
              playsinline: 1,
              start: config.startSeconds,
            },
            events: {
              onReady: (event) => {
                if (disposed) return;
                readyRef.current = true;
                currentVideoRef.current = config.youtubeVideoId;
                if (pendingStartRef.current) {
                  try {
                    event.target.seekTo(config.startSeconds, true);
                    event.target.playVideo();
                    scheduleBlockedVerification();
                  } catch {
                    updateStatus('blocked');
                  }
                }
              },
              onStateChange: (event) => {
                if (disposed || !window.YT) return;
                const { PlayerState } = window.YT;
                if (event.data === PlayerState.PLAYING) {
                  clearBlockedTimer();
                  pendingStartRef.current = false;
                  updateStatus('playing');
                } else if (event.data === PlayerState.BUFFERING) {
                  updateStatus('loading');
                } else if (event.data === PlayerState.PAUSED) {
                  clearBlockedTimer();
                  updateStatus('paused');
                } else if (event.data === PlayerState.ENDED) {
                  // Loop gently from startSeconds
                  try {
                    playerRef.current?.seekTo(config.startSeconds, true);
                    playerRef.current?.playVideo();
                  } catch {
                    updateStatus('paused');
                  }
                }
              },
              onError: () => {
                if (disposed) return;
                clearBlockedTimer();
                updateStatus('error');
              },
            },
          });
        } catch {
          updateStatus('error');
        }
      };

      if (window.YT?.Player) {
        initPlayer();
      } else {
        const prevReady = window.onYouTubeIframeAPIReady;
        window.onYouTubeIframeAPIReady = () => {
          prevReady?.();
          initPlayer();
        };
        if (
          !document.querySelector(
            'script[src="https://www.youtube.com/iframe_api"]'
          )
        ) {
          const script = document.createElement('script');
          script.src = 'https://www.youtube.com/iframe_api';
          script.async = true;
          script.onerror = () => {
            if (!disposed) updateStatus('error');
          };
          document.head.appendChild(script);
        }
      }

      return () => {
        disposed = true;
        clearBlockedTimer();
        try {
          playerRef.current?.destroy();
        } catch {
          // ignore cleanup errors
        }
        playerRef.current = null;
        readyRef.current = false;
      };
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // Update video if owner edits music settings
    useEffect(() => {
      if (
        readyRef.current &&
        playerRef.current &&
        config.youtubeVideoId &&
        config.youtubeVideoId !== currentVideoRef.current
      ) {
        currentVideoRef.current = config.youtubeVideoId;
        try {
          playerRef.current.loadVideoById({
            videoId: config.youtubeVideoId,
            startSeconds: config.startSeconds,
          });
          if (status !== 'playing') {
            playerRef.current.pauseVideo();
          }
        } catch {
          updateStatus('error');
        }
      }
    }, [config.startSeconds, config.youtubeVideoId, status, updateStatus]);

    const showFallbackPlayCta = status === 'blocked' || status === 'error';

    return (
      <>
        {/* Persistent off-screen YouTube mount */}
        <div
          aria-hidden="true"
          className="pointer-events-none fixed bottom-0 left-0 h-px w-px overflow-hidden opacity-[0.01]"
        >
          <div ref={hostRef} />
        </div>

        {/* Discreet user-facing music control */}
        <div className="flex items-center gap-2">
          {showFallbackPlayCta ? (
            <button
              type="button"
              onClick={startFromUserGesture}
              className={`inline-flex min-h-[40px] items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-medium transition-all focus-visible:outline-2 focus-visible:outline-offset-2 ${
                nightMode
                  ? 'bg-[#F3B8C8] text-[#2B1826] hover:bg-[#F8CBD7] focus-visible:outline-white'
                  : 'bg-[var(--theme-accent)] text-white hover:bg-[var(--theme-accent-hover)] focus-visible:outline-[var(--theme-accent)]'
              } whitespace-nowrap shadow-sm`}
              aria-label={`Play our song: ${config.songTitle}`}
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Play Our Song ♡</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={togglePlayback}
              className={`inline-flex min-h-[40px] items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 ${
                nightMode
                  ? 'border-white/20 bg-white/10 text-[#FDF5F7] hover:bg-white/20 focus-visible:outline-white'
                  : 'border-[var(--theme-border)] bg-[var(--theme-surface)]/90 text-[var(--theme-ink)] hover:bg-[var(--theme-bg-soft)] focus-visible:outline-[var(--theme-accent)]'
              } whitespace-nowrap`}
              aria-label={
                status === 'playing'
                  ? `Pause ${config.songTitle}`
                  : `Play ${config.songTitle}`
              }
            >
              {status === 'playing' ? (
                <>
                  <Pause className="h-3.5 w-3.5 shrink-0" />
                  <span className="hidden max-w-[140px] truncate sm:inline">
                    {config.songTitle}
                  </span>
                  <span
                    className="flex h-3 items-end gap-[2px]"
                    aria-hidden="true"
                  >
                    <span className="h-2 w-[2px] animate-pulse rounded-full bg-current" />
                    <span className="h-3 w-[2px] animate-pulse rounded-full bg-current [animation-delay:150ms]" />
                    <span className="h-1.5 w-[2px] animate-pulse rounded-full bg-current [animation-delay:300ms]" />
                  </span>
                </>
              ) : status === 'loading' ? (
                <>
                  <Volume2 className="h-3.5 w-3.5 shrink-0 animate-pulse" />
                  <span className="hidden sm:inline">Starting song...</span>
                  <span className="sm:hidden">Song</span>
                </>
              ) : (
                <>
                  <Music2 className="h-3.5 w-3.5 shrink-0" />
                  <span className="hidden max-w-[140px] truncate sm:inline">
                    {config.songTitle}
                  </span>
                  <span className="sm:hidden">Music</span>
                </>
              )}
            </button>
          )}
        </div>
      </>
    );
  }
);

MusicPlayer.displayName = 'MusicPlayer';
