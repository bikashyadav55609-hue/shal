import React from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, Heart } from 'lucide-react';
import { AnniversaryContent } from '../types/anniversary';
import { WaxSealSvg } from './BotanicalIllustrations';
import {
  ButterflyAccent,
  FloralCornerOrnament,
  GARDEN_ROSES_SRC,
  GoldFloralDivider,
  SwayingFloralSprig,
  ThreeMonthEmblem,
} from './RomanticOrnaments';

interface ChapterOneWelcomeProps {
  content: AnniversaryContent;
  opened: boolean;
  onFirstOpen: () => void;
  onProceedToChapter2: () => void;
}

export const ChapterOneWelcome: React.FC<ChapterOneWelcomeProps> = ({
  content,
  opened,
  onFirstOpen,
  onProceedToChapter2,
}) => {
  const { personal, chapter1 } = content;

  return (
    <section
      aria-label="Chapter 1: Three-Month Anniversary Invitation"
      className="paper-texture relative flex min-h-[calc(100vh-3.5rem)] flex-col items-center justify-center overflow-hidden px-4 py-10 sm:px-6 sm:py-14"
      style={{
        background:
          'linear-gradient(166deg, #FFF6F0 0%, #FBE2EA 42%, #F6D0DA 78%, #EFAFC1 100%)',
      }}
    >
      {/* Sunlit garden & warm champagne radial glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 22%, rgba(255, 246, 240, 0.92) 0%, rgba(249, 214, 203, 0.45) 45%, transparent 78%)',
        }}
      />

      {/* Realistic Floral Corner Garlands */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 z-10"
      >
        <FloralCornerOrnament
          position="top-left"
          className="h-32 w-40 sm:h-48 sm:w-64"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 right-0 z-10 hidden sm:block opacity-75"
      >
        <FloralCornerOrnament
          position="top-right"
          className="h-40 w-52"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-0 bottom-0 z-10"
      >
        <FloralCornerOrnament
          position="bottom-right"
          className="h-32 w-40 sm:h-48 sm:w-64"
        />
      </div>

      <div className="relative z-20 mx-auto flex w-full max-w-3xl flex-col items-center text-center">
        {/* Chapter Label */}
        <p className="mb-3 text-[11px] font-semibold tracking-[0.24em] text-[#7F5A6B] uppercase">
          CHAPTER I &nbsp;·&nbsp; THE ANNIVERSARY GARDEN
        </p>

        {/* Ornamental 03 Months Anniversary Emblem flanked by swaying sprigs */}
        <div className="mb-5 flex items-center justify-center gap-3">
          <SwayingFloralSprig className="hidden h-14 w-11 opacity-85 sm:block" />
          <ThreeMonthEmblem badgeText={chapter1.anniversaryBadge} />
          <SwayingFloralSprig
            flip
            className="hidden h-14 w-11 opacity-85 sm:block"
          />
        </div>

        {/* Expressive Display Heading */}
        <h1 className="font-serif-display text-balance text-4xl font-semibold tracking-tight text-[#563443] sm:text-5xl md:text-6xl">
          {chapter1.heroHeading}
        </h1>
        <p className="font-serif-display mt-3 max-w-xl text-lg italic text-[#B65F7D] sm:text-2xl">
          {chapter1.heroSubtitle}
        </p>

        <GoldFloralDivider className="my-5 w-full" />

        <AnimatePresence mode="wait">
          {!opened ? (
            <motion.div
              key="closed-invitation"
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: -12 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
              className="mt-2 w-full"
            >
              {/* Luxury Stationery Envelope Card */}
              <div
                onClick={onFirstOpen}
                role="presentation"
                className="stationery-panel paper-texture group relative mx-auto max-w-2xl cursor-pointer overflow-hidden rounded-3xl p-6 transition-transform duration-300 hover:-translate-y-0.5 sm:p-10"
              >
                {/* Delicate inner gold hairline frame */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-3 rounded-2xl border border-[#D8B477]/35"
                />

                {/* Three realistic garden roses emblem above envelope */}
                <div className="relative mx-auto mb-3 flex items-center justify-center">
                  <div
                    className="relative h-28 w-44 overflow-hidden"
                    style={{
                      WebkitMaskImage:
                        'radial-gradient(ellipse 50% 50% at 50% 50%, black 38%, transparent 92%)',
                      maskImage:
                        'radial-gradient(ellipse 50% 50% at 50% 50%, black 38%, transparent 92%)',
                    }}
                  >
                    <img
                      src={GARDEN_ROSES_SRC}
                      alt=""
                      aria-hidden="true"
                      referrerPolicy="no-referrer"
                      className="h-full w-full scale-110 object-cover mix-blend-multiply"
                    />
                  </div>
                  <ButterflyAccent className="animate-sway absolute -top-1 right-10 h-8 w-8 opacity-85 sm:right-24" />
                </div>

                {/* Envelope visual with blush-rose flap, satin ribbon & wax seal */}
                <div className="relative mx-auto mb-6 max-w-md overflow-hidden rounded-2xl border border-[#C97891]/35 bg-gradient-to-b from-[#FFF7F2] via-[#FCE7ED] to-[#F6D3DD] p-6 shadow-inner">
                  {/* Envelope flap */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-0 h-20 border-b border-[#C97891]/30 bg-gradient-to-b from-[#F9DDE5] to-[#FCEFF3]/60"
                    style={{ clipPath: 'polygon(0 0, 100% 0, 50% 100%)' }}
                  />
                  {/* Gold-trimmed satin ribbon */}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-1/2 h-3 -translate-y-1/2 border-y border-[#D8B477]/45 bg-[#EBA8B8]/45"
                  />
                  <div className="relative z-10 flex flex-col items-center py-2">
                    <div className="transition-transform duration-300 group-hover:scale-105">
                      <WaxSealSvg className="h-14 w-14 drop-shadow-sm" />
                    </div>
                    <span className="font-script mt-2 text-2xl text-[#A94F70]">
                      Happy 3 Months, {personal.herNickname}
                    </span>
                  </div>
                </div>

                {/* Three glowing hearts accent */}
                <div
                  aria-hidden="true"
                  className="mb-3 flex items-center justify-center gap-2 text-xs text-[#C97891]"
                >
                  <span>♡</span>
                  <span className="text-sm text-[#A94F70]">♡</span>
                  <span>♡</span>
                </div>

                {/* Invitation text */}
                <div className="relative z-10 mx-auto max-w-lg space-y-3 text-base leading-relaxed whitespace-pre-line text-[#50313F] sm:text-[17px]">
                  {chapter1.invitationText}
                </div>

                <div className="relative z-10 mt-7 flex justify-center">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onFirstOpen();
                    }}
                    className="inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-gradient-to-r from-[#B96281] to-[#A94F70] px-8 py-3.5 text-sm font-medium text-[#FFF7F2] shadow-lg shadow-[#A94F70]/25 transition-all hover:from-[#A94F70] hover:to-[#8F3D5B] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70] sm:text-base"
                  >
                    <Heart className="h-4 w-4 fill-current" />
                    <span>{chapter1.openButtonLabel}</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="opened-welcome"
              initial={{ opacity: 0, y: 20, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              className="mt-2 w-full"
            >
              <div className="stationery-panel paper-texture relative mx-auto max-w-2xl overflow-hidden rounded-3xl p-7 sm:p-11">
                {/* Inner gold framing border */}
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-3 rounded-2xl border border-[#D8B477]/35"
                />

                <div className="relative z-10">
                  <div className="mb-4 flex items-center justify-center gap-3">
                    <span className="h-px w-12 bg-[#D8B477]/70" />
                    <WaxSealSvg className="h-10 w-10" />
                    <span className="h-px w-12 bg-[#D8B477]/70" />
                  </div>

                  <p className="font-script text-3xl text-[#A94F70] sm:text-4xl">
                    {chapter1.anniversaryHighlightHeading}
                  </p>

                  <div className="mx-auto mt-5 max-w-lg text-left text-base leading-relaxed whitespace-pre-line text-[#50313F] sm:text-[17px]">
                    {chapter1.welcomeMessage}
                  </div>

                  {/* Editorial Three-Month Keepsake Note */}
                  <div className="mx-auto mt-7 max-w-lg rounded-2xl border border-[#C97891]/25 bg-[#F9E8ED]/60 p-4 text-left text-sm leading-relaxed whitespace-pre-line text-[#6C4757]">
                    {chapter1.anniversarySupportingText}
                  </div>

                  <div className="mt-7 flex items-center justify-between border-t border-[#D8B477]/35 pt-5 text-sm text-[#7E596A]">
                    <span className="font-handwriting text-2xl text-[#A94F70]">
                      — With all my love, {personal.ownerName}
                    </span>
                    <span className="text-xs font-medium tracking-wider uppercase">
                      {personal.anniversaryDate}
                    </span>
                  </div>

                  <div className="mt-8 flex justify-center">
                    <button
                      type="button"
                      onClick={onProceedToChapter2}
                      className="inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-gradient-to-r from-[#B96281] to-[#A94F70] px-8 py-3.5 text-sm font-medium text-[#FFF7F2] shadow-lg shadow-[#A94F70]/25 transition-all hover:from-[#A94F70] hover:to-[#8F3D5B] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70] sm:text-base"
                    >
                      <span>{chapter1.nextButtonLabel}</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
