import React from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ChapterId } from '../types/anniversary';
import {
  DECORATIVE_HEART_SPECS,
  DECORATIVE_ORB_SPECS,
  DECORATIVE_SPARKLE_SPECS,
  getChapterDecorativeVars,
} from '../utils/decorativeLayers';

interface ButterflyFlightSpec {
  id: string;
  sizeClass: string;
  wingColor: string;
  lowerWingColor: string;
  accentColor: string;
  goldDetail?: boolean;
  mobileVisible: boolean;
  duration: number;
  delay: number;
  wingSpeed: number;
  xPath: string[];
  yPath: string[];
  rotatePath: number[];
  scalePath: number[];
  opacityPath: number[];
  times: number[];
}

const BUTTERFLY_FLIGHTS: ButterflyFlightSpec[] = [
  {
    id: 'blush-monarch',
    sizeClass: 'h-8 w-8 sm:h-10 sm:w-10',
    wingColor: '#F6D0DA',
    lowerWingColor: '#EFAFC1',
    accentColor: '#C97A8F',
    goldDetail: true,
    mobileVisible: true,
    duration: 24,
    delay: 0,
    wingSpeed: 0.42,
    xPath: ['8vw', '28vw', '46vw', '68vw', '88vw', '72vw', '48vw', '22vw', '8vw'],
    yPath: ['26vh', '16vh', '24vh', '13vh', '28vh', '42vh', '32vh', '38vh', '26vh'],
    rotatePath: [14, -8, 12, -10, 18, -14, -6, 10, 14],
    scalePath: [0.92, 1.05, 0.96, 1.06, 0.94, 1.02, 0.95, 1.03, 0.92],
    opacityPath: [0, 0.9, 0.92, 0.88, 0.86, 0.9, 0.92, 0.85, 0],
    times: [0, 0.12, 0.25, 0.38, 0.52, 0.66, 0.78, 0.9, 1],
  },
  {
    id: 'peach-swallowtail',
    sizeClass: 'h-7 w-7 sm:h-9 sm:w-9',
    wingColor: '#F9D6CB',
    lowerWingColor: '#F3B8AA',
    accentColor: '#C46D7E',
    goldDetail: false,
    mobileVisible: true,
    duration: 29,
    delay: 0.4,
    wingSpeed: 0.48,
    xPath: ['86vw', '68vw', '52vw', '32vw', '14vw', '28vw', '54vw', '76vw', '86vw'],
    yPath: ['64vh', '52vh', '60vh', '46vh', '58vh', '72vh', '66vh', '74vh', '64vh'],
    rotatePath: [-16, 8, -12, 14, -18, 12, -8, 10, -16],
    scalePath: [0.9, 1.02, 0.95, 1.05, 0.9, 1, 0.94, 1.02, 0.9],
    opacityPath: [0, 0.86, 0.9, 0.88, 0.82, 0.88, 0.9, 0.84, 0],
    times: [0, 0.12, 0.26, 0.4, 0.54, 0.68, 0.8, 0.91, 1],
  },
  {
    id: 'mauve-petalwing',
    sizeClass: 'h-7 w-7 sm:h-8 sm:w-8',
    wingColor: '#EBD9EE',
    lowerWingColor: '#DFC3E4',
    accentColor: '#B88B9D',
    goldDetail: true,
    mobileVisible: false,
    duration: 27,
    delay: 1.1,
    wingSpeed: 0.38,
    xPath: ['18vw', '34vw', '24vw', '44vw', '64vw', '80vw', '62vw', '36vw', '18vw'],
    yPath: ['78vh', '62vh', '44vh', '30vh', '20vh', '34vh', '54vh', '70vh', '78vh'],
    rotatePath: [8, -14, 16, -6, 12, -16, 10, -12, 8],
    scalePath: [0.88, 0.98, 1.04, 0.96, 1.02, 0.92, 1, 0.95, 0.88],
    opacityPath: [0, 0.82, 0.88, 0.85, 0.84, 0.88, 0.84, 0.8, 0],
    times: [0, 0.1, 0.24, 0.38, 0.52, 0.66, 0.8, 0.92, 1],
  },
  {
    id: 'champagne-sprite',
    sizeClass: 'h-6 w-6 sm:h-7 sm:w-7',
    wingColor: '#F7E5D5',
    lowerWingColor: '#F3D4BD',
    accentColor: '#D7B477',
    goldDetail: true,
    mobileVisible: false,
    duration: 32,
    delay: 1.6,
    wingSpeed: 0.44,
    xPath: ['78vw', '60vw', '74vw', '56vw', '38vw', '20vw', '42vw', '64vw', '78vw'],
    yPath: ['20vh', '32vh', '48vh', '38vh', '22vh', '34vh', '16vh', '14vh', '20vh'],
    rotatePath: [-10, 14, -16, 8, -12, 16, -8, 10, -10],
    scalePath: [0.9, 1, 0.94, 1.04, 0.92, 1, 0.95, 1.02, 0.9],
    opacityPath: [0, 0.84, 0.86, 0.88, 0.82, 0.86, 0.88, 0.82, 0],
    times: [0, 0.12, 0.26, 0.4, 0.54, 0.68, 0.8, 0.91, 1],
  },
];

interface DelicateButterflySvgProps {
  className: string;
  wingColor: string;
  lowerWingColor: string;
  accentColor: string;
  goldDetail?: boolean;
  wingSpeed: number;
  reducedMotion: boolean;
}

const DelicateButterflySvg: React.FC<DelicateButterflySvgProps> = ({
  className,
  wingColor,
  lowerWingColor,
  accentColor,
  goldDetail = false,
  wingSpeed,
  reducedMotion,
}) => (
  <svg viewBox="0 0 48 42" fill="none" className={className} aria-hidden="true">
    <motion.g
      style={{ transformOrigin: '24px 21px' }}
      animate={
        reducedMotion
          ? undefined
          : {
              scaleX: [1, 0.3, 1],
              scaleY: [1, 0.94, 1],
            }
      }
      transition={
        reducedMotion
          ? undefined
          : {
              duration: wingSpeed,
              repeat: Infinity,
              ease: 'easeInOut',
            }
      }
    >
      {/* Upper left & right forewings */}
      <path
        d="M24 20 C16 5, 2.5 5.5, 4 17 C5.2 24.5, 15.5 25, 24 20 Z"
        fill={wingColor}
        stroke={accentColor}
        strokeWidth="1"
      />
      <path
        d="M24 20 C32 5, 45.5 5.5, 44 17 C42.8 24.5, 32.5 25, 24 20 Z"
        fill={wingColor}
        stroke={accentColor}
        strokeWidth="1"
      />

      {/* Delicate inner wing veining & pearl shimmer */}
      <path
        d="M22.5 19.5 Q14 13 8.5 14 M22.5 20 Q14 18 9.5 19.5"
        stroke={accentColor}
        strokeOpacity="0.45"
        strokeWidth="0.7"
        strokeLinecap="round"
      />
      <path
        d="M25.5 19.5 Q34 13 39.5 14 M25.5 20 Q34 18 38.5 19.5"
        stroke={accentColor}
        strokeOpacity="0.45"
        strokeWidth="0.7"
        strokeLinecap="round"
      />
      <circle cx="13.5" cy="14.5" r="2.2" fill="#FFFDF9" opacity="0.72" />
      <circle cx="34.5" cy="14.5" r="2.2" fill="#FFFDF9" opacity="0.72" />

      {/* Lower hindwings */}
      <path
        d="M24 21.5 C16.5 24, 9.5 32.5, 14 36 C18.5 38.5, 22.5 30, 24 21.5 Z"
        fill={lowerWingColor}
        stroke={accentColor}
        strokeWidth="0.9"
      />
      <path
        d="M24 21.5 C31.5 24, 38.5 32.5, 34 36 C29.5 38.5, 25.5 30, 24 21.5 Z"
        fill={lowerWingColor}
        stroke={accentColor}
        strokeWidth="0.9"
      />

      {goldDetail && (
        <>
          <circle cx="15.5" cy="31.5" r="1.2" fill="#D7B477" opacity="0.85" />
          <circle cx="32.5" cy="31.5" r="1.2" fill="#D7B477" opacity="0.85" />
        </>
      )}
    </motion.g>

    {/* Slender butterfly body & curled antennae */}
    <line
      x1="24"
      y1="12.5"
      x2="24"
      y2="32.5"
      stroke="#7F4C60"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    <circle cx="24" cy="12" r="1.5" fill="#7F4C60" />
    <path
      d="M24 12 Q21 7 18.2 6.5 M24 12 Q27 7 29.8 6.5"
      stroke="#7F4C60"
      strokeWidth="0.95"
      strokeLinecap="round"
    />
    <circle cx="18" cy="6.5" r="0.9" fill="#D7B477" />
    <circle cx="30" cy="6.5" r="0.9" fill="#D7B477" />
  </svg>
);

interface DecorativeElementsProps {
  currentChapter?: ChapterId;
}

export const DecorativeElements: React.FC<DecorativeElementsProps> = ({
  currentChapter = 1,
}) => {
  const prefersReducedMotion = Boolean(useReducedMotion());
  const chapterVars = getChapterDecorativeVars(currentChapter);

  return (
    <div
      aria-hidden="true"
      data-testid="decorative-elements"
      data-chapter-mood={currentChapter}
      className="pointer-events-none fixed inset-0 z-[25] overflow-hidden select-none"
      style={{
        pointerEvents: 'none',
        ...(chapterVars as unknown as React.CSSProperties),
      }}
    >
      {/* Layer 1: Gentle glowing atmospheric light orbs controlled by CSS variables */}
      <div
        data-testid="decorative-layer-orbs"
        className="pointer-events-none absolute inset-0"
      >
        {DECORATIVE_ORB_SPECS.map((orb) => (
          <div
            key={orb.id}
            data-testid={`decorative-orb-${orb.id}`}
            className={`animate-orb pointer-events-none absolute rounded-full blur-3xl ${
              orb.positionClass
            } ${orb.sizeClass} ${orb.mobileVisible ? '' : 'hidden sm:block'}`}
            style={
              {
                background: `radial-gradient(circle, color-mix(in srgb, ${orb.colorVar} ${Math.round(
                  orb.alpha * 100
                )}%, transparent) 0%, transparent 72%)`,
                '--orb-duration': orb.duration,
                '--orb-delay': orb.delay,
                '--orb-drift-x': orb.driftX,
                '--orb-drift-y': orb.driftY,
                '--orb-scale': orb.scale,
              } as React.CSSProperties
            }
          />
        ))}
      </div>

      {/* Layer 2: Subtle translucent floating hearts controlled by CSS variables */}
      <div
        data-testid="decorative-layer-hearts"
        className="pointer-events-none absolute inset-0"
      >
        {DECORATIVE_HEART_SPECS.map((heart) => (
          <span
            key={heart.id}
            data-testid={`decorative-heart-${heart.id}`}
            className={`animate-float-heart pointer-events-none absolute top-0 ${
              heart.mobileVisible ? '' : 'hidden sm:block'
            }`}
            style={
              {
                left: heart.left,
                color: heart.colorVar,
                '--heart-duration': heart.duration,
                '--heart-delay': heart.delay,
                '--heart-sway-a': heart.swayA,
                '--heart-sway-b': heart.swayB,
                '--heart-opacity': heart.opacity,
              } as React.CSSProperties
            }
          >
            <svg
              width={heart.size}
              height={heart.size}
              viewBox="0 0 16 16"
              fill="currentColor"
            >
              <path d="M8 14 C8 14, 1.5 9.6, 1.5 5.4 C1.5 3.3, 3.2 1.8, 5.2 1.8 C6.4 1.8, 7.4 2.4, 8 3.5 C8.6 2.4, 9.6 1.8, 10.8 1.8 C12.8 1.8, 14.5 3.3, 14.5 5.4 C14.5 9.6, 8 14, 8 14 Z" />
            </svg>
          </span>
        ))}
      </div>

      {/* Layer 3: Twinkling warm gold & ivory starlight sparkles controlled by CSS variables */}
      <div
        data-testid="decorative-layer-sparkles"
        className="pointer-events-none absolute inset-0"
      >
        {DECORATIVE_SPARKLE_SPECS.map((sp) => (
          <span
            key={sp.id}
            className={`animate-twinkle pointer-events-none absolute text-xs ${
              sp.mobileVisible ? '' : 'hidden sm:block'
            }`}
            style={
              {
                left: sp.left,
                top: sp.top,
                color: sp.colorVar,
                '--twinkle-delay': sp.delay,
                '--twinkle-duration': sp.duration,
                textShadow: '0 0 6px rgba(215, 180, 119, 0.55)',
              } as React.CSSProperties
            }
          >
            ✦
          </span>
        ))}
      </div>

      {/* Layer 4: Framer Motion delicate butterfly SVG illustrations on curved paths */}
      <div
        data-testid="decorative-layer-butterflies"
        className="pointer-events-none absolute inset-0"
      >
        {BUTTERFLY_FLIGHTS.map((bf) => (
          <motion.div
            key={bf.id}
            data-testid={`decorative-butterfly-${bf.id}`}
            className={`pointer-events-none absolute top-0 left-0 will-change-transform ${
              bf.mobileVisible ? '' : 'hidden sm:block'
            }`}
            style={{ pointerEvents: 'none' }}
            initial={{
              x: bf.xPath[0],
              y: bf.yPath[0],
              rotate: bf.rotatePath[0],
              scale: bf.scalePath[0],
              opacity: prefersReducedMotion ? 0.65 : 0,
            }}
            animate={
              prefersReducedMotion
                ? {
                    x: bf.xPath[1],
                    y: bf.yPath[1],
                    rotate: bf.rotatePath[1],
                    opacity: 0.65,
                  }
                : {
                    x: bf.xPath,
                    y: bf.yPath,
                    rotate: bf.rotatePath,
                    scale: bf.scalePath,
                    opacity: bf.opacityPath,
                  }
            }
            transition={
              prefersReducedMotion
                ? undefined
                : {
                    duration: bf.duration,
                    delay: bf.delay,
                    times: bf.times,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }
            }
          >
            <DelicateButterflySvg
              className={`${bf.sizeClass} drop-shadow-[0_4px_10px_rgba(182,95,125,0.22)]`}
              wingColor={bf.wingColor}
              lowerWingColor={bf.lowerWingColor}
              accentColor={bf.accentColor}
              goldDetail={bf.goldDetail}
              wingSpeed={bf.wingSpeed}
              reducedMotion={prefersReducedMotion}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
};
