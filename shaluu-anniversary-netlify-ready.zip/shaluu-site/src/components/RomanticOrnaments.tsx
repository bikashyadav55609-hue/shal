import React from 'react';

export const FLORAL_GARLAND_SRC =
  '/src/assets/images/floral_corner_garland_1794839656430.jpg';
export const GARDEN_ROSES_SRC =
  '/src/assets/images/botanical_garden_roses_1794839653597.jpg';

interface FloralCornerOrnamentProps {
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  className?: string;
}

export const FloralCornerOrnament: React.FC<FloralCornerOrnamentProps> = ({
  position = 'top-left',
  className = 'w-32 h-24 sm:w-44 sm:h-32',
}) => {
  const transformMap: Record<
    NonNullable<FloralCornerOrnamentProps['position']>,
    string
  > = {
    'top-left': '',
    'top-right': '-scale-x-100',
    'bottom-left': '-scale-y-100',
    'bottom-right': '-scale-x-100 -scale-y-100',
  };

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none select-none ${transformMap[position]} ${className}`}
    >
      <img
        src={FLORAL_GARLAND_SRC}
        alt=""
        aria-hidden="true"
        referrerPolicy="no-referrer"
        className="h-full w-full object-contain mix-blend-multiply opacity-90"
        style={{
          WebkitMaskImage:
            'radial-gradient(ellipse 88% 88% at 10% 10%, black 38%, rgba(0, 0, 0, 0.72) 56%, transparent 82%)',
          maskImage:
            'radial-gradient(ellipse 88% 88% at 10% 10%, black 38%, rgba(0, 0, 0, 0.72) 56%, transparent 82%)',
        }}
      />
    </div>
  );
};

export const GoldFloralDivider: React.FC<{ className?: string }> = ({
  className = '',
}) => (
  <div
    aria-hidden="true"
    className={`mx-auto flex max-w-md items-center justify-center gap-3 ${className}`}
  >
    <span className="h-px flex-1 bg-gradient-to-r from-transparent via-[#D7B477] to-[#D7B477]/65" />
    {/* Three miniature rosebuds & center heart motif for 3 months */}
    <svg viewBox="0 0 92 24" className="h-5 w-24 shrink-0" fill="none">
      <path
        d="M8 12 Q16 7 24 12"
        stroke="#A5B99B"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <circle cx="24" cy="12" r="3.2" fill="#EFAFC1" />
      <circle cx="24" cy="12" r="1.4" fill="#B65F7D" />
      <path
        d="M46 19 C46 19, 37.5 13.5, 37.5 8.5 C37.5 6, 39.6 4.2, 42.2 4.2 C43.9 4.2, 45.2 5, 46 6.4 C46.8 5, 48.1 4.2, 49.8 4.2 C52.4 4.2, 54.5 6, 54.5 8.5 C54.5 13.5, 46 19, 46 19 Z"
        fill="#D58AA3"
      />
      <path
        d="M84 12 Q76 7 68 12"
        stroke="#A5B99B"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <circle cx="68" cy="12" r="3.2" fill="#EFAFC1" />
      <circle cx="68" cy="12" r="1.4" fill="#B65F7D" />
    </svg>
    <span className="h-px flex-1 bg-gradient-to-l from-transparent via-[#D7B477] to-[#D7B477]/65" />
  </div>
);

export const ThreeMonthEmblem: React.FC<{
  badgeText?: string;
  className?: string;
}> = ({ badgeText = '03 MONTHS · ONE SPECIAL LOVE', className = '' }) => (
  <div className={`flex flex-col items-center ${className}`}>
    <div className="relative flex items-center justify-center gap-3">
      <svg viewBox="0 0 28 28" className="animate-sway h-6 w-6" fill="none" aria-hidden="true">
        <circle cx="14" cy="14" r="9" fill="#F6D0DA" />
        <circle cx="14" cy="14" r="5.5" fill="#D58AA3" />
        <path
          d="M11 14 C11 11.5, 17 11.5, 17 14"
          stroke="#FFF6F0"
          strokeWidth="1.3"
          strokeLinecap="round"
        />
      </svg>

      <div className="flex items-baseline gap-2 border-y border-[#D7B477]/65 px-4 py-1">
        <span className="font-serif-display text-3xl font-semibold tracking-tight text-[#B65F7D] sm:text-4xl">
          03
        </span>
        <span className="text-[11px] font-semibold tracking-[0.22em] text-[#7F5A6B] uppercase">
          Months of Love
        </span>
      </div>

      <svg
        viewBox="0 0 28 28"
        className="animate-sway h-6 w-6"
        style={{ animationDelay: '0.8s' }}
        fill="none"
        aria-hidden="true"
      >
        <circle cx="14" cy="14" r="9" fill="#F6D0DA" />
        <circle cx="14" cy="14" r="5.5" fill="#D58AA3" />
        <path
          d="M11 14 C11 11.5, 17 11.5, 17 14"
          stroke="#FFF6F0"
          strokeWidth="1.3"
          strokeLinecap="round"
        />
      </svg>
    </div>
    <p className="mt-2 text-[11px] font-medium tracking-[0.22em] text-[#B65F7D] uppercase">
      {badgeText}
    </p>
  </div>
);

export const ButterflyAccent: React.FC<{
  className?: string;
  wingColor?: string;
  accentColor?: string;
}> = ({
  className = 'w-8 h-8',
  wingColor = '#F6D0DA',
  accentColor = '#D58AA3',
}) => (
  <svg
    viewBox="0 0 40 36"
    fill="none"
    className={className}
    aria-hidden="true"
  >
    <g className="animate-butterfly-wing">
      <path
        d="M20 18 C14 5, 2 5, 3.5 15 C4.8 21.5, 13 22, 20 18 Z"
        fill={wingColor}
        stroke={accentColor}
        strokeWidth="1"
      />
      <path
        d="M20 18 C26 5, 38 5, 36.5 15 C35.2 21.5, 27 22, 20 18 Z"
        fill={wingColor}
        stroke={accentColor}
        strokeWidth="1"
      />
      <circle cx="12" cy="13.5" r="2.1" fill="#FFF6F0" opacity="0.65" />
      <circle cx="28" cy="13.5" r="2.1" fill="#FFF6F0" opacity="0.65" />
      <path
        d="M20 19 C14 21, 8 28, 12 31 C16 33, 19 26, 20 19 Z"
        fill="#EFAFC1"
        stroke={accentColor}
        strokeWidth="0.9"
      />
      <path
        d="M20 19 C26 21, 32 28, 28 31 C24 33, 21 26, 20 19 Z"
        fill="#EFAFC1"
        stroke={accentColor}
        strokeWidth="0.9"
      />
    </g>
    <line
      x1="20"
      y1="10"
      x2="20"
      y2="28"
      stroke="#7F4C60"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M20 11 Q17.5 6.5 15.5 6 M20 11 Q22.5 6.5 24.5 6"
      stroke="#7F4C60"
      strokeWidth="0.9"
      strokeLinecap="round"
    />
  </svg>
);

export const SwayingFloralSprig: React.FC<{
  className?: string;
  flip?: boolean;
}> = ({ className = 'w-16 h-20', flip = false }) => (
  <svg
    viewBox="0 0 64 80"
    fill="none"
    aria-hidden="true"
    className={`animate-sway pointer-events-none select-none ${
      flip ? '-scale-x-100' : ''
    } ${className}`}
  >
    <path
      d="M32 76 Q29 48 34 14"
      stroke="#8CA784"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <ellipse
      cx="23"
      cy="54"
      rx="9"
      ry="4.5"
      transform="rotate(-28 23 54)"
      fill="#A5B99B"
      opacity="0.85"
    />
    <ellipse
      cx="40"
      cy="44"
      rx="9"
      ry="4.5"
      transform="rotate(26 40 44)"
      fill="#95AC8B"
      opacity="0.85"
    />
    <ellipse
      cx="24"
      cy="31"
      rx="7.5"
      ry="3.8"
      transform="rotate(-24 24 31)"
      fill="#A5B99B"
      opacity="0.85"
    />
    {/* Tiny rosebud tip */}
    <circle cx="34" cy="14" r="6" fill="#F6D0DA" />
    <circle cx="34" cy="14" r="3.5" fill="#D58AA3" />
    <circle cx="21" cy="24" r="4" fill="#F9D6CB" />
    <circle cx="43" cy="34" r="3.8" fill="#EFAFC1" />
  </svg>
);
