import React from 'react';

interface PetalOverlayProps {
  active: boolean;
  nightMode?: boolean;
}

const PETAL_PATHS = [
  'M9 1 C14 4, 16 11, 9 19 C2 11, 4 4, 9 1 Z',
  'M8 2 C13 2, 16 8, 12 15 C9 19, 5 18, 3 13 C1 8, 4 3, 8 2 Z',
  'M9 1 C12 3, 15 6, 14 11 C13 16, 9 19, 6 17 C3 15, 2 10, 4 5 C5 2, 7 1, 9 1 Z',
  'M8 2 C10 4, 14 3, 15 8 C16 13, 11 18, 7 18 C3 17, 1 11, 3 6 C4 3, 6 1, 8 2 Z',
  'M9 2 C13 5, 14 12, 9 18 C7 16, 4 14, 3 10 C2 6, 5 2, 9 2 Z',
];

const PETAL_SPECS = [
  { left: '4%', duration: '14s', delay: '-3s', size: 20, color: '#EFA5BA', pathIdx: 0, swayA: '26px', swayB: '-18px', swayC: '30px', mobile: true },
  { left: '11%', duration: '18s', delay: '-9s', size: 17, color: '#E596AE', pathIdx: 1, swayA: '-22px', swayB: '20px', swayC: '-26px', mobile: false },
  { left: '19%', duration: '15s', delay: '-5s', size: 19, color: '#F5C4B6', pathIdx: 2, swayA: '18px', swayB: '-24px', swayC: '22px', mobile: true },
  { left: '27%', duration: '19s', delay: '-12s', size: 16, color: '#D58AA3', pathIdx: 3, swayA: '-16px', swayB: '28px', swayC: '-14px', mobile: false },
  { left: '36%', duration: '13s', delay: '-2s', size: 21, color: '#F2B8C7', pathIdx: 4, swayA: '22px', swayB: '-16px', swayC: '28px', mobile: true },
  { left: '44%', duration: '17s', delay: '-10s', size: 17, color: '#F7D2DC', pathIdx: 0, swayA: '-24px', swayB: '16px', swayC: '-20px', mobile: false },
  { left: '53%', duration: '16s', delay: '-6s', size: 19, color: '#EFA5BA', pathIdx: 1, swayA: '28px', swayB: '-22px', swayC: '18px', mobile: true },
  { left: '61%', duration: '19s', delay: '-14s', size: 16, color: '#F5C4B6', pathIdx: 2, swayA: '-20px', swayB: '24px', swayC: '-28px', mobile: false },
  { left: '69%', duration: '14s', delay: '-4s', size: 20, color: '#F2B8C7', pathIdx: 3, swayA: '20px', swayB: '-18px', swayC: '32px', mobile: true },
  { left: '77%', duration: '17s', delay: '-11s', size: 18, color: '#D58AA3', pathIdx: 4, swayA: '-26px', swayB: '18px', swayC: '-18px', mobile: false },
  { left: '84%', duration: '15s', delay: '-7s', size: 19, color: '#F7D2DC', pathIdx: 0, swayA: '18px', swayB: '-24px', swayC: '20px', mobile: true },
  { left: '91%', duration: '18s', delay: '-13s', size: 17, color: '#E596AE', pathIdx: 2, swayA: '-18px', swayB: '22px', swayC: '-24px', mobile: false },
  { left: '96%', duration: '16s', delay: '-1s', size: 18, color: '#F5C4B6', pathIdx: 1, swayA: '-24px', swayB: '12px', swayC: '-28px', mobile: true },
];

export const PetalOverlay: React.FC<PetalOverlayProps> = ({
  active,
  nightMode = false,
}) => {
  if (!active) return null;

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 z-[25] overflow-hidden select-none"
    >
      {/* Continuous falling realistic rose petals */}
      {PETAL_SPECS.map((petal, idx) => (
        <span
          key={`petal-${idx}`}
          className={`animate-petal absolute top-0 block ${
            petal.mobile ? '' : 'hidden sm:block'
          }`}
          style={
            {
              left: petal.left,
              '--petal-duration': petal.duration,
              '--petal-delay': petal.delay,
              '--petal-sway-a': petal.swayA,
              '--petal-sway-b': petal.swayB,
              '--petal-sway-c': petal.swayC,
              '--petal-opacity': nightMode ? 0.8 : 0.84,
            } as React.CSSProperties
          }
        >
          <svg
            width={petal.size}
            height={petal.size * 1.25}
            viewBox="0 0 18 22"
            fill="none"
          >
            <path d={PETAL_PATHS[petal.pathIdx]} fill={petal.color} />
            <path
              d="M9 4 Q10 10 8.5 16"
              stroke="#FFFFFF"
              strokeOpacity="0.32"
              strokeWidth="0.7"
              strokeLinecap="round"
            />
          </svg>
        </span>
      ))}

    </div>
  );
};
