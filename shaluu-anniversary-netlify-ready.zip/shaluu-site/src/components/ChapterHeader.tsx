import React from 'react';
import { SlidersHorizontal } from 'lucide-react';
import { ChapterId } from '../types/anniversary';

interface ChapterHeaderProps {
  siteTitle: string;
  currentChapter: ChapterId;
  highestUnlockedChapter: ChapterId;
  previewMode: boolean;
  onSelectChapter: (chapter: ChapterId) => void;
  onOpenCustomize: () => void;
  musicSlot: React.ReactNode;
}

const CHAPTER_LABELS: Record<ChapterId, string> = {
  1: 'Invitation',
  2: 'Gallery',
  3: 'Reasons',
  4: 'Bouquet',
};

export const ChapterHeader: React.FC<ChapterHeaderProps> = ({
  siteTitle,
  currentChapter,
  highestUnlockedChapter,
  previewMode,
  onSelectChapter,
  onOpenCustomize,
  musicSlot,
}) => {
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--theme-gold-border)] bg-[var(--theme-bg)]/90 text-[var(--theme-ink)] backdrop-blur-md transition-colors duration-500">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        {/* Zone 1: Brand Title */}
        <button
          type="button"
          onClick={() => onSelectChapter(1)}
          className="font-serif-display min-w-0 truncate text-left text-base font-semibold tracking-tight text-[var(--theme-ink)] sm:text-lg"
          title={siteTitle}
        >
          <span className="sm:hidden">For Shaluu ♡</span>
          <span className="hidden sm:inline">{siteTitle}</span>
        </button>

        {/* Zone 2: Chapter Progress Indicator */}
        <nav
          aria-label="Chapter progress"
          className="hidden items-center gap-1.5 md:flex"
        >
          <span className="mr-2 text-xs font-medium text-[var(--theme-ink-muted)] tabular-nums">
            Chapter {currentChapter} of 4
          </span>
          {([1, 2, 3, 4] as ChapterId[]).map((ch) => {
            const unlocked = previewMode || ch <= highestUnlockedChapter;
            const active = ch === currentChapter;
            return (
              <button
                key={ch}
                type="button"
                disabled={!unlocked}
                onClick={() => unlocked && onSelectChapter(ch)}
                aria-current={active ? 'step' : undefined}
                aria-label={`Chapter ${ch}: ${CHAPTER_LABELS[ch]}`}
                className={`whitespace-nowrap rounded-full px-3 py-1 text-xs font-medium transition-colors ${
                  active
                    ? 'bg-[var(--theme-accent)] text-white shadow-xs'
                    : unlocked
                    ? 'text-[var(--theme-ink-muted)] hover:bg-[var(--theme-bg-soft)] hover:text-[var(--theme-ink)]'
                    : 'cursor-not-allowed opacity-40'
                }`}
              >
                {ch}. {CHAPTER_LABELS[ch]}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Music & Owner Customize */}
        <div className="flex shrink-0 items-center gap-2">
          <span className="text-xs font-medium text-[var(--theme-ink-muted)] tabular-nums md:hidden">
            {currentChapter}/4
          </span>
          {musicSlot}
          <button
            type="button"
            onClick={onOpenCustomize}
            aria-label="Customize website"
            title="Owner customization panel"
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-full border border-[var(--theme-border)] bg-[var(--theme-surface)] px-3 py-1.5 text-xs font-medium text-[var(--theme-ink-muted)] transition-colors hover:bg-[var(--theme-bg-soft)] hover:text-[var(--theme-ink)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--theme-accent)]"
          >
            <SlidersHorizontal className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Customize</span>
          </button>
        </div>
      </div>
    </header>
  );
};
