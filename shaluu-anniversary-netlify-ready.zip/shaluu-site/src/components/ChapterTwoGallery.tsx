import React, { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import {
  ArrowLeft,
  ArrowRight,
  Camera,
  ImagePlus,
} from 'lucide-react';
import { AnniversaryContent, GalleryPhoto } from '../types/anniversary';
import { getAllGalleryPhotos } from '../utils/anniversaryStore';
import { LightboxModal } from './LightboxModal';
import {
  ButterflyAccent,
  FloralCornerOrnament,
  GoldFloralDivider,
  SwayingFloralSprig,
} from './RomanticOrnaments';

interface ChapterTwoGalleryProps {
  content: AnniversaryContent;
  onPrevChapter: () => void;
  onNextChapter: () => void;
  onOpenGalleryCustomize: () => void;
}

export const ChapterTwoGallery: React.FC<ChapterTwoGalleryProps> = ({
  content,
  onPrevChapter,
  onNextChapter,
  onOpenGalleryCustomize,
}) => {
  const { chapter2 } = content;
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const [brokenIds, setBrokenIds] = useState<Record<string, boolean>>({});

  const allPhotos = useMemo(
    () => getAllGalleryPhotos(chapter2.sections),
    [chapter2.sections]
  );

  const openPhotoInLightbox = (photoId: string) => {
    const idx = allPhotos.findIndex((item) => item.photo.id === photoId);
    if (idx !== -1) {
      setLightboxIndex(idx);
    }
  };

  const renderPolaroid = (
    photo: GalleryPhoto,
    sectionTitle: string,
    index: number,
    variant: 'featured' | 'layered' | 'finale' = 'layered'
  ) => {
    const isBroken = brokenIds[photo.id];
    const tiltClass =
      variant === 'layered'
        ? index % 2 === 0
          ? 'sm:-rotate-1'
          : 'sm:rotate-1'
        : '';

    return (
      <motion.button
        key={photo.id}
        type="button"
        onClick={() => openPhotoInLightbox(photo.id)}
        initial={{ opacity: 0, y: 16 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.15 }}
        transition={{ duration: 0.45, delay: Math.min(index * 0.06, 0.24) }}
        aria-label={`View photograph: ${photo.caption || sectionTitle}`}
        className={`group relative flex w-full flex-col overflow-hidden rounded-2xl border border-[#D58AA3]/28 bg-[#FFFDFB] p-3.5 pb-6 text-left shadow-[0_18px_42px_-18px_rgba(182,95,125,0.28)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_48px_-18px_rgba(182,95,125,0.38)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#B65F7D] ${tiltClass} ${
          variant === 'featured' || variant === 'finale'
            ? 'mx-auto max-w-xl'
            : ''
        }`}
      >
        {/* Subtle blush washi-tape detail at top center */}
        <span
          aria-hidden="true"
          className="mx-auto -mt-1 mb-2.5 block h-2.5 w-16 rounded-xs bg-[#F6D0DA]/75"
        />

        <div className="relative flex w-full items-center justify-center overflow-hidden rounded-xl bg-gradient-to-b from-[#FDF0F4] to-[#F9E3E9] p-2.5">
          {!isBroken ? (
            <img
              src={photo.dataUrl}
              alt={photo.alt || photo.caption || `${sectionTitle} photo`}
              referrerPolicy="no-referrer"
              onError={() =>
                setBrokenIds((prev) => ({ ...prev, [photo.id]: true }))
              }
              className={`mx-auto w-auto max-w-full rounded-lg object-contain transition-transform duration-500 group-hover:scale-[1.02] ${
                variant === 'featured' || variant === 'finale'
                  ? 'max-h-[460px]'
                  : 'max-h-[340px]'
              }`}
            />
          ) : (
            <div className="flex h-56 w-full flex-col items-center justify-center gap-2 rounded-lg bg-[#FDF0F4] px-4 text-center text-sm text-[#7F5A6B]">
              <Camera className="h-6 w-6 opacity-60" />
              <span>Photograph could not be displayed</span>
            </div>
          )}
        </div>

        <div className="mt-4 flex items-start justify-between gap-2 px-1">
          <p className="font-handwriting text-xl leading-snug text-[#563443] sm:text-2xl">
            {photo.caption || sectionTitle}
          </p>
          {photo.isFeatured && (
            <span
              className="mt-1 shrink-0 text-xs font-medium text-[#D7B477]"
              title="Featured photograph"
            >
              ★
            </span>
          )}
        </div>
      </motion.button>
    );
  };

  return (
    <section
      aria-label="Chapter 2: My Favorite Girl"
      className="paper-texture relative overflow-hidden py-10 sm:py-16"
      style={{
        background:
          'linear-gradient(180deg, #FFF6F0 0%, #FCE8EE 48%, #F7DCE4 82%, #F7E5D5 100%)',
      }}
    >
      {/* Soft rose sunlit bloom */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 18% 12%, rgba(255, 246, 240, 0.85) 0%, transparent 48%), radial-gradient(circle at 84% 72%, rgba(239, 175, 193, 0.25) 0%, transparent 52%)',
        }}
      />

      {/* Corner Floral Ornaments */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 opacity-85"
      >
        <FloralCornerOrnament
          position="top-left"
          className="h-28 w-36 sm:h-44 sm:w-56"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 right-0 hidden opacity-75 sm:block"
      >
        <FloralCornerOrnament
          position="top-right"
          className="h-36 w-48"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute bottom-0 left-0 hidden opacity-70 sm:block"
      >
        <FloralCornerOrnament
          position="bottom-left"
          className="h-36 w-44"
        />
      </div>

      <div className="relative z-20 mx-auto max-w-5xl px-4 sm:px-6">
        {/* Editorial Chapter Header */}
        <div className="mb-12 text-center">
          <p className="text-[11px] font-semibold tracking-[0.24em] text-[#7F5A6B] uppercase">
            CHAPTER II &nbsp;·&nbsp; A LITTLE CELEBRATION OF YOU
          </p>
          <div className="mt-2 flex items-center justify-center gap-3">
            <SwayingFloralSprig className="hidden h-12 w-10 opacity-75 sm:block" />
            <h1 className="font-serif-display text-balance text-4xl font-semibold tracking-tight text-[#563443] sm:text-5xl md:text-6xl">
              {chapter2.heading}
            </h1>
            <SwayingFloralSprig
              flip
              className="hidden h-12 w-10 opacity-75 sm:block"
            />
          </div>
          <p className="font-serif-display mt-2 text-xl italic text-[#B65F7D] sm:text-2xl">
            {chapter2.subheading}
          </p>
          <p className="font-handwriting mt-1.5 text-2xl text-[#7F5A6B]">
            {chapter2.handwrittenNote}
          </p>
          <GoldFloralDivider className="mt-5" />
        </div>

        {/* Four Varied Editorial Gallery Sections */}
        <div className="space-y-16">
          {chapter2.sections.map((section, sectionIdx) => {
            const orderedPhotos = [...section.photos].sort((a, b) =>
              a.isFeatured === b.isFeatured ? 0 : a.isFeatured ? -1 : 1
            );
            const isSpotlight =
              section.layoutHint === 'featured' ||
              section.layoutHint === 'finale';

            return (
              <div
                key={section.id}
                className="relative border-t border-[#D8B477]/35 pt-10 first:border-t-0 first:pt-0"
              >
                <div className="mb-7 flex flex-wrap items-end justify-between gap-3">
                  <div>
                    <p className="text-xs font-semibold tracking-[0.14em] text-[#A94F70] uppercase">
                      0{sectionIdx + 1}. {section.subtitle}
                    </p>
                    <h2 className="font-serif-display mt-1 text-2xl font-semibold text-[#50313F] sm:text-3xl">
                      {section.title}
                    </h2>
                  </div>
                  <span className="text-xs font-medium text-[#7E596A] tabular-nums">
                    {section.photos.length}{' '}
                    {section.photos.length === 1 ? 'photograph' : 'photographs'}
                  </span>
                </div>

                {orderedPhotos.length === 0 ? (
                  /* Romantic Empty Stationery Placeholder — Never Fake Portraits */
                  <div className="stationery-panel paper-texture relative mx-auto flex max-w-2xl flex-col items-center overflow-hidden rounded-3xl px-6 py-10 text-center">
                    <div
                      aria-hidden="true"
                      className="pointer-events-none absolute inset-2.5 rounded-2xl border border-dashed border-[#C97891]/35"
                    />
                    <ButterflyAccent className="mb-2 h-7 w-7 opacity-80" />
                    <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-[#F9E3E9] text-[#A94F70]">
                      <ImagePlus className="h-5 w-5" />
                    </div>
                    <p className="font-handwriting text-2xl text-[#50313F] sm:text-3xl">
                      “{section.placeholderCaption}”
                    </p>
                    <p className="mt-2 max-w-md text-sm text-[#7E596A]">
                      Waiting for your favorite real photographs in “
                      {section.title}”. Open Customize to upload JPG, JPEG, PNG,
                      or WebP images.
                    </p>
                    <button
                      type="button"
                      onClick={onOpenGalleryCustomize}
                      aria-label={`Add photos to ${section.title}`}
                      className="relative z-10 mt-5 inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[#C97891]/40 bg-[#FFF7F2] px-5 py-2 text-xs font-medium text-[#A94F70] shadow-xs transition-colors hover:bg-[#F9E3E9] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
                    >
                      <Camera className="h-4 w-4" />
                      <span>Add Photos to This Section</span>
                    </button>
                  </div>
                ) : isSpotlight && orderedPhotos.length === 1 ? (
                  <div className="grid grid-cols-1 items-center gap-8 md:grid-cols-12">
                    <div className="md:col-span-7">
                      {renderPolaroid(
                        orderedPhotos[0],
                        section.title,
                        0,
                        section.layoutHint === 'finale' ? 'finale' : 'featured'
                      )}
                    </div>
                    <div className="stationery-panel rounded-3xl p-6 text-center md:col-span-5 md:text-left">
                      <p className="font-script text-3xl text-[#A94F70]">
                        {section.layoutHint === 'finale'
                          ? 'Forever my favorite'
                          : 'Right here'}
                      </p>
                      <p className="font-serif-display mt-2 text-xl italic leading-relaxed text-[#50313F]">
                        “
                        {orderedPhotos[0].caption ||
                          section.placeholderCaption}
                        ”
                      </p>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`grid items-start gap-6 ${
                      section.layoutHint === 'mini'
                        ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
                        : 'grid-cols-1 md:grid-cols-2'
                    }`}
                  >
                    {orderedPhotos.map((photo, idx) =>
                      renderPolaroid(
                        photo,
                        section.title,
                        idx,
                        isSpotlight && idx === 0 ? 'featured' : 'layered'
                      )
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Chapter 2 Closing & Navigation */}
        <div className="stationery-panel paper-texture relative mt-16 overflow-hidden rounded-3xl p-7 text-center sm:p-10">
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D8B477]/35"
          />
          <div className="relative z-10">
            <GoldFloralDivider className="mb-4" />
            <p className="font-serif-display mx-auto max-w-xl text-2xl italic text-[#50313F] sm:text-3xl">
              “{chapter2.closingLine}”
            </p>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
              <button
                type="button"
                onClick={onPrevChapter}
                className="inline-flex min-h-[48px] items-center gap-2 rounded-full border border-[#C97891]/35 bg-[#FFF7F2] px-6 py-3 text-sm font-medium text-[#50313F] transition-colors hover:bg-[#F9E3E9] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Chapter 1</span>
              </button>
              <button
                type="button"
                onClick={onNextChapter}
                className="inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-gradient-to-r from-[#B96281] to-[#A94F70] px-7 py-3 text-sm font-medium text-[#FFF7F2] shadow-md shadow-[#A94F70]/25 transition-all hover:from-[#A94F70] hover:to-[#8F3D5B] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
              >
                <span>{chapter2.nextButtonLabel}</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <LightboxModal
        items={allPhotos}
        activeIndex={lightboxIndex}
        onClose={() => setLightboxIndex(null)}
        onNavigate={(next) => setLightboxIndex(next)}
      />
    </section>
  );
};
