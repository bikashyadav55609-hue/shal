import React, { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { RotateCcw } from 'lucide-react';
import {
  BOUQUET_ASSETS,
  BOUQUET_FINAL_STEP,
  BOUQUET_FLORAL_PIECES,
  BOUQUET_TIMELINE,
  getBouquetStageCaption,
} from '../utils/bouquetTimeline';
import {
  BouquetFinalSparkles,
  BouquetPiece,
  BouquetRibbonBow,
  BouquetStems,
  BouquetWrappingLayers,
} from './BouquetFlowerParts';

interface VirtualBouquetProps {
  bouquetTitle: string;
  onAssemblyComplete: () => void;
}

export const VirtualBouquet: React.FC<VirtualBouquetProps> = ({
  bouquetTitle,
  onAssemblyComplete,
}) => {
  const prefersReducedMotion =
    typeof window !== 'undefined' &&
    window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  // Always start EMPTY (step 0) when Chapter 4 opens unless reduced motion is enabled
  const [step, setStep] = useState<number>(() =>
    prefersReducedMotion ? BOUQUET_FINAL_STEP : 0
  );
  const [runId, setRunId] = useState(0);

  // Preload all 11 individual transparent botanical PNGs immediately
  useEffect(() => {
    Object.values(BOUQUET_ASSETS).forEach((src) => {
      const img = new Image();
      img.src = src;
    });
  }, []);

  useEffect(() => {
    if (prefersReducedMotion) {
      setStep(BOUQUET_FINAL_STEP);
      onAssemblyComplete();
      return;
    }

    setStep(0);
    const timers = BOUQUET_TIMELINE.map((item) =>
      window.setTimeout(() => {
        setStep(item.step);
        if (item.step === BOUQUET_FINAL_STEP) {
          onAssemblyComplete();
        }
      }, item.delayMs)
    );

    return () => {
      timers.forEach((t) => window.clearTimeout(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [runId, prefersReducedMotion]);

  const handleReplayBouquet = () => {
    setStep(0);
    setRunId((n) => n + 1);
  };

  const completed = step >= BOUQUET_FINAL_STEP;

  return (
    <div
      className="relative mx-auto flex w-full max-w-xl flex-col items-center justify-center py-2"
      data-testid="virtual-bouquet"
      data-bouquet-step={step}
      data-bouquet-run={runId}
    >
      {/* Dreamy sunlit blush & warm-ivory floral aura behind bouquet (no rectangular photo frame) */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-[44%] left-1/2 h-[360px] w-[360px] -translate-x-1/2 -translate-y-1/2 rounded-full blur-3xl sm:h-[440px] sm:w-[440px]"
        style={{
          background:
            'radial-gradient(circle, rgba(255, 246, 240, 0.92) 0%, rgba(246, 208, 218, 0.52) 52%, transparent 76%)',
        }}
      />

      {/* Open, unframed floral assembly canvas */}
      <div
        key={`bouquet-canvas-${runId}`}
        className={`relative z-10 aspect-[380/440] w-full max-w-[350px] sm:max-w-[420px] ${
          completed && !prefersReducedMotion ? 'animate-bouquet-breathe' : ''
        }`}
      >
        {/* Subtle radial anchor halo at the base of the stems */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute bottom-[6%] left-1/2 h-16 w-48 -translate-x-1/2 rounded-full bg-[#B65F7D]/15 blur-xl"
        />

        {/* Animation 1: Stems rising from lower center */}
        <BouquetStems visible={step >= 1} instant={prefersReducedMotion} />

        {/* Animation 11 (back cone) & front blush wrapping layers */}
        <BouquetWrappingLayers
          visible={step >= 11}
          instant={prefersReducedMotion}
        />

        {/* Animations 1–10: Individual realistic transparent botanical assets */}
        {BOUQUET_FLORAL_PIECES.map((piece) => (
          <BouquetPiece
            key={`${runId}-${piece.id}`}
            spec={piece}
            visible={step >= piece.minStep}
            instant={prefersReducedMotion}
          />
        ))}

        {/* Animation 12: Dusty-rose satin ribbon & bow */}
        <BouquetRibbonBow
          visible={step >= 12}
          instant={prefersReducedMotion}
        />

        {/* Animation 13: Final celebration petals & warm gold sparkles */}
        <BouquetFinalSparkles visible={completed} />
      </div>

      {/* Live Assembly Status Note (visible while arranging, transitions into revealed title) */}
      <div className="relative z-20 mt-3 min-h-[112px] w-full text-center">
        <AnimatePresence mode="wait">
          {!completed ? (
            <motion.div
              key="bouquet-progress"
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.22 }}
              className="flex flex-col items-center gap-2 pt-2"
            >
              <p className="font-serif-display text-lg italic text-[#8D4B63] sm:text-xl">
                {getBouquetStageCaption(step)}
              </p>
              <div
                aria-hidden="true"
                className="flex items-center gap-1.5"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((dot) => (
                  <span
                    key={dot}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      step >= dot
                        ? 'w-3 bg-[#B65F7D]'
                        : 'w-1.5 bg-[#D58AA3]/35'
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="bouquet-completed-heading"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65 }}
              className="flex flex-col items-center gap-3.5"
            >
              <h2 className="font-script text-balance text-4xl text-[#B65F7D] drop-shadow-xs sm:whitespace-nowrap sm:text-[44px]">
                {bouquetTitle}
              </h2>
              {!prefersReducedMotion && (
                <button
                  type="button"
                  onClick={handleReplayBouquet}
                  className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[#D58AA3]/45 bg-[#FFF9F5]/90 px-5 py-2 text-xs font-medium text-[#7F5A6B] shadow-xs transition-colors hover:bg-[#FFF6F0] hover:text-[#B65F7D] focus-visible:outline-2 focus-visible:outline-[#B65F7D] sm:text-sm"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  <span>Watch the Bouquet Bloom Again ♡</span>
                </button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
