import React from 'react';
import { motion } from 'motion/react';
import { BouquetPieceSpec } from '../utils/bouquetTimeline';

interface BouquetStemsProps {
  visible: boolean;
  instant?: boolean;
}

const STEM_SPECS = [
  { id: 'stem-1', xTop: 118, yTop: 120, xCtrl: 145, delay: 0, width: 4.2, color: '#6E8E64' },
  { id: 'stem-2', xTop: 152, yTop: 95, xCtrl: 165, delay: 0.14, width: 4.5, color: '#7A9A6E' },
  { id: 'stem-3', xTop: 190, yTop: 88, xCtrl: 188, delay: 0.26, width: 4.8, color: '#66875C' },
  { id: 'stem-4', xTop: 224, yTop: 96, xCtrl: 210, delay: 0.38, width: 4.5, color: '#7D9D71' },
  { id: 'stem-5', xTop: 258, yTop: 125, xCtrl: 232, delay: 0.50, width: 4.2, color: '#6A8A60' },
  { id: 'stem-6', xTop: 138, yTop: 155, xCtrl: 160, delay: 0.62, width: 3.8, color: '#84A378' },
  { id: 'stem-7', xTop: 242, yTop: 158, xCtrl: 220, delay: 0.72, width: 3.8, color: '#84A378' },
];

export const BouquetStems: React.FC<BouquetStemsProps> = ({
  visible,
  instant = false,
}) => {
  if (!visible) return null;

  return (
    <svg
      viewBox="0 0 380 440"
      className="pointer-events-none absolute inset-0 z-10 h-full w-full"
      fill="none"
      aria-hidden="true"
    >
      {STEM_SPECS.map((stem) => (
        <motion.path
          key={stem.id}
          d={`M190 406 Q${stem.xCtrl} 275 ${stem.xTop} ${stem.yTop}`}
          stroke={stem.color}
          strokeWidth={stem.width}
          strokeLinecap="round"
          initial={instant ? { pathLength: 1, opacity: 1 } : { pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 0.96 }}
          transition={{
            duration: instant ? 0 : 0.95,
            delay: instant ? 0 : stem.delay,
            ease: [0.22, 1, 0.36, 1],
          }}
        />
      ))}
    </svg>
  );
};

interface BouquetPieceProps {
  spec: BouquetPieceSpec;
  visible: boolean;
  instant?: boolean;
}

export const BouquetPiece: React.FC<BouquetPieceProps> = ({
  spec,
  visible,
  instant = false,
}) => {
  if (!visible) return null;

  const flipFactor = spec.flipX ? -1 : 1;
  const startScale = spec.fromScale ?? 0.56;
  const startY = spec.fromY ?? 18;
  const startX = spec.fromX ?? 0;
  const startRotate = spec.rotateDeg + (spec.fromRotateOffset ?? -6);

  return (
    <motion.div
      style={{
        left: `${spec.leftPct}%`,
        top: `${spec.topPct}%`,
        width: `${spec.widthPct}%`,
        zIndex: spec.zIndex,
      }}
      className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 select-none"
      initial={
        instant
          ? {
              opacity: 1,
              scale: 1,
              x: 0,
              y: 0,
              rotate: spec.rotateDeg,
            }
          : {
              opacity: 0,
              scale: startScale,
              x: startX,
              y: startY,
              rotate: startRotate,
            }
      }
      animate={{
        opacity: 1,
        scale: 1,
        x: 0,
        y: 0,
        rotate: spec.rotateDeg,
      }}
      transition={{
        duration: instant ? 0 : 0.88,
        delay: instant ? 0 : (spec.subDelayMs ?? 0) / 1000,
        ease: [0.16, 1, 0.3, 1],
      }}
    >
      <img
        src={spec.src}
        alt={spec.alt}
        referrerPolicy="no-referrer"
        style={{
          transform: `scaleX(${flipFactor})`,
          filter: 'drop-shadow(0 8px 14px rgba(86, 52, 67, 0.14))',
        }}
        className="h-auto w-full object-contain"
      />
    </motion.div>
  );
};

interface BouquetWrappingLayersProps {
  visible: boolean;
  instant?: boolean;
}

export const BouquetWrappingLayers: React.FC<BouquetWrappingLayersProps> = ({
  visible,
  instant = false,
}) => {
  if (!visible) return null;

  return (
    <>
      {/* Back soft pleated blush & ivory-tissue wrapping sheets behind upper flowers */}
      <motion.svg
        viewBox="0 0 380 440"
        className="pointer-events-none absolute inset-0 z-[7] h-full w-full"
        fill="none"
        aria-hidden="true"
        initial={instant ? { opacity: 1, y: 0, scale: 1 } : { opacity: 0, y: 36, scale: 0.92 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: instant ? 0 : 0.72, ease: [0.16, 1, 0.3, 1] }}
      >
        <defs>
          <linearGradient id="wrapBackOuter" x1="190" y1="88" x2="190" y2="395" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FBE7EE" />
            <stop offset="55%" stopColor="#F3C9D7" />
            <stop offset="100%" stopColor="#DCA0B5" />
          </linearGradient>
          <linearGradient id="wrapTissueLiner" x1="190" y1="98" x2="190" y2="305" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFF9F6" />
            <stop offset="100%" stopColor="#FCE7EE" />
          </linearGradient>
          <filter id="backWrapShadow" x="-12%" y="-12%" width="124%" height="124%">
            <feDropShadow dx="0" dy="10" stdDeviation="10" floodColor="#563443" floodOpacity="0.14" />
          </filter>
        </defs>
        {/* Outer soft blush-paper petals */}
        <path
          d="M52 178 C78 126, 134 96, 190 102 C246 96, 302 126, 328 178 C294 252, 240 326, 206 392 C194 398, 186 398, 174 392 C140 326, 86 252, 52 178 Z"
          fill="url(#wrapBackOuter)"
          filter="url(#backWrapShadow)"
        />
        {/* Delicate translucent ivory tissue lining peeking at top */}
        <path
          d="M72 178 C100 130, 146 108, 190 116 C234 108, 280 130, 308 178 L220 342 L160 342 Z"
          fill="url(#wrapTissueLiner)"
          opacity="0.78"
        />
      </motion.svg>

      {/* Front layered blush wrapping folds with soft radial shading and natural flared skirt */}
      <svg
        viewBox="0 0 380 440"
        className="pointer-events-none absolute inset-0 z-[38] h-full w-full"
        fill="none"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="wrapLeftSilk" x1="58" y1="215" x2="205" y2="410" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FCE5ED" />
            <stop offset="48%" stopColor="#F4C7D6" />
            <stop offset="100%" stopColor="#D794AB" />
          </linearGradient>
          <linearGradient id="wrapRightSilk" x1="322" y1="215" x2="175" y2="410" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FDEAF1" />
            <stop offset="52%" stopColor="#F2C2D2" />
            <stop offset="100%" stopColor="#D490A7" />
          </linearGradient>
          <radialGradient id="wrapFrontSculpt" cx="46%" cy="32%" r="72%">
            <stop offset="0%" stopColor="#FFF8F5" />
            <stop offset="45%" stopColor="#F7D2DF" />
            <stop offset="100%" stopColor="#DC9DB3" />
          </radialGradient>
          <linearGradient id="wrapSkirtFold" x1="190" y1="312" x2="190" y2="416" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#D892AA" />
            <stop offset="35%" stopColor="#F2C5D4" />
            <stop offset="100%" stopColor="#FBE5EC" />
          </linearGradient>
          <filter id="wrapSoftDrop" x="-15%" y="-15%" width="130%" height="130%">
            <feDropShadow dx="0" dy="8" stdDeviation="8" floodColor="#563443" floodOpacity="0.16" />
          </filter>
        </defs>

        {/* Left curved paper fold */}
        <motion.path
          d="M58 214 C104 236, 152 268, 198 312 C188 352, 174 388, 158 416 C140 402, 108 320, 58 214 Z"
          fill="url(#wrapLeftSilk)"
          filter="url(#wrapSoftDrop)"
          initial={instant ? { opacity: 1, x: 0, y: 0 } : { opacity: 0, x: -24, y: 26 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          transition={{ duration: instant ? 0 : 0.65, delay: instant ? 0 : 0.14, ease: [0.16, 1, 0.3, 1] }}
        />

        {/* Right curved paper fold */}
        <motion.path
          d="M322 214 C276 236, 228 268, 182 312 C192 352, 206 388, 222 416 C240 402, 272 320, 322 214 Z"
          fill="url(#wrapRightSilk)"
          filter="url(#wrapSoftDrop)"
          initial={instant ? { opacity: 1, x: 0, y: 0 } : { opacity: 0, x: 24, y: 26 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          transition={{ duration: instant ? 0 : 0.65, delay: instant ? 0 : 0.28, ease: [0.16, 1, 0.3, 1] }}
        />

        {/* Center soft scalloped tissue cuff + gathered lower skirt */}
        <motion.g
          initial={instant ? { opacity: 1, y: 0 } : { opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: instant ? 0 : 0.62, delay: instant ? 0 : 0.42, ease: [0.16, 1, 0.3, 1] }}
        >
          <path
            d="M110 250 C142 268, 170 272, 190 264 C210 272, 238 268, 270 250 C252 292, 234 318, 214 334 C198 342, 182 342, 166 334 C146 318, 128 292, 110 250 Z"
            fill="url(#wrapFrontSculpt)"
          />
          {/* Flared gathered bottom paper skirt tapering cleanly above stem tips */}
          <path
            d="M166 316 Q190 326 214 316 C226 352, 238 386, 246 406 C224 416, 206 410, 190 416 C174 410, 156 416, 134 406 C142 386, 154 352, 166 316 Z"
            fill="url(#wrapSkirtFold)"
          />
          {/* Soft paper highlight ridges */}
          <path
            d="M122 258 C144 282, 162 302, 174 316 M258 258 C236 282, 218 302, 206 316 M174 328 L156 406 M206 328 L224 406"
            stroke="#FFF9F6"
            strokeOpacity="0.52"
            strokeWidth="1.2"
            strokeLinecap="round"
          />
        </motion.g>
      </svg>
    </>
  );
};

interface BouquetRibbonBowProps {
  visible: boolean;
  instant?: boolean;
}

export const BouquetRibbonBow: React.FC<BouquetRibbonBowProps> = ({
  visible,
  instant = false,
}) => {
  if (!visible) return null;

  return (
    <svg
      viewBox="0 0 380 440"
      className="pointer-events-none absolute inset-0 z-[42] h-full w-full"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="satinBand" x1="154" y1="312" x2="226" y2="312" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#9D4E69" />
          <stop offset="35%" stopColor="#D58AA3" />
          <stop offset="55%" stopColor="#EBB8C9" />
          <stop offset="78%" stopColor="#C16F8B" />
          <stop offset="100%" stopColor="#944761" />
        </linearGradient>
        <linearGradient id="satinLoop" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ECC0CF" />
          <stop offset="45%" stopColor="#CC7A97" />
          <stop offset="100%" stopColor="#9B4C67" />
        </linearGradient>
        <filter id="bowShadow" x="-15%" y="-15%" width="130%" height="130%">
          <feDropShadow dx="0" dy="5" stdDeviation="4.5" floodColor="#563443" floodOpacity="0.24" />
        </filter>
      </defs>

      {/* Satin waist band hugging the gathered paper waist */}
      <motion.path
        d="M161 304 Q190 315 219 304 L216 321 Q190 330 164 321 Z"
        fill="url(#satinBand)"
        filter="url(#bowShadow)"
        initial={instant ? { scaleX: 1, opacity: 1 } : { scaleX: 0, opacity: 0 }}
        animate={{ scaleX: 1, opacity: 1 }}
        style={{ transformOrigin: '190px 313px' }}
        transition={{ duration: instant ? 0 : 0.45, ease: [0.16, 1, 0.3, 1] }}
      />

      {/* Flowing dusty-rose satin tails */}
      <motion.g
        filter="url(#bowShadow)"
        initial={instant ? { opacity: 1, y: 0, scaleY: 1 } : { opacity: 0, y: -12, scaleY: 0.4 }}
        animate={{ opacity: 1, y: 0, scaleY: 1 }}
        style={{ transformOrigin: '190px 316px' }}
        transition={{ duration: instant ? 0 : 0.55, delay: instant ? 0 : 0.25, ease: [0.16, 1, 0.3, 1] }}
      >
        <path
          d="M184 316 Q162 354 146 393 L159 387 L168 398 Q179 358 190 320 Z"
          fill="url(#satinLoop)"
        />
        <path
          d="M196 316 Q218 354 234 393 L221 387 L212 398 Q201 358 190 320 Z"
          fill="url(#satinLoop)"
        />
      </motion.g>

      {/* Left & Right Sculpted Bow Loops with Silk Sheen */}
      <motion.g
        filter="url(#bowShadow)"
        initial={instant ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.3 }}
        animate={{ opacity: 1, scale: 1 }}
        style={{ transformOrigin: '190px 312px' }}
        transition={{ duration: instant ? 0 : 0.55, delay: instant ? 0 : 0.15, ease: [0.16, 1, 0.3, 1] }}
      >
        <path
          d="M188 310 C155 282, 122 293, 128 315 C133 333, 166 326, 188 315 Z"
          fill="url(#satinLoop)"
        />
        <path
          d="M183 310 C158 296, 138 302, 141 312"
          stroke="#FFF7F4"
          strokeOpacity="0.45"
          strokeWidth="1.3"
          strokeLinecap="round"
        />
        <path
          d="M192 310 C225 282, 258 293, 252 315 C247 333, 214 326, 192 315 Z"
          fill="url(#satinLoop)"
        />
        <path
          d="M197 310 C222 296, 242 302, 239 312"
          stroke="#FFF7F4"
          strokeOpacity="0.45"
          strokeWidth="1.3"
          strokeLinecap="round"
        />
        {/* Soft pleated center silk knot */}
        <rect
          x="181"
          y="303"
          width="18"
          height="17"
          rx="6"
          fill="url(#satinBand)"
        />
      </motion.g>
    </svg>
  );
};

export const BouquetFinalSparkles: React.FC<{ visible: boolean }> = ({
  visible,
}) => {
  if (!visible) return null;

  const sparkles = [
    { left: '12%', top: '18%', delay: '0s', size: 'text-base' },
    { left: '86%', top: '16%', delay: '0.6s', size: 'text-sm' },
    { left: '8%', top: '48%', delay: '1.2s', size: 'text-xs' },
    { left: '91%', top: '46%', delay: '1.8s', size: 'text-base' },
    { left: '20%', top: '72%', delay: '0.9s', size: 'text-sm' },
    { left: '80%', top: '70%', delay: '1.5s', size: 'text-xs' },
    { left: '50%', top: '4%', delay: '0.4s', size: 'text-sm' },
  ];

  const driftPetals = [
    { left: '22%', delay: '0s', color: '#F6D0DA' },
    { left: '46%', delay: '1.2s', color: '#EFAFC1' },
    { left: '72%', delay: '0.6s', color: '#F9D6CB' },
    { left: '62%', delay: '2.1s', color: '#F6D0DA' },
  ];

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 z-[45]"
    >
      {sparkles.map((sp, i) => (
        <span
          key={`sp-${i}`}
          className={`animate-twinkle absolute text-[#D7B477] ${sp.size}`}
          style={
            {
              left: sp.left,
              top: sp.top,
              '--twinkle-delay': sp.delay,
            } as React.CSSProperties
          }
        >
          ✦
        </span>
      ))}

      {driftPetals.map((pt, i) => (
        <motion.span
          key={`dp-${i}`}
          initial={{ opacity: 0, y: 12, rotate: 0 }}
          animate={{
            opacity: [0, 0.85, 0],
            y: [12, 110, 195],
            x: [0, i % 2 === 0 ? 18 : -18, i % 2 === 0 ? -10 : 12],
            rotate: [0, 110, 220],
          }}
          transition={{
            duration: 5.2,
            delay: parseFloat(pt.delay),
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="absolute top-[14%]"
          style={{ left: pt.left }}
        >
          <svg width="13" height="16" viewBox="0 0 16 20" fill="none">
            <path
              d="M8 1 C13 4, 15 11, 8 19 C1 11, 3 4, 8 1 Z"
              fill={pt.color}
            />
          </svg>
        </motion.span>
      ))}
    </div>
  );
};
