import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart } from 'lucide-react';
import { GoldFloralDivider } from './RomanticOrnaments';

interface PandaHugProps {
  heading: string;
  message: string;
  buttonLabel: string;
  hugCount: number;
  onHug: () => void;
}

export const PandaHug: React.FC<PandaHugProps> = ({
  heading,
  message,
  buttonLabel,
  hugCount,
  onHug,
}) => {
  const [isHugging, setIsHugging] = useState(false);
  const [burstKey, setBurstKey] = useState(0);

  const triggerHug = () => {
    setIsHugging(true);
    setBurstKey((k) => k + 1);
    onHug();
    window.setTimeout(() => {
      setIsHugging(false);
    }, 1500);
  };

  return (
    <div className="stationery-panel paper-texture relative overflow-hidden rounded-3xl p-6 text-center sm:p-10">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-3 rounded-2xl border border-[#D8B477]/35"
      />

      <div className="relative z-10">
        <p className="text-[11px] font-semibold tracking-[0.2em] text-[#A94F70] uppercase">
          A Cozy Little Moment
        </p>
        <h2 className="font-serif-display mt-1 text-3xl font-semibold text-[#50313F] sm:text-4xl">
          {heading}
        </h2>
        <GoldFloralDivider className="mt-3" />

        <div className="relative mx-auto my-6 flex h-56 w-56 items-center justify-center">
          {/* Floating Hearts & Flowers burst on hug */}
          {burstKey > 0 && (
            <div
              key={burstKey}
              aria-hidden="true"
              className="pointer-events-none absolute inset-0"
            >
              {[
                { x: -64, y: -50, delay: 0, symbol: '♡' },
                { x: 66, y: -46, delay: 0.08, symbol: '✿' },
                { x: -46, y: -76, delay: 0.14, symbol: '♡' },
                { x: 50, y: -80, delay: 0.18, symbol: '♡' },
                { x: 0, y: -90, delay: 0.05, symbol: '✿' },
              ].map((item, idx) => (
                <motion.span
                  key={idx}
                  initial={{ opacity: 0, x: 0, y: 0, scale: 0.5 }}
                  animate={{
                    opacity: [0, 1, 0],
                    x: item.x,
                    y: item.y,
                    scale: [0.6, 1.3, 0.95],
                  }}
                  transition={{ duration: 1.35, delay: item.delay }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-2xl text-[#A94F70]"
                >
                  {item.symbol}
                </motion.span>
              ))}
            </div>
          )}

          {/* Polished Soft SVG Panda */}
          <motion.button
            type="button"
            onClick={triggerHug}
            aria-label="Tap panda for a warm virtual hug"
            animate={
              isHugging ? { scale: [1, 1.09, 1.04, 1] } : { scale: 1 }
            }
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="group cursor-pointer rounded-full p-2 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#A94F70]"
          >
            <svg
              viewBox="0 0 210 210"
              className="h-48 w-48 drop-shadow-sm transition-transform duration-300 group-hover:scale-[1.03]"
              fill="none"
              aria-hidden="true"
            >
              <defs>
                <radialGradient id="pandaHalo" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#F4C6D0" stopOpacity="0.55" />
                  <stop offset="100%" stopColor="#FFF7F2" stopOpacity="0" />
                </radialGradient>
                <radialGradient id="pandaFur" cx="45%" cy="35%" r="65%">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#F6ECE7" />
                </radialGradient>
              </defs>

              <circle cx="105" cy="110" r="88" fill="url(#pandaHalo)" />

              {/* Ears */}
              <circle cx="65" cy="55" r="19" fill="#46333D" />
              <circle cx="145" cy="55" r="19" fill="#46333D" />
              <circle cx="65" cy="55" r="9.5" fill="#684D5B" />
              <circle cx="145" cy="55" r="9.5" fill="#684D5B" />

              {/* Cute little pink blossom on ear */}
              <g transform="translate(152 43)">
                {[0, 72, 144, 216, 288].map((a) => (
                  <ellipse
                    key={a}
                    cx="0"
                    cy="-6.5"
                    rx="3.4"
                    ry="5.5"
                    fill="#F4C6D0"
                    transform={`rotate(${a})`}
                  />
                ))}
                <circle cx="0" cy="0" r="2.6" fill="#D8B477" />
              </g>

              {/* Body */}
              <ellipse
                cx="105"
                cy="148"
                rx="47"
                ry="39"
                fill="url(#pandaFur)"
                stroke="#E6D2CC"
                strokeWidth="1.8"
              />
              <path
                d="M62 137 C70 118, 140 118, 148 137 C144 148, 66 148, 62 137 Z"
                fill="#46333D"
              />

              {/* Left & Right Arms (animate open wide on hug!) */}
              <motion.g
                animate={
                  isHugging
                    ? { rotate: -38, x: -6, y: -12 }
                    : { rotate: 0, x: 0, y: 0 }
                }
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                style={{ transformOrigin: '68px 132px' }}
              >
                <ellipse
                  cx="56"
                  cy="140"
                  rx="14.5"
                  ry="23"
                  transform="rotate(28 56 140)"
                  fill="#46333D"
                />
              </motion.g>
              <motion.g
                animate={
                  isHugging
                    ? { rotate: 38, x: 6, y: -12 }
                    : { rotate: 0, x: 0, y: 0 }
                }
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                style={{ transformOrigin: '142px 132px' }}
              >
                <ellipse
                  cx="154"
                  cy="140"
                  rx="14.5"
                  ry="23"
                  transform="rotate(-28 154 140)"
                  fill="#46333D"
                />
              </motion.g>

              {/* Heart held by panda */}
              <path
                d="M105 162 C105 162, 89 151, 89 141 C89 136, 93 132.5, 97.8 132.5 C100.8 132.5, 103.4 134.2, 105 136.5 C106.6 134.2, 109.2 132.5, 112.2 132.5 C117 132.5, 121 136, 121 141 C121 151, 105 162, 105 162 Z"
                fill="#C96480"
                stroke="#FFF7F2"
                strokeWidth="1.2"
              />

              {/* Feet */}
              <ellipse cx="78" cy="180" rx="16.5" ry="11.5" fill="#46333D" />
              <ellipse cx="132" cy="180" rx="16.5" ry="11.5" fill="#46333D" />
              <circle cx="78" cy="180" r="5" fill="#F4C6D0" />
              <circle cx="132" cy="180" r="5" fill="#F4C6D0" />

              {/* Head */}
              <ellipse
                cx="105"
                cy="89"
                rx="46"
                ry="40"
                fill="url(#pandaFur)"
                stroke="#E6D2CC"
                strokeWidth="1.8"
              />

              {/* Eye patches */}
              <ellipse
                cx="84"
                cy="87"
                rx="12.5"
                ry="14.5"
                transform="rotate(-14 84 87)"
                fill="#46333D"
              />
              <ellipse
                cx="126"
                cy="87"
                rx="12.5"
                ry="14.5"
                transform="rotate(14 126 87)"
                fill="#46333D"
              />

              {/* Eyes */}
              {isHugging ? (
                <>
                  <path
                    d="M78 87 Q84 80 90 87"
                    stroke="#FFF7F2"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                  <path
                    d="M120 87 Q126 80 132 87"
                    stroke="#FFF7F2"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                </>
              ) : (
                <>
                  <circle cx="85" cy="86" r="4.5" fill="#FFF7F2" />
                  <circle cx="86.5" cy="84.5" r="1.8" fill="#46333D" />
                  <circle cx="125" cy="86" r="4.5" fill="#FFF7F2" />
                  <circle cx="126.5" cy="84.5" r="1.8" fill="#46333D" />
                </>
              )}

              {/* Rosy cheeks */}
              <ellipse cx="69" cy="99" rx="8" ry="4.5" fill="#F4B2C2" opacity="0.85" />
              <ellipse cx="141" cy="99" rx="8" ry="4.5" fill="#F4B2C2" opacity="0.85" />

              {/* Nose & smile */}
              <ellipse cx="105" cy="98" rx="5.5" ry="3.8" fill="#46333D" />
              <path
                d="M98 105 Q105 111 112 105"
                stroke="#46333D"
                strokeWidth="2.4"
                strokeLinecap="round"
              />
            </svg>
          </motion.button>
        </div>

        {/* Hug Message */}
        <div className="mx-auto max-w-lg space-y-3">
          {hugCount > 0 ? (
            <motion.p
              key={hugCount}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-base leading-relaxed whitespace-pre-line text-[#50313F] sm:text-[17px]"
            >
              {message}
            </motion.p>
          ) : (
            <p className="text-sm text-[#7E596A]">
              Tap the little panda above whenever you need a warm hug.
            </p>
          )}
        </div>

        <div className="mt-6 flex flex-col items-center gap-2">
          <button
            type="button"
            onClick={triggerHug}
            className="inline-flex min-h-[48px] items-center gap-2 rounded-full bg-gradient-to-r from-[#B96281] to-[#A94F70] px-7 py-3 text-sm font-medium text-[#FFF7F2] shadow-md shadow-[#A94F70]/20 transition-all hover:from-[#A94F70] hover:to-[#8F3D5B] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A94F70]"
          >
            <Heart className="h-4 w-4 fill-current" />
            <span>{hugCount > 0 ? buttonLabel : 'Send Panda Hug ♡'}</span>
          </button>
          {hugCount > 0 && (
            <span className="text-xs font-medium text-[#7E596A] tabular-nums">
              Hugs sent: {hugCount}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
