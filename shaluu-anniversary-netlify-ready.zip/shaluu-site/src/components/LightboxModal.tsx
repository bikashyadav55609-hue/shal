import React, { useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { GalleryPhoto } from '../types/anniversary';

interface LightboxItem {
  photo: GalleryPhoto;
  sectionTitle: string;
}

interface LightboxModalProps {
  items: LightboxItem[];
  activeIndex: number | null;
  onClose: () => void;
  onNavigate: (nextIndex: number) => void;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  items,
  activeIndex,
  onClose,
  onNavigate,
}) => {
  const touchStartX = useRef<number | null>(null);
  const closeBtnRef = useRef<HTMLButtonElement | null>(null);

  const isOpen = activeIndex !== null && items[activeIndex] !== undefined;
  const current = isOpen && activeIndex !== null ? items[activeIndex] : null;

  useEffect(() => {
    if (!isOpen || activeIndex === null) return;
    closeBtnRef.current?.focus();

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowRight' && items.length > 1) {
        onNavigate((activeIndex + 1) % items.length);
      } else if (e.key === 'ArrowLeft' && items.length > 1) {
        onNavigate((activeIndex - 1 + items.length) % items.length);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, isOpen, items.length, onClose, onNavigate]);

  if (!isOpen || !current || activeIndex === null) return null;

  const goPrev = () => onNavigate((activeIndex - 1 + items.length) % items.length);
  const goNext = () => onNavigate((activeIndex + 1) % items.length);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`Photo lightbox: ${current.photo.caption || current.sectionTitle}`}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#1F141A]/90 p-4 backdrop-blur-sm sm:p-6"
      onClick={onClose}
      onTouchStart={(e) => {
        touchStartX.current = e.touches[0]?.clientX ?? null;
      }}
      onTouchEnd={(e) => {
        if (touchStartX.current === null || items.length <= 1) return;
        const endX = e.changedTouches[0]?.clientX ?? touchStartX.current;
        const delta = endX - touchStartX.current;
        if (delta > 48) {
          goPrev();
        } else if (delta < -48) {
          goNext();
        }
        touchStartX.current = null;
      }}
    >
      {/* Top Bar */}
      <div
        className="mb-3 flex w-full max-w-4xl items-center justify-between text-white/90"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="min-w-0">
          <p className="truncate text-xs tracking-wider text-white/70 uppercase">
            {current.sectionTitle}
          </p>
          <p className="text-xs tabular-nums text-white/80">
            {activeIndex + 1} / {items.length}
          </p>
        </div>
        <button
          ref={closeBtnRef}
          type="button"
          onClick={onClose}
          aria-label="Close photo viewer"
          className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-white/15 text-white transition-colors hover:bg-white/25 focus-visible:outline-2 focus-visible:outline-white"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Main Image Frame */}
      <div
        className="relative flex max-h-[76vh] w-full max-w-4xl items-center justify-center"
        onClick={(e) => e.stopPropagation()}
      >
        {items.length > 1 && (
          <button
            type="button"
            onClick={goPrev}
            aria-label="Previous photograph"
            className="absolute left-1 z-10 inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-black/45 text-white transition-colors hover:bg-black/70 focus-visible:outline-2 focus-visible:outline-white sm:left-3"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
        )}

        <div className="flex max-h-[74vh] flex-col items-center overflow-hidden rounded-2xl bg-[#FFFBF8] p-3 shadow-2xl sm:p-4">
          <img
            src={current.photo.dataUrl}
            alt={
              current.photo.alt ||
              current.photo.caption ||
              `Photograph of Shaluu from ${current.sectionTitle}`
            }
            referrerPolicy="no-referrer"
            className="max-h-[60vh] w-auto max-w-full rounded-lg object-contain"
          />
          {current.photo.caption && (
            <p className="font-handwriting mt-3 max-w-xl text-center text-xl text-[#36222B] sm:text-2xl">
              {current.photo.caption}
            </p>
          )}
        </div>

        {items.length > 1 && (
          <button
            type="button"
            onClick={goNext}
            aria-label="Next photograph"
            className="absolute right-1 z-10 inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-full bg-black/45 text-white transition-colors hover:bg-black/70 focus-visible:outline-2 focus-visible:outline-white sm:right-3"
          >
            <ChevronRight className="h-6 w-6" />
          </button>
        )}
      </div>

      {items.length > 1 && (
        <p className="mt-3 text-xs text-white/65">
          Swipe or use arrow keys to browse photographs
        </p>
      )}
    </div>
  );
};
