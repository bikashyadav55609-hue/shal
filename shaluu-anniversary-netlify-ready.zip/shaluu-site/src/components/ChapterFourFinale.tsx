import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowLeft, Heart, RotateCcw } from 'lucide-react';
import { AnniversaryContent } from '../types/anniversary';
import { WaxSealSvg } from './BotanicalIllustrations';
import { VirtualBouquet } from './VirtualBouquet';
import {
  FloralCornerOrnament,
  GoldFloralDivider,
  SwayingFloralSprig,
  ThreeMonthEmblem,
} from './RomanticOrnaments';

interface ChapterFourFinaleProps {
  content: AnniversaryContent;
  bouquetAssembled: boolean;
  finalLetterOpened: boolean;
  onBouquetAssembled: () => void;
  onOpenFinalLetter: () => void;
  onPrevChapter: () => void;
  onReplay: () => void;
}

const TWINKLE_STARS = [
  { left: '8%', top: '9%', size: 4, delay: '0s' },
  { left: '19%', top: '23%', size: 3, delay: '1.1s' },
  { left: '31%', top: '11%', size: 3.5, delay: '0.6s' },
  { left: '44%', top: '7%', size: 3, delay: '1.8s' },
  { left: '58%', top: '13%', size: 4, delay: '0.3s' },
  { left: '72%', top: '9%', size: 3, delay: '1.4s' },
  { left: '84%', top: '17%', size: 4, delay: '0.9s' },
  { left: '92%', top: '28%', size: 3, delay: '2.2s' },
  { left: '13%', top: '44%', size: 3, delay: '1.5s' },
  { left: '89%', top: '48%', size: 3.5, delay: '0.4s' },
];

export const ChapterFourFinale: React.FC<ChapterFourFinaleProps> = ({
  content,
  bouquetAssembled,
  finalLetterOpened,
  onBouquetAssembled,
  onOpenFinalLetter,
  onPrevChapter,
  onReplay,
}) => {
  const { personal, chapter4 } = content;
  const [bouquetCompletedNow, setBouquetCompletedNow] = useState(false);

  const handleComplete = () => {
    setBouquetCompletedNow(true);
    onBouquetAssembled();
  };

  const showMessageCard = bouquetCompletedNow || bouquetAssembled;

  return (
    <section
      aria-label="Chapter 4: Until We Meet, My Panda"
      className="paper-texture relative min-h-[calc(100vh-3.5rem)] overflow-hidden px-4 pt-20 pb-16 text-[#563443] sm:px-6 sm:py-16"
      style={{
        background:
          'linear-gradient(180deg, #FFF6F0 0%, #F9DCE6 28%, #F6D0DA 64%, #EFAFC1 100%)',
      }}
    >
      {/* Sunlit twilight radial glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(circle at 50% 34%, rgba(255, 246, 240, 0.72) 0%, rgba(249, 214, 203, 0.28) 46%, transparent 78%)',
        }}
      />

      {/* Golden Starlight Sparkles */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        {TWINKLE_STARS.map((st, idx) => (
          <span
            key={idx}
            className="animate-twinkle absolute rounded-full bg-[#D7B477]"
            style={
              {
                left: st.left,
                top: st.top,
                width: `${st.size}px`,
                height: `${st.size}px`,
                '--twinkle-delay': st.delay,
              } as React.CSSProperties
            }
          />
        ))}
      </div>

      {/* Subtle Warm Gold Crescent Moon */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-3 right-4 opacity-90 sm:top-10 sm:right-16"
      >
        <div className="relative flex h-12 w-12 items-center justify-center rounded-full bg-[#FFF6F0]/60 shadow-[0_0_26px_rgba(215,180,119,0.5)] sm:h-18 sm:w-18">
          <svg viewBox="0 0 64 64" className="h-9 w-9 sm:h-13 sm:w-13">
            <path
              d="M39 10 C26 12, 18 23, 20 36 C22 48, 33 56, 46 53 C36 52, 29 44, 29 33 C29 22, 34 14, 39 10 Z"
              fill="#D7B477"
            />
          </svg>
        </div>
      </div>

      {/* Floral Corner Ornaments */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 opacity-50 sm:opacity-80"
      >
        <FloralCornerOrnament
          position="top-left"
          className="h-20 w-24 sm:h-44 sm:w-56"
        />
      </div>
      <div
        aria-hidden="true"
        className="pointer-events-none absolute right-0 bottom-0 hidden opacity-70 sm:block"
      >
        <FloralCornerOrnament
          position="bottom-right"
          className="h-40 w-52"
        />
      </div>

      <div className="relative z-20 mx-auto max-w-4xl space-y-12">
        {/* Chapter Heading */}
        <div className="text-center">
          <p className="text-[10px] font-semibold tracking-[0.16em] text-[#7F5A6B] uppercase sm:text-[11px] sm:tracking-[0.24em]">
            CHAPTER IV &nbsp;·&nbsp; THREE MONTHS &amp; FOREVER TO GO
          </p>
          <div className="mt-2 flex items-center justify-center gap-3">
            <SwayingFloralSprig className="hidden h-14 w-11 opacity-80 sm:block" />
            <h1 className="font-serif-display text-balance text-4xl font-semibold tracking-tight text-[#563443] sm:text-5xl md:text-6xl">
              {chapter4.heading}
            </h1>
            <SwayingFloralSprig
              flip
              className="hidden h-14 w-11 opacity-80 sm:block"
            />
          </div>
          {personal.firstMeetingDate && (
            <p className="mt-2 text-sm font-medium text-[#B65F7D]">
              Counting the days until: {personal.firstMeetingDate}
            </p>
          )}
          <GoldFloralDivider className="mt-4" />
        </div>

        {/* Flower-by-Flower Real Botanical Bouquet Centerpiece (No Frame, No Static Photo) */}
        <div className="mx-auto max-w-2xl text-center">
          <VirtualBouquet
            bouquetTitle={chapter4.bouquetTitle}
            onAssemblyComplete={handleComplete}
          />

          <AnimatePresence>
            {showMessageCard && (
              <motion.div
                key="bouquet-anniversary-message"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className="stationery-panel paper-texture relative mx-auto mt-6 max-w-xl overflow-hidden rounded-3xl p-6 text-center sm:p-9"
              >
                <div
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D7B477]/35"
                />
                <div className="relative z-10">
                  <GoldFloralDivider className="mb-4" />
                  <h3 className="font-serif-display text-balance text-2xl font-semibold text-[#563443] sm:text-3xl">
                    Three Months of Love, A Thousand More to Come ♡
                  </h3>
                  <p className="mt-4 text-base leading-relaxed whitespace-pre-line text-[#563443] sm:text-[17px]">
                    {chapter4.bouquetText}
                  </p>
                  <p className="font-handwriting mt-4 text-2xl text-[#B65F7D]">
                    — Always made with love for {personal.herNickname} ♡
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Two Glowing Stars Connected Across Distance */}
        <div className="stationery-panel mx-auto max-w-2xl rounded-3xl p-6 text-center sm:p-8">
          <svg
            viewBox="0 0 460 130"
            className="mx-auto h-auto w-full max-w-md"
            fill="none"
            aria-label={`Two glowing stars representing ${personal.ownerCityLabel} and ${personal.herCityLabel} connected across distance`}
          >
            <motion.path
              d="M78 72 Q230 10 382 72"
              stroke="url(#starLinkGrad)"
              strokeWidth="2.2"
              strokeDasharray="6 6"
              initial={{ pathLength: 0, opacity: 0.4 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 1.6, ease: 'easeInOut' }}
            />
            <defs>
              <linearGradient
                id="starLinkGrad"
                x1="78"
                y1="72"
                x2="382"
                y2="72"
                gradientUnits="userSpaceOnUse"
              >
                <stop stopColor="#D7B477" />
                <stop offset="0.5" stopColor="#B65F7D" />
                <stop offset="1" stopColor="#D7B477" />
              </linearGradient>
            </defs>

            <path
              d="M230 48 C230 48, 222 42, 222 36.5 C222 33.8, 224.2 32, 226.7 32 C228.3 32, 229.4 33, 230 34.1 C230.6 33, 231.7 32, 233.3 32 C235.8 32, 238 33.8, 238 36.5 C238 42, 230 48, 230 48 Z"
              fill="#B65F7D"
            />

            {/* Owner City Star */}
            <g transform="translate(78 72)">
              <circle r="20" fill="#D7B477" opacity="0.24" />
              <circle r="7" fill="#D7B477" />
              <path
                d="M0 -13 L2.5 -2.5 L13 0 L2.5 2.5 L0 13 L-2.5 2.5 L-13 0 L-2.5 -2.5 Z"
                fill="#C89C56"
              />
            </g>

            {/* Her City Star */}
            <g transform="translate(382 72)">
              <circle r="20" fill="#EFAFC1" opacity="0.34" />
              <circle r="7" fill="#B65F7D" />
              <path
                d="M0 -13 L2.5 -2.5 L13 0 L2.5 2.5 L0 13 L-2.5 2.5 L-13 0 L-2.5 -2.5 Z"
                fill="#D58AA3"
              />
            </g>

            <text
              x="78"
              y="108"
              textAnchor="middle"
              fill="#563443"
              fontSize="13"
              fontWeight="500"
              fontFamily="DM Sans, sans-serif"
            >
              {personal.ownerCityLabel || 'My City'}
            </text>
            <text
              x="382"
              y="108"
              textAnchor="middle"
              fill="#563443"
              fontSize="13"
              fontWeight="500"
              fontFamily="DM Sans, sans-serif"
            >
              {personal.herCityLabel || 'Your City'}
            </text>
          </svg>

          <p className="font-serif-display mt-2 text-2xl italic text-[#563443] sm:text-3xl">
            “{chapter4.twoStarsTitle}”
          </p>
        </div>

        {/* Final Anniversary Letter Envelope & Reveal */}
        <div className="mx-auto max-w-2xl">
          <AnimatePresence mode="wait">
            {!finalLetterOpened ? (
              <motion.div
                key="sealed-final-envelope"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                transition={{ duration: 0.45 }}
                className="flex flex-col items-center"
              >
                <button
                  type="button"
                  onClick={onOpenFinalLetter}
                  className="group relative w-full max-w-md cursor-pointer overflow-hidden rounded-3xl border border-[#D7B477]/65 bg-gradient-to-b from-[#FFF8F4] via-[#FCE5ED] to-[#F6D0DA] p-8 text-center text-[#563443] shadow-[0_24px_56px_-18px_rgba(182,95,125,0.38)] transition-transform duration-300 hover:-translate-y-1 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#B65F7D]"
                >
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-0 h-20 border-b border-[#D58AA3]/25 bg-gradient-to-b from-[#FFF3F6] to-transparent"
                    style={{ clipPath: 'polygon(0 0, 100% 0, 50% 100%)' }}
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-x-0 top-14 h-2 border-y border-[#D7B477]/40 bg-[#EFAFC1]/40"
                  />
                  <div className="relative z-10 flex flex-col items-center pt-4">
                    <div className="transition-transform duration-300 group-hover:scale-105">
                      <WaxSealSvg className="h-14 w-14" />
                    </div>
                    <h2 className="font-serif-display mt-4 text-2xl font-semibold text-[#563443] sm:text-3xl">
                      {chapter4.letterEnvelopeTitle}
                    </h2>
                    <span className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-gradient-to-r from-[#C86E8C] to-[#B65F7D] px-6 py-2.5 text-xs font-medium text-[#FFF6F0] shadow-sm">
                      <Heart className="h-3.5 w-3.5 fill-current" />
                      <span>Tap to Open Final Letter</span>
                    </span>
                  </div>
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="opened-final-letter"
                initial={{ opacity: 0, y: 24, scale: 0.97 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-10"
              >
                <article className="stationery-panel paper-texture relative overflow-hidden rounded-3xl p-6 text-[#563443] sm:p-11">
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-3 rounded-2xl border border-[#D7B477]/40"
                  />
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute top-0 left-0 opacity-65"
                  >
                    <FloralCornerOrnament
                      position="top-left"
                      className="h-28 w-36"
                    />
                  </div>
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute right-0 bottom-0 opacity-60"
                  >
                    <FloralCornerOrnament
                      position="bottom-right"
                      className="h-28 w-36"
                    />
                  </div>

                  <div className="relative z-10">
                    <div className="mb-6 flex items-center justify-between border-b border-[#D7B477]/45 pb-4">
                      <h2 className="font-handwriting text-3xl text-[#B65F7D] sm:text-4xl">
                        {chapter4.letterEnvelopeTitle}
                      </h2>
                      <WaxSealSvg className="h-10 w-10 shrink-0" />
                    </div>

                    <div className="space-y-4 text-base leading-relaxed whitespace-pre-line text-[#563443] sm:text-[17px]">
                      {chapter4.finalLetterBody}
                    </div>

                    <p className="font-handwriting mt-8 text-right text-3xl text-[#B65F7D]">
                      {chapter4.finalLetterSignature}
                    </p>
                  </div>
                </article>

                {/* Final Three-Month Anniversary Closing Moment */}
                <motion.div
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.65, delay: 0.25 }}
                  className="stationery-panel paper-texture relative overflow-hidden rounded-3xl p-8 text-center sm:p-10"
                >
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-2.5 rounded-2xl border border-[#D7B477]/40"
                  />
                  <div className="relative z-10">
                    <ThreeMonthEmblem
                      badgeText="THREE MONTHS OF US"
                      className="mb-4"
                    />
                    <h3 className="font-serif-display text-3xl font-semibold text-[#563443] sm:text-4xl">
                      {chapter4.closingAnniversaryHeading}
                    </h3>
                    <p className="mt-2 text-base text-[#7F5A6B]">
                      {chapter4.closingSubtitle}
                    </p>
                    <p className="font-script mt-3 text-3xl text-[#B65F7D]">
                      {chapter4.closingTitle}
                    </p>

                    <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
                      <button
                        type="button"
                        onClick={onPrevChapter}
                        className="inline-flex min-h-[48px] items-center gap-2 rounded-full border border-[#D58AA3]/40 bg-[#FFF6F0] px-6 py-3 text-sm font-medium text-[#563443] transition-colors hover:bg-[#F9DCE4] focus-visible:outline-2 focus-visible:outline-[#B65F7D]"
                      >
                        <ArrowLeft className="h-4 w-4" />
                        <span>Back to Chapter 3</span>
                      </button>
                      <button
                        type="button"
                        onClick={onReplay}
                        className="inline-flex min-h-[48px] items-center gap-2.5 rounded-full bg-gradient-to-r from-[#C86E8C] to-[#B65F7D] px-7 py-3 text-sm font-semibold text-[#FFF6F0] shadow-lg shadow-[#B65F7D]/25 transition-all hover:from-[#B65F7D] hover:to-[#994865] active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-[#B65F7D]"
                      >
                        <RotateCcw className="h-4 w-4" />
                        <span>{chapter4.replayButtonLabel}</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Back button when final letter is not opened yet */}
        {!finalLetterOpened && (
          <div className="flex justify-center pt-2">
            <button
              type="button"
              onClick={onPrevChapter}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[#D58AA3]/40 bg-[#FFF6F0]/90 px-5 py-2.5 text-sm font-medium text-[#563443] transition-colors hover:bg-[#FFF6F0] focus-visible:outline-2 focus-visible:outline-[#B65F7D]"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Back to Chapter 3</span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
