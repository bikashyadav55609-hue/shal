import React, { useRef, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  Download,
  Eye,
  Lock,
  Plus,
  RefreshCw,
  Star,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  AnniversaryContent,
  ChapterId,
  GalleryPhoto,
  ThemeId,
} from '../types/anniversary';
import {
  addGallerySection,
  addPhotoToSection,
  createDefaultContent,
  deletePhotoFromSection,
  extractYouTubeVideoId,
  parseCustomizationImport,
  removeGallerySection,
  reorderPhotoInSection,
  replacePhotoInSection,
  updateGallerySection,
  updatePhotoDetails,
} from '../utils/anniversaryStore';
import { readImageFileAsDataUrl } from '../utils/browserStorage';

type EditorTab = 'personal' | 'gallery' | 'messages' | 'music';

interface CustomizationPanelProps {
  isOpen: boolean;
  initialTab?: EditorTab;
  content: AnniversaryContent;
  previewMode: boolean;
  storageWarning: string | null;
  onClose: () => void;
  onChangeContent: (next: AnniversaryContent) => void;
  onTogglePreviewMode: (enabled: boolean) => void;
  onJumpToChapter: (chapter: ChapterId) => void;
}

const THEMES: Array<{ id: ThemeId; name: string; swatch: string }> = [
  { id: 'blush-sunrise', name: 'Blush Sunrise', swatch: '#B85D71' },
  { id: 'lavender-meadow', name: 'Lavender Meadow', swatch: '#8C628E' },
  { id: 'peach-blossom', name: 'Peach Blossom', swatch: '#C1686B' },
];

export const CustomizationPanel: React.FC<CustomizationPanelProps> = ({
  isOpen,
  initialTab = 'personal',
  content,
  previewMode,
  storageWarning,
  onClose,
  onChangeContent,
  onTogglePreviewMode,
  onJumpToChapter,
}) => {
  const [activeTab, setActiveTab] = useState<EditorTab>(initialTab);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState('');
  const [unlocked, setUnlocked] = useState(() => !content.ownerPin);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [newSectionTitle, setNewSectionTitle] = useState('');
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const replaceInputRef = useRef<HTMLInputElement | null>(null);
  const replaceTargetRef = useRef<{
    sectionId: string;
    photoId: string;
  } | null>(null);
  const importInputRef = useRef<HTMLInputElement | null>(null);

  React.useEffect(() => {
    if (isOpen) {
      setActiveTab(initialTab);
      setUnlocked(!content.ownerPin);
      setPinInput('');
      setPinError('');
    }
  }, [content.ownerPin, initialTab, isOpen]);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setStatusMessage(msg);
    window.setTimeout(() => setStatusMessage(null), 3000);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === content.ownerPin) {
      setUnlocked(true);
      setPinError('');
    } else {
      setPinError('Incorrect PIN. Please try again.');
    }
  };

  const handleUploadPhotos = async (
    sectionId: string,
    files: FileList | null
  ) => {
    if (!files || files.length === 0) return;
    setUploadError(null);
    let updatedSections = content.chapter2.sections;

    try {
      for (const file of Array.from(files)) {
        const dataUrl = await readImageFileAsDataUrl(file);
        const newPhoto: GalleryPhoto = {
          id: `photo-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          dataUrl,
          fileName: file.name,
          caption: '',
          alt: `${content.personal.herNickname} photograph`,
          isFeatured: false,
          addedAt: new Date().toISOString(),
        };
        updatedSections = addPhotoToSection(
          updatedSections,
          sectionId,
          newPhoto
        );
      }

      onChangeContent({
        ...content,
        chapter2: { ...content.chapter2, sections: updatedSections },
      });
      showToast('Photographs added to gallery');
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Could not upload photograph.'
      );
    }
  };

  const handleReplacePhoto = async (files: FileList | null) => {
    const target = replaceTargetRef.current;
    if (!target || !files || !files[0]) return;
    setUploadError(null);
    try {
      const dataUrl = await readImageFileAsDataUrl(files[0]);
      const nextSections = replacePhotoInSection(
        content.chapter2.sections,
        target.sectionId,
        target.photoId,
        dataUrl,
        files[0].name
      );
      onChangeContent({
        ...content,
        chapter2: { ...content.chapter2, sections: nextSections },
      });
      showToast('Photograph replaced');
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Could not replace photograph.'
      );
    } finally {
      replaceTargetRef.current = null;
    }
  };

  const handleExportJson = () => {
    const blob = new Blob([JSON.stringify(content, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'little-world-anniversary-backup.json';
    a.click();
    URL.revokeObjectURL(url);
    showToast('Backup exported');
  };

  const handleImportJson = async (files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const result = parseCustomizationImport(text);
      if (result.ok) {
        onChangeContent(result.content);
        showToast('Backup restored');
      } else {
        setUploadError(result.error);
      }
    } catch {
      setUploadError('Failed to read backup file.');
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Owner customization panel"
      className="fixed inset-0 z-50 flex justify-end bg-[#23161E]/55 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-2xl flex-col bg-[#FFFDFB] text-[#36222B] shadow-2xl"
      >
        {/* Top Drawer Bar */}
        <div className="flex items-center justify-between border-b border-[var(--theme-border)] px-5 py-4">
          <div>
            <h2 className="font-serif-display text-2xl font-semibold text-[#36222B]">
              Owner Customization
            </h2>
            <p className="text-xs text-[#705561]">
              Personalize names, photographs, letters, music, and theme before
              sharing.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Exit editing mode"
            className="inline-flex min-h-[40px] items-center gap-1.5 rounded-full border border-[var(--theme-border)] px-3.5 py-1.5 text-xs font-medium text-[#36222B] hover:bg-[#FDF2F4]"
          >
            <X className="h-4 w-4" />
            <span>Done</span>
          </button>
        </div>

        {/* Optional PIN Gate */}
        {!unlocked ? (
          <form
            onSubmit={handlePinSubmit}
            className="flex flex-1 flex-col items-center justify-center p-6 text-center"
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-[#FDF2F4] text-[#B85D71]">
              <Lock className="h-5 w-5" />
            </div>
            <h3 className="font-serif-display text-2xl font-semibold">
              Enter Owner PIN
            </h3>
            <p className="mt-1 max-w-sm text-xs text-[#705561]">
              Note: A client-side PIN is only a convenience for keeping
              surprises hidden and does not provide strong security.
            </p>
            <div className="mt-5 flex w-full max-w-xs flex-col gap-3">
              <label htmlFor="owner-pin-unlock" className="sr-only">
                Owner PIN
              </label>
              <input
                id="owner-pin-unlock"
                type="password"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Enter PIN"
                className="rounded-xl border border-[var(--theme-border)] px-4 py-2.5 text-center text-sm focus:border-[var(--theme-accent)] focus:outline-none"
              />
              {pinError && (
                <p className="text-xs text-rose-600">{pinError}</p>
              )}
              <button
                type="submit"
                className="min-h-[44px] rounded-xl bg-[var(--theme-accent)] px-4 py-2 text-sm font-medium text-white hover:bg-[var(--theme-accent-hover)]"
              >
                Unlock Editor
              </button>
            </div>
          </form>
        ) : (
          <>
            {/* Preview & Storage Notice Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--theme-border)] bg-[#FDF5F7] px-5 py-2.5 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => onTogglePreviewMode(!previewMode)}
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 font-medium transition-colors ${
                    previewMode
                      ? 'bg-[var(--theme-accent)] text-white'
                      : 'border border-[var(--theme-border)] bg-white text-[#36222B]'
                  }`}
                >
                  <Eye className="h-3.5 w-3.5" />
                  <span>
                    {previewMode ? 'Preview All: ON' : 'Preview All Chapters'}
                  </span>
                </button>

                {([1, 2, 3, 4] as ChapterId[]).map((ch) => (
                  <button
                    key={ch}
                    type="button"
                    onClick={() => {
                      onTogglePreviewMode(true);
                      onJumpToChapter(ch);
                    }}
                    className="rounded-md border border-[var(--theme-border)] bg-white px-2 py-1 text-[11px] font-medium hover:bg-[#FDF2F4]"
                  >
                    Go Ch.{ch}
                  </button>
                ))}
              </div>

              {statusMessage && (
                <span className="inline-flex items-center gap-1 font-medium text-[#4F7450]">
                  <Check className="h-3.5 w-3.5" />
                  {statusMessage}
                </span>
              )}
            </div>

            {/* Tabs */}
            <div
              role="tablist"
              aria-label="Customization sections"
              className="grid grid-cols-4 border-b border-[var(--theme-border)] bg-white px-4"
            >
              {(
                [
                  { id: 'personal', label: 'Personal' },
                  { id: 'gallery', label: 'Gallery' },
                  { id: 'messages', label: 'Letters' },
                  { id: 'music', label: 'Music & Look' },
                ] as Array<{ id: EditorTab; label: string }>
              ).map((tab) => (
                <button
                  key={tab.id}
                  role="tab"
                  type="button"
                  aria-selected={activeTab === tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`border-b-2 py-3 text-xs font-semibold transition-colors sm:text-sm ${
                    activeTab === tab.id
                      ? 'border-[var(--theme-accent)] text-[var(--theme-accent)]'
                      : 'border-transparent text-[#705561] hover:text-[#36222B]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 space-y-6 overflow-y-auto p-5 sm:p-6">
              {(storageWarning || uploadError) && (
                <div
                  role="alert"
                  className="rounded-2xl border border-amber-300 bg-amber-50 p-3.5 text-xs text-amber-900"
                >
                  {uploadError || storageWarning}
                </div>
              )}

              {/* Local Storage Honest Note */}
              <div className="rounded-2xl border border-[var(--theme-border)] bg-[#FFF8FA] p-3.5 text-xs leading-relaxed text-[#705561]">
                Changes and uploaded photos are saved automatically in this
                browser (using IndexedDB &amp; local storage). Data stored
                locally stays on this device/browser and is not automatically
                synced across other devices unless you export a backup below.
              </div>

              {/* TAB 1: PERSONAL DETAILS */}
              {activeTab === 'personal' && (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="owner-name-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Your Name or Nickname
                      </label>
                      <input
                        id="owner-name-input"
                        type="text"
                        value={content.personal.ownerName}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              ownerName: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="her-nickname-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Her Preferred Nickname
                      </label>
                      <input
                        id="her-nickname-input"
                        type="text"
                        value={content.personal.herNickname}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              herNickname: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="anniversary-date-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Anniversary Date / Label
                      </label>
                      <input
                        id="anniversary-date-input"
                        type="text"
                        value={content.personal.anniversaryDate}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              anniversaryDate: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="first-meeting-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Optional First-Meeting Date
                      </label>
                      <input
                        id="first-meeting-input"
                        type="text"
                        placeholder="e.g., Soon, when we meet"
                        value={content.personal.firstMeetingDate}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              firstMeetingDate: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label
                        htmlFor="owner-city-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Your Star Label (Optional City)
                      </label>
                      <input
                        id="owner-city-input"
                        type="text"
                        value={content.personal.ownerCityLabel}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              ownerCityLabel: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                    <div>
                      <label
                        htmlFor="her-city-input"
                        className="mb-1 block text-xs font-medium text-[#705561]"
                      >
                        Her Star Label (Optional City)
                      </label>
                      <input
                        id="her-city-input"
                        type="text"
                        value={content.personal.herCityLabel}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            personal: {
                              ...content.personal,
                              herCityLabel: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="owner-pin-set"
                      className="mb-1 block text-xs font-medium text-[#705561]"
                    >
                      Optional Customization PIN (leave blank for no PIN)
                    </label>
                    <input
                      id="owner-pin-set"
                      type="text"
                      placeholder="Optional convenience PIN"
                      value={content.ownerPin}
                      onChange={(e) =>
                        onChangeContent({
                          ...content,
                          ownerPin: e.target.value,
                        })
                      }
                      className="w-full rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                    />
                    <p className="mt-1 text-[11px] text-[#705561]">
                      Client-side PINs are only a convenience to keep surprises
                      tucked away—not strong security.
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 2: GALLERY MANAGEMENT */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <input
                    ref={replaceInputRef}
                    type="file"
                    accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      handleReplacePhoto(e.target.files);
                      e.target.value = '';
                    }}
                  />

                  {content.chapter2.sections.map((section) => (
                    <div
                      key={section.id}
                      className="rounded-2xl border border-[var(--theme-border)] bg-white p-4 shadow-xs"
                    >
                      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                        <input
                          type="text"
                          aria-label={`Section title for ${section.title}`}
                          value={section.title}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              chapter2: {
                                ...content.chapter2,
                                sections: updateGallerySection(
                                  content.chapter2.sections,
                                  section.id,
                                  { title: e.target.value }
                                ),
                              },
                            })
                          }
                          className="font-serif-display flex-1 rounded-lg border border-transparent px-2 py-1 text-lg font-semibold hover:border-[var(--theme-border)] focus:border-[var(--theme-accent)] focus:outline-none"
                        />

                        <div className="flex items-center gap-2">
                          <label className="inline-flex min-h-[38px] cursor-pointer items-center gap-1.5 rounded-full bg-[var(--theme-accent)] px-3.5 py-1.5 text-xs font-medium text-white hover:bg-[var(--theme-accent-hover)]">
                            <Upload className="h-3.5 w-3.5" />
                            <span>Upload Photo</span>
                            <input
                              type="file"
                              multiple
                              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
                              className="hidden"
                              onChange={(e) => {
                                handleUploadPhotos(section.id, e.target.files);
                                e.target.value = '';
                              }}
                            />
                          </label>
                          {content.chapter2.sections.length > 1 && (
                            <button
                              type="button"
                              onClick={() =>
                                onChangeContent({
                                  ...content,
                                  chapter2: {
                                    ...content.chapter2,
                                    sections: removeGallerySection(
                                      content.chapter2.sections,
                                      section.id
                                    ),
                                  },
                                })
                              }
                              aria-label={`Remove section ${section.title}`}
                              className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-[var(--theme-border)] text-[#705561] hover:bg-rose-50 hover:text-rose-600"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      {section.photos.length === 0 ? (
                        <p className="rounded-xl border border-dashed border-[var(--theme-border)] py-4 text-center text-xs text-[#705561]">
                          No photos in this section yet. Click “Upload Photo” to
                          add JPG, JPEG, PNG, or WebP files.
                        </p>
                      ) : (
                        <div className="space-y-3">
                          {section.photos.map((photo, idx) => (
                            <div
                              key={photo.id}
                              className="flex flex-col gap-3 rounded-xl border border-[var(--theme-border)] bg-[#FFFBF8] p-3 sm:flex-row sm:items-center"
                            >
                              <img
                                src={photo.dataUrl}
                                alt={photo.alt || photo.fileName}
                                className="h-20 w-20 shrink-0 rounded-lg bg-[#FDF2F4] object-contain"
                              />
                              <div className="flex-1 space-y-2">
                                <input
                                  type="text"
                                  placeholder="Write a romantic caption..."
                                  aria-label={`Caption for ${photo.fileName}`}
                                  value={photo.caption}
                                  onChange={(e) =>
                                    onChangeContent({
                                      ...content,
                                      chapter2: {
                                        ...content.chapter2,
                                        sections: updatePhotoDetails(
                                          content.chapter2.sections,
                                          section.id,
                                          photo.id,
                                          { caption: e.target.value }
                                        ),
                                      },
                                    })
                                  }
                                  className="w-full rounded-lg border border-[var(--theme-border)] bg-white px-2.5 py-1.5 text-xs"
                                />
                                <div className="flex flex-wrap items-center gap-1.5">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      onChangeContent({
                                        ...content,
                                        chapter2: {
                                          ...content.chapter2,
                                          sections: updatePhotoDetails(
                                            content.chapter2.sections,
                                            section.id,
                                            photo.id,
                                            { isFeatured: !photo.isFeatured }
                                          ),
                                        },
                                      })
                                    }
                                    className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium ${
                                      photo.isFeatured
                                        ? 'bg-[var(--theme-accent)] text-white'
                                        : 'border border-[var(--theme-border)] bg-white text-[#705561]'
                                    }`}
                                  >
                                    <Star className="h-3 w-3" />
                                    <span>
                                      {photo.isFeatured ? 'Featured' : 'Feature'}
                                    </span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => {
                                      replaceTargetRef.current = {
                                        sectionId: section.id,
                                        photoId: photo.id,
                                      };
                                      replaceInputRef.current?.click();
                                    }}
                                    className="rounded-md border border-[var(--theme-border)] bg-white px-2 py-1 text-[11px] font-medium text-[#36222B] hover:bg-[#FDF2F4]"
                                  >
                                    Replace
                                  </button>

                                  <button
                                    type="button"
                                    disabled={idx === 0}
                                    onClick={() =>
                                      onChangeContent({
                                        ...content,
                                        chapter2: {
                                          ...content.chapter2,
                                          sections: reorderPhotoInSection(
                                            content.chapter2.sections,
                                            section.id,
                                            photo.id,
                                            'up'
                                          ),
                                        },
                                      })
                                    }
                                    aria-label={`Move ${photo.fileName} up`}
                                    className="rounded-md border border-[var(--theme-border)] bg-white p-1 text-[#705561] disabled:opacity-35"
                                  >
                                    <ArrowUp className="h-3.5 w-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    disabled={idx === section.photos.length - 1}
                                    onClick={() =>
                                      onChangeContent({
                                        ...content,
                                        chapter2: {
                                          ...content.chapter2,
                                          sections: reorderPhotoInSection(
                                            content.chapter2.sections,
                                            section.id,
                                            photo.id,
                                            'down'
                                          ),
                                        },
                                      })
                                    }
                                    aria-label={`Move ${photo.fileName} down`}
                                    className="rounded-md border border-[var(--theme-border)] bg-white p-1 text-[#705561] disabled:opacity-35"
                                  >
                                    <ArrowDown className="h-3.5 w-3.5" />
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() =>
                                      onChangeContent({
                                        ...content,
                                        chapter2: {
                                          ...content.chapter2,
                                          sections: deletePhotoFromSection(
                                            content.chapter2.sections,
                                            section.id,
                                            photo.id
                                          ),
                                        },
                                      })
                                    }
                                    aria-label={`Delete ${photo.fileName}`}
                                    className="rounded-md border border-[var(--theme-border)] bg-white p-1 text-rose-600 hover:bg-rose-50"
                                  >
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}

                  {/* Add Gallery Section */}
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="New gallery section title..."
                      aria-label="New gallery section title"
                      value={newSectionTitle}
                      onChange={(e) => setNewSectionTitle(e.target.value)}
                      className="flex-1 rounded-xl border border-[var(--theme-border)] px-3.5 py-2 text-sm"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newSectionTitle.trim()) return;
                        onChangeContent({
                          ...content,
                          chapter2: {
                            ...content.chapter2,
                            sections: addGallerySection(
                              content.chapter2.sections,
                              newSectionTitle
                            ),
                          },
                        });
                        setNewSectionTitle('');
                        showToast('Gallery section added');
                      }}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-[var(--theme-accent)] px-4 py-2 text-xs font-medium text-white"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Add Section</span>
                    </button>
                  </div>
                </div>
              )}

              {/* TAB 3: LETTERS & MESSAGES */}
              {activeTab === 'messages' && (
                <div className="space-y-6">
                  <div>
                    <label
                      htmlFor="hero-heading-edit"
                      className="mb-1 block text-xs font-semibold text-[#36222B]"
                    >
                      Chapter 1 — Anniversary Heading
                    </label>
                    <input
                      id="hero-heading-edit"
                      type="text"
                      value={content.chapter1.heroHeading}
                      onChange={(e) =>
                        onChangeContent({
                          ...content,
                          chapter1: {
                            ...content.chapter1,
                            heroHeading: e.target.value,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="anniv-support-edit"
                      className="mb-1 block text-xs font-semibold text-[#36222B]"
                    >
                      Chapter 1 — Anniversary Celebration Note
                    </label>
                    <textarea
                      id="anniv-support-edit"
                      rows={4}
                      value={content.chapter1.anniversarySupportingText}
                      onChange={(e) =>
                        onChangeContent({
                          ...content,
                          chapter1: {
                            ...content.chapter1,
                            anniversarySupportingText: e.target.value,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-[var(--theme-border)] p-3 text-sm"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="welcome-msg-edit"
                      className="mb-1 block text-xs font-semibold text-[#36222B]"
                    >
                      Chapter 1 — Welcome Message
                    </label>
                    <textarea
                      id="welcome-msg-edit"
                      rows={5}
                      value={content.chapter1.welcomeMessage}
                      onChange={(e) =>
                        onChangeContent({
                          ...content,
                          chapter1: {
                            ...content.chapter1,
                            welcomeMessage: e.target.value,
                          },
                        })
                      }
                      className="w-full rounded-xl border border-[var(--theme-border)] p-3 text-sm"
                    />
                  </div>

                  {/* 5 Flower Messages */}
                  <div className="space-y-3 border-t border-[var(--theme-border)] pt-4">
                    <h3 className="text-xs font-semibold tracking-wider text-[#705561] uppercase">
                      Chapter 3 — Interactive Flower Messages
                    </h3>
                    {content.chapter3.flowers.map((flower, idx) => (
                      <div key={flower.id}>
                        <label className="mb-1 block text-xs font-medium text-[#705561]">
                          {flower.name}
                        </label>
                        <input
                          type="text"
                          value={flower.message}
                          onChange={(e) => {
                            const updated = [...content.chapter3.flowers];
                            updated[idx] = {
                              ...flower,
                              message: e.target.value,
                            };
                            onChangeContent({
                              ...content,
                              chapter3: {
                                ...content.chapter3,
                                flowers: updated,
                              },
                            });
                          }}
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                    ))}
                  </div>

                  {/* 7 Open When Letters */}
                  <div className="space-y-4 border-t border-[var(--theme-border)] pt-4">
                    <h3 className="text-xs font-semibold tracking-wider text-[#705561] uppercase">
                      Chapter 3 — Open When... Letters
                    </h3>
                    {content.chapter3.letters.map((letter, idx) => (
                      <div
                        key={letter.id}
                        className="space-y-2 rounded-2xl border border-[var(--theme-border)] bg-white p-3.5"
                      >
                        <input
                          type="text"
                          value={letter.title}
                          aria-label={`Envelope title ${idx + 1}`}
                          onChange={(e) => {
                            const updated = [...content.chapter3.letters];
                            updated[idx] = { ...letter, title: e.target.value };
                            onChangeContent({
                              ...content,
                              chapter3: {
                                ...content.chapter3,
                                letters: updated,
                              },
                            });
                          }}
                          className="w-full rounded-lg border border-[var(--theme-border)] px-3 py-1.5 text-sm font-medium"
                        />
                        <textarea
                          rows={4}
                          value={letter.body}
                          aria-label={`Letter body for ${letter.title}`}
                          onChange={(e) => {
                            const updated = [...content.chapter3.letters];
                            updated[idx] = { ...letter, body: e.target.value };
                            onChangeContent({
                              ...content,
                              chapter3: {
                                ...content.chapter3,
                                letters: updated,
                              },
                            });
                          }}
                          className="w-full rounded-lg border border-[var(--theme-border)] p-2.5 text-xs"
                        />
                      </div>
                    ))}
                  </div>

                  {/* Panda & Chapter 4 Finale Texts */}
                  <div className="space-y-4 border-t border-[var(--theme-border)] pt-4">
                    <div>
                      <label
                        htmlFor="panda-msg-edit"
                        className="mb-1 block text-xs font-semibold text-[#36222B]"
                      >
                        Chapter 3 — Panda Hug Message
                      </label>
                      <textarea
                        id="panda-msg-edit"
                        rows={3}
                        value={content.chapter3.pandaMessage}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            chapter3: {
                              ...content.chapter3,
                              pandaMessage: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] p-3 text-sm"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="bouquet-msg-edit"
                        className="mb-1 block text-xs font-semibold text-[#36222B]"
                      >
                        Chapter 4 — Bouquet Message
                      </label>
                      <textarea
                        id="bouquet-msg-edit"
                        rows={3}
                        value={content.chapter4.bouquetText}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            chapter4: {
                              ...content.chapter4,
                              bouquetText: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] p-3 text-sm"
                      />
                    </div>

                    <div>
                      <label
                        htmlFor="final-letter-edit"
                        className="mb-1 block text-xs font-semibold text-[#36222B]"
                      >
                        Chapter 4 — Final Love Letter
                      </label>
                      <textarea
                        id="final-letter-edit"
                        rows={9}
                        value={content.chapter4.finalLetterBody}
                        onChange={(e) =>
                          onChangeContent({
                            ...content,
                            chapter4: {
                              ...content.chapter4,
                              finalLetterBody: e.target.value,
                            },
                          })
                        }
                        className="w-full rounded-xl border border-[var(--theme-border)] p-3 text-sm"
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                      <div>
                        <label
                          htmlFor="final-sign-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          Final Letter Signature
                        </label>
                        <input
                          id="final-sign-edit"
                          type="text"
                          value={content.chapter4.finalLetterSignature}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              chapter4: {
                                ...content.chapter4,
                                finalLetterSignature: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="closing-sub-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          Closing Message
                        </label>
                        <input
                          id="closing-sub-edit"
                          type="text"
                          value={content.chapter4.closingSubtitle}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              chapter4: {
                                ...content.chapter4,
                                closingSubtitle: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: MUSIC & APPEARANCE */}
              {activeTab === 'music' && (
                <div className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-xs font-semibold tracking-wider text-[#705561] uppercase">
                      Background Song (YouTube IFrame)
                    </h3>
                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <label
                          htmlFor="song-title-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          Song Title
                        </label>
                        <input
                          id="song-title-edit"
                          type="text"
                          value={content.music.songTitle}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              music: {
                                ...content.music,
                                songTitle: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="artist-name-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          Artist Name
                        </label>
                        <input
                          id="artist-name-edit"
                          type="text"
                          value={content.music.artistName}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              music: {
                                ...content.music,
                                artistName: e.target.value,
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                      <div>
                        <label
                          htmlFor="yt-id-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          YouTube Video ID or URL
                        </label>
                        <input
                          id="yt-id-edit"
                          type="text"
                          value={content.music.youtubeVideoId}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              music: {
                                ...content.music,
                                youtubeVideoId: extractYouTubeVideoId(
                                  e.target.value
                                ),
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm"
                        />
                      </div>
                      <div>
                        <label
                          htmlFor="yt-start-edit"
                          className="mb-1 block text-xs font-medium text-[#705561]"
                        >
                          Start Timestamp (seconds)
                        </label>
                        <input
                          id="yt-start-edit"
                          type="number"
                          min={0}
                          value={content.music.startSeconds}
                          onChange={(e) =>
                            onChangeContent({
                              ...content,
                              music: {
                                ...content.music,
                                startSeconds: Math.max(
                                  0,
                                  Number(e.target.value) || 0
                                ),
                              },
                            })
                          }
                          className="w-full rounded-xl border border-[var(--theme-border)] px-3 py-2 text-sm tabular-nums"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Pastel Color Themes */}
                  <div className="space-y-3 border-t border-[var(--theme-border)] pt-4">
                    <h3 className="text-xs font-semibold tracking-wider text-[#705561] uppercase">
                      Color Theme
                    </h3>
                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                      {THEMES.map((th) => {
                        const selected = content.theme === th.id;
                        return (
                          <button
                            key={th.id}
                            type="button"
                            onClick={() =>
                              onChangeContent({ ...content, theme: th.id })
                            }
                            className={`flex items-center gap-3 rounded-2xl border p-3.5 text-left transition-all ${
                              selected
                                ? 'border-[var(--theme-accent)] bg-[#FDF2F4] shadow-xs'
                                : 'border-[var(--theme-border)] bg-white hover:bg-[#FFF8FA]'
                            }`}
                          >
                            <span
                              className="h-6 w-6 shrink-0 rounded-full"
                              style={{ backgroundColor: th.swatch }}
                            />
                            <span className="text-xs font-semibold text-[#36222B]">
                              {th.name}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Backup / Restore / Reset */}
                  <div className="space-y-3 border-t border-[var(--theme-border)] pt-4">
                    <h3 className="text-xs font-semibold tracking-wider text-[#705561] uppercase">
                      Backup &amp; Restore
                    </h3>
                    <div className="flex flex-wrap gap-2.5">
                      <button
                        type="button"
                        onClick={handleExportJson}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[var(--theme-border)] bg-white px-3.5 py-2 text-xs font-medium hover:bg-[#FDF2F4]"
                      >
                        <Download className="h-3.5 w-3.5" />
                        <span>Export JSON Backup</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => importInputRef.current?.click()}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-[var(--theme-border)] bg-white px-3.5 py-2 text-xs font-medium hover:bg-[#FDF2F4]"
                      >
                        <Upload className="h-3.5 w-3.5" />
                        <span>Import Backup</span>
                      </button>
                      <input
                        ref={importInputRef}
                        type="file"
                        accept=".json,application/json"
                        className="hidden"
                        onChange={(e) => {
                          handleImportJson(e.target.files);
                          e.target.value = '';
                        }}
                      />

                      <button
                        type="button"
                        onClick={() => {
                          onChangeContent(createDefaultContent());
                          showToast('Default text restored');
                        }}
                        className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2 text-xs font-medium text-rose-700 hover:bg-rose-100"
                      >
                        <RefreshCw className="h-3.5 w-3.5" />
                        <span>Reset to Defaults</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
